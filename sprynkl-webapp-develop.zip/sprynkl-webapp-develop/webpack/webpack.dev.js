const merge = require('webpack-merge');
const common = require('./webpack.common.js');
const Webpack = require('webpack');
const Path = require('path');
const dotEnv = require('dotenv');

const dest = Path.join(__dirname, '../dist');

module.exports = merge(common, {
  mode: 'development',
  devtool: 'source-map',
  devServer: {
    contentBase: dest,
    inline: true,
    historyApiFallback: true,
    before: (app) => {
      dotEnv.config();
      app.get('/config', (req, res) => {
        res.json({api: process.env.SERVER_ADDRESS || 'http://localhost:8888'});
      });
      app.get('/manifest.json', (req, res) => {
        const manifest = require('../src/manifest.json');
        res.json(manifest);
      });
      app.get('/firebase-messaging-sw.js', (req, res) => {
        res.type('application/javascript; charset=UTF-8');
        res.sendFile(Path.join(__dirname, '../src/firebase-messaging-sw.js'));
      });
    }
  },
  plugins: [
    new Webpack.DefinePlugin({
      'process.env.NODE_ENV': JSON.stringify('development'),
      __isBrowser__: 'true'
    })
  ],
  module: {
    rules: [
      {
        test: /\.(js)$/,
        include: Path.resolve(__dirname, '../src'),
        loader: 'babel-loader'
        // loader: "eslint-loader", // turn on eslint when dev
        // enforce: 'pre',
        // options: {
        //   emitWarning: true
        // }
      },
      {
        test: /\.(js)$/,
        include: Path.resolve(__dirname, '../src'),
        loader: 'babel-loader'
      },
      {
        test: /\.s?css$/i,
        use: ['style-loader', 'css-loader?sourceMap=true', 'sass-loader']
      }
    ]
  }
});
