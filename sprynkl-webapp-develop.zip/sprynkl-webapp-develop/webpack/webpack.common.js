const Path = require("path");
const CleanWebpackPlugin = require("clean-webpack-plugin");
const Webpack = require("webpack");
const HtmlWebpackPlugin = require("html-webpack-plugin");

const dest = Path.join(__dirname, "../public");
module.exports = {
  entry: {
    index: [Path.resolve(__dirname, "./polyfills"), Path.resolve(__dirname, "../src/index")]
  },
  output: {
    path: dest,
    filename: "sprynkl.js", // 'bundle.[hash].js', <~ generate hash bundle
    chunkFilename: "[name].sprynkl.js",
    publicPath: "/"
  },
  plugins: [
    new CleanWebpackPlugin([dest], {
      root: process.cwd()
    }),
    new HtmlWebpackPlugin({
      template: Path.resolve(__dirname, "../src/index.html")
    }),
    new Webpack.HotModuleReplacementPlugin(),
    new Webpack.DefinePlugin({
      __isBrowser__: "true"
    })
  ],
  resolve: {
    alias: {
      "~": Path.resolve(__dirname, "../src"),
      components: Path.resolve(__dirname, "../src/components"),
      services: Path.resolve(__dirname, "../src/services"),
      utils: Path.resolve(__dirname, "../src/utils"),
      configs: Path.resolve(__dirname, "../src/configs"),
      models: Path.resolve(__dirname, "../src/models")
    }
  },
  module: {
    rules: [
      {
        test: /\.(ico|jpg|jpeg|png|gif|webp|svg)(\?.*)?$/,
        use: {
          loader: "file-loader",
          options: {
            name: "assets/images/[name].[ext]"
          }
        }
      },
      {
        test: /\.(eot|otf|ttf|woff|woff2)(\?.*)?$/,
        use: {
          loader: "file-loader",
          options: {
            name: "assets/fonts/[name].[ext]"
          }
        }
      }
    ]
  }
};
