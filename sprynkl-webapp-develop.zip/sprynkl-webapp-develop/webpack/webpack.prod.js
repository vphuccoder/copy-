const merge = require('webpack-merge');
const common = require('./webpack.common.js');
const Webpack = require('webpack');
const Path = require('path');
const ExtractTextPlugin = require('extract-text-webpack-plugin');
const ExtractSASS = new ExtractTextPlugin('styles/bundle.css');
const CopyPlugin = require('copy-webpack-plugin');
const TerserPlugin = require('terser-webpack-plugin');

module.exports = merge(common, {
  mode: 'production',
  stats: 'errors-only',
  optimization: {
    minimize: true,
    minimizer: [
      new TerserPlugin({
        terserOptions: {
          output: {
            comments: false
          }
        }
      })
    ],
    splitChunks: {
      chunks: 'all',
      cacheGroups: {
        react: {
          test: /\/node_modules\/react/,
          name: 'react',
          priority: 1
        },
        vendor: {
          test: /[\\/]node_modules[\\/]/,
          name: 'vendors'

          // name(module) {
          //   // get the name. E.g. node_modules/packageName/not/this/part.js
          //   // or node_modules/packageName
          //   const packageName = module.context.match(/[\\/]node_modules[\\/](.*?)([\\/]|$)/)[1];

          //   // npm package names are URL-safe, but some servers don't like @ symbols
          //   return `npm.${packageName.replace("@", "")}`;
          // }
        }
      }
    }
  },
  plugins: [
    new Webpack.DefinePlugin({
      'process.env.NODE_ENV': JSON.stringify('production'),
      __isBrowser__: 'true'
    }),
    new ExtractTextPlugin({filename: 'bundle.css', allChunks: true}),
    // compiling mode “scope hoisting”
    new Webpack.optimize.ModuleConcatenationPlugin(),
    new CopyPlugin([{from: Path.resolve(__dirname, '../src/static-config'), to: ''}]),
    new CopyPlugin([{from: Path.resolve(__dirname, '../src/firebase-messaging-sw.js'), to: ''}]),
    new CopyPlugin([{from: Path.resolve(__dirname, '../src/manifest.json'), to: ''}]),
    ExtractSASS
  ],
  resolve: {
    alias: {
      '~': Path.resolve(__dirname, '../src')
    }
  },
  module: {
    rules: [
      {
        test: /\.(js)$/,
        exclude: /(node_modules|bower_components)/,
        use: 'babel-loader'
      },
      {
        test: /\.s?css/i,
        use: ExtractSASS.extract(['css-loader', 'sass-loader'])
      }
    ]
  }
});
