import Express from "express";
import { logger } from "./utils/log";
import * as config from "./config";
import Routes from "./routes";

class server {
  constructor() {
      logger.info("starting server");
      this.initRoutes(Express());
      this.start();
  }

  initRoutes(routes) {
    this.app = (new Routes(routes));
  }

  start() {
     logger.info("app starting");
    this.app.listen(config.PORT, () => {
       logger.info("Running on port:", config.PORT);
    });

    process.on("unhandledRejection", error => {
     logger.error("unhandledRejection", error.message);
    });
  }

  static stop() {
    process.exit();
  }
}

export default new server();
