export const PRODUCTION = "production";
export const DEVELOPMENT = "development";