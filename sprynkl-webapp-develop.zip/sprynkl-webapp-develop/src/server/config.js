import dotEnv from "dotenv";

const env = process.env.NODE_ENV;
dotEnv.config();

const NODE_ENV = env || "development";

export { NODE_ENV };
// server configurations
export const PORT = parseInt(process.env.PORT || "8080");
export const SERVER_ADDRESS = process.env.SERVER_ADDRESS || "http://localhost:8888";