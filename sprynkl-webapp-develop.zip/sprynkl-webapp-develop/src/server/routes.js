import bodyParser from 'body-parser';
import express from 'express';
import * as HttpStatus from './http-status';
import path from 'path';
import fs from 'fs';
import {logger, logStream} from './utils/log';
import {SERVER_ADDRESS} from './config';

const morgan = require('morgan');

class AppRoutes {
  constructor(Routers) {
    logger.info('App routes init');
    this.router = Routers;
    this.router.use(bodyParser.urlencoded({extended: false}));
    this.router.use(bodyParser.json({limit: '5mb'}));
    // mount logger middleware
    this.router.use(morgan('dev', {stream: logStream}));

    // add static path
    this.router.use(express.static(path.join(__dirname, 'public')));

    // Serving static files
    this.router.use(express.static('public'));

    this.router.get('/config', (req, res, next) => {
      return res.send({api: SERVER_ADDRESS});
    });

    // add route for iOS universal link and Android app link
    this.router.get('/.well-known/apple-app-site-association', (req, res, next) => {
      const aasa = fs.readFileSync('./magicLinkConfigs/apple-app-site-association');
      res.type('application/json');
      return res.status(HttpStatus.OK).send(aasa);
    });

    this.router.get('/.well-known/assetlinks.json', (req, res, next) => {
      const assetlinks = fs.readFileSync('./magicLinkConfigs/assetlinks.json');
      res.type('application/json');
      return res.status(HttpStatus.OK).send(assetlinks);
    });

    this.router.get('/manifest.json', (req, res, next) => {
      const assetlinks = fs.readFileSync('./manifest.json');
      res.type('application/json');
      return res.status(HttpStatus.OK).send(assetlinks);
    });

    this.router.get('*', (req, res, next) => {
      const indexFile = path.resolve(__dirname, '../../public/index.html');
      fs.readFile(indexFile, 'utf8', (err, data) => {
        if (err) {
          logger.error(err);
          return res.status(500).send('Oops, better luck next time!');
        }

        return res.send(data);
      });
    });

    // api
    this.router.use((req, res, next) => {
      logger.info('%s %d %s', req.method, req.statusCode, req.url);
      res.status(HttpStatus.NOT_FOUND);
      return res.json({
        error: 'Not found'
      });
    });

    this.router.use((error, req, res, next) => {
      res.status(error.status || HttpStatus.SERVER_ERROR);
      logger.error(`${req.method} ${req.url} return ${res.statusCode} ${error.message}`);
      return res.json({
        error: error.message
      });
    });

    return this.router;
  }
}

export default AppRoutes;
