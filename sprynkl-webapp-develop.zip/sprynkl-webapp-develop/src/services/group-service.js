import * as baseHttpService from './http-service';
import {GROUP_API_URL} from '../models/constants';
import {Group, User} from '../models';
import {usageTrackingService} from '.';

class GroupService {
  async createGroup(token, name, defaultAvatar) {
    const body = JSON.stringify({
      name,
      defaultAvatar: `${defaultAvatar}`
    });
    const data = await baseHttpService.sendPost(GROUP_API_URL.base, body, baseHttpService.getBearerHeader(token));
    usageTrackingService.logCreateTeam();
    return Group.map(data);
  }

  /**
   input {
    "name": string,
    "description": string,
    "avatar": string // file id
   }
   */
  async updateGroup(token, groupId, input) {
    const body = JSON.stringify({
      ...input
    });
    const data = await baseHttpService.sendPut(
      `${GROUP_API_URL.base}/${groupId}`,
      body,
      baseHttpService.getBearerHeader(token)
    );
    return Group.map(data);
  }

  async deleteGroup(token, groupId) {
    await baseHttpService.sendDelete(`${GROUP_API_URL.base}/${groupId}`, baseHttpService.getBearerHeader(token));
  }

  async getGroup(token, groupId) {
    const data = await baseHttpService.sendGet(
      `${GROUP_API_URL.base}/${groupId}`,
      baseHttpService.getBearerHeader(token)
    );
    return Group.map(data);
  }

  async blockUser(token, groupId, userId) {
    const body = JSON.stringify({
      group: groupId,
      blockUser: userId
    });
    await baseHttpService.sendPost(GROUP_API_URL.block, body, baseHttpService.getBearerHeader(token));
  }

  async removeUser(token, groupId, userId) {
    const body = JSON.stringify({
      group: groupId,
      removeUser: userId
    });
    await baseHttpService.sendPost(GROUP_API_URL.remove, body, baseHttpService.getBearerHeader(token));
  }

  async assignOwner(token, groupId, assignedOwnerId) {
    const body = JSON.stringify({
      groupId,
      assignedOwnerId
    });
    await baseHttpService.sendPost(GROUP_API_URL.assignOwner, body, baseHttpService.getBearerHeader(token));
  }

  async assignRole(token, groupId, userId, role) {
    const body = JSON.stringify({
      group: groupId,
      selectedUser: userId,
      role
    });
    await baseHttpService.sendPost(GROUP_API_URL.assignRole, body, baseHttpService.getBearerHeader(token));
  }

  async invite(token, groupId, emails) {
    const body = JSON.stringify({
      users: emails
    });
    const data = await baseHttpService.sendPost(
      `${GROUP_API_URL.invite}/${groupId}`,
      body,
      baseHttpService.getBearerHeader(token)
    );
    return Group.map(data);
  }

  async getLeaderBoard(token, groupId, startTime, endTime) {
    const data = await baseHttpService.sendGet(
      `${GROUP_API_URL.leaderBoard}${groupId}?startTime=${startTime}&endTime=${endTime}`,
      baseHttpService.getBearerHeader(token)
    );
    const result = [];

    data.forEach((item) => {
      result.push({user: User.map(item.user), karma: item.karma});
    });
    return result;
  }

  async getEmailDomain(token, groupId) {
    const data = await baseHttpService.sendGet(
      `${GROUP_API_URL.emailDomain}/${groupId}`,
      baseHttpService.getBearerHeader(token)
    );
    return data;
  }
}

const groupService = new GroupService();
export default groupService;
