// @flow
import * as firebase from 'firebase/app';
import 'firebase/messaging';

class PushMessageService {
  async checkPermission(): Promise<boolean> {
    if (!firebase.messaging.isSupported()) {
      return false;
    }

    try {
      let permission = await Notification.requestPermission();
      return permission === 'granted';
    } catch (error) {
      return false;
    }
  }

  async getRegistrationToken(): Promise<string> {
    const fcmToken = await firebase.messaging().getToken();
    return fcmToken;
  }
}

const pushMessageService = new PushMessageService();
export default pushMessageService;
