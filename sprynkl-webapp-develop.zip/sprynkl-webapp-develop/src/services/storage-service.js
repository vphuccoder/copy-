const REFRESH_TOKEN_KEY = 'refeshToken';
const UUID_KEY = 'uuid';
class StorageService {
  setToken(token) {
    localStorage.setItem(REFRESH_TOKEN_KEY, token.refreshToken);
  }

  getRefreshToken() {
    return localStorage.getItem(REFRESH_TOKEN_KEY);
  }

  getItem(item) {
    return localStorage.getItem(item);
  }

  getUUID() {
    return localStorage.getItem(UUID_KEY);
  }

  setUUID(key) {
    localStorage.setItem(UUID_KEY, key);
  }

  clearRefreshToken() {
    return localStorage.removeItem(REFRESH_TOKEN_KEY);
  }
}

const storageService = new StorageService();
export default storageService;
