import * as baseHttpService from './http-service';
import {appConfig} from '../models';

class AppService {
  async getAppSetting() {
    const result = await baseHttpService.getConfig();
    appConfig.populateData(result);
  }
}

const appService = new AppService();
export default appService;
