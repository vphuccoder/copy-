// @flow
import * as baseHttpService from './http-service';
import {USER_API_URL} from 'models/constants';
import {User, Token, UserSettingModel, UserType} from '../models';
import {usageTrackingService} from '.';

class UserService {
  async oauth(
    username: string,
    password: string,
    deviceId: string,
    fcmToken: string,
    oneTimeLogin: boolean = false
  ): Promise {
    const body = JSON.stringify({
      grant_type: 'password',
      username,
      password,
      deviceId,
      fcmToken,
      oneTimeLogin
    });
    const data = await baseHttpService.sendPost(USER_API_URL.oauth, body, baseHttpService.getBasicHeader());
    return Token.map(data);
  }

  async googelOauth(username: string, idToken: string, deviceId: string, fcmToken: string): Promise {
    const body = JSON.stringify({
      grant_type: 'password',
      username,
      password: idToken,
      userType: UserType.GOOGLE,
      deviceId,
      fcmToken,
      oneTimeLogin: false
    });
    const data = await baseHttpService.sendPost(USER_API_URL.oauth, body, baseHttpService.getBasicHeader());
    return Token.map(data);
  }

  async checkPin(email: string, pin: string) {
    const body = JSON.stringify({
      grant_type: 'password',
      email,
      pin
    });
    await baseHttpService.sendPost(USER_API_URL.checkPin, body, baseHttpService.getBasicHeader());
  }

  async refreshToken(token: string, fcmToken: boolean = ''): Promise {
    const jsonBody = {
      grant_type: 'refresh_token',
      refresh_token: token,
      fcmToken
    };
    const body = JSON.stringify(jsonBody);
    const data = await baseHttpService.sendPost(USER_API_URL.oauth, body, baseHttpService.getBasicHeader());
    return Token.map(data);
  }

  async resendSignupPin(email: string): Promise {
    const body = JSON.stringify({
      email
    });
    await baseHttpService.sendPost(USER_API_URL.resendPin, body, baseHttpService.getBasicHeader());
  }

  async checkEmail(email: string, sendCode: boolean = true): Promise {
    const body = JSON.stringify({email});
    const data = await baseHttpService.sendPost(
      `${USER_API_URL.checkEmail}?sendCode=${sendCode}`,
      body,
      baseHttpService.getBasicHeader()
    );
    return User.map(data);
  }

  async generateLoginPin(email: string): Promise {
    const body = JSON.stringify({
      email
    });
    await baseHttpService.sendPost(USER_API_URL.generatePin, body, baseHttpService.getBasicHeader());
  }
  async createUser(token: string, fullName: string, password: string, defaultAvatar: number, meta: {}): Promise {
    const body = JSON.stringify({
      fullName,
      password,
      defaultAvatar: `${defaultAvatar}`,
      meta
    });
    const data = await baseHttpService.sendPost(USER_API_URL.base, body, baseHttpService.getBearerHeader(token));
    usageTrackingService.logCreateAccount();
    return User.map(data);
  }

  async createGoogleUser(email: string, idToken: string, defaultAvatar: number, meta: {}): Promise {
    const body = JSON.stringify({
      email,
      idToken,
      defaultAvatar: `${defaultAvatar}`,
      meta
    });
    const data = await baseHttpService.sendPost(USER_API_URL.google, body, baseHttpService.getBasicHeader());
    usageTrackingService.logCreateAccount(UserType.GOOGLE);
    return User.map(data);
  }

  async updateUser(token: string, input: {}): Promise {
    const body = JSON.stringify({
      ...input
    });
    const data = await baseHttpService.sendPut(USER_API_URL.base, body, baseHttpService.getBearerHeader(token));
    return User.map(data);
  }

  async getUser(token: string): Promise {
    const data = await baseHttpService.sendGet(USER_API_URL.base, baseHttpService.getBearerHeader(token));
    return User.map(data);
  }

  async getUserById(token: string, userId: string): Promise {
    const data = await baseHttpService.sendGet(
      `${USER_API_URL.base}/${userId}`,
      baseHttpService.getBearerHeader(token)
    );
    return User.map(data);
  }

  async skipAction(token: string, actionId: string) {
    const body = JSON.stringify({
      actionId
    });
    await baseHttpService.sendPost(USER_API_URL.skipAction, body, baseHttpService.getBearerHeader(token));
  }

  async leaveGroup(token: string, id: string): Promise {
    const body = JSON.stringify({
      id
    });
    const data = await baseHttpService.sendPost(USER_API_URL.leaveGroup, body, baseHttpService.getBearerHeader(token));
    return User.map(data);
  }

  // action in ["join", "skip"]
  async confirmGroup(token: string, id: string, action: string): Promise {
    const body = JSON.stringify({
      id,
      action
    });
    const data = await baseHttpService.sendPost(
      USER_API_URL.confirmGroup,
      body,
      baseHttpService.getBearerHeader(token)
    );
    return User.map(data);
  }

  async changePassword(token: string, oldPassword: string, newPassword: string): Promise {
    const body = JSON.stringify({
      oldPassword,
      newPassword
    });
    await baseHttpService.sendPost(USER_API_URL.changePassword, body, baseHttpService.getBearerHeader(token));
  }

  async forgetPassword(email: string) {
    const body = JSON.stringify({
      email
    });
    await baseHttpService.sendPost(USER_API_URL.forgetPassword, body, baseHttpService.getBasicHeader());
  }

  async resetPassword(email: string, pin: string, newPassword: string): Promise {
    const body = JSON.stringify({
      email,
      pin,
      newPassword
    });
    await baseHttpService.sendPost(USER_API_URL.resetPassword, body, baseHttpService.getBasicHeader());
  }

  getAllUserTeam(token: string): Promise {
    return baseHttpService.sendGet(USER_API_URL.getAllTeam, baseHttpService.getBearerHeader(token));
  }

  logOut(token: string, deviceId: string = ''): Promise {
    const body = JSON.stringify({
      deviceId
    });
    return baseHttpService.sendPost(USER_API_URL.logOut, body, baseHttpService.getBearerHeader(token));
  }

  sendFeedback(token: string, feedback: string, meta: {}): Promise {
    const body = JSON.stringify({
      feedback,
      meta
    });
    return baseHttpService.sendPost(USER_API_URL.sendFeedback, body, baseHttpService.getBearerHeader(token));
  }

  updateRecentSearches(token: string, text: string): Promise {
    const body = JSON.stringify({
      keyword: text
    });
    return baseHttpService.sendPost(USER_API_URL.updateRecentSearch, body, baseHttpService.getBearerHeader(token));
  }

  async getUserSetting(token: string): Promise {
    const result = await baseHttpService.sendGet(USER_API_URL.getUserSetting, baseHttpService.getBearerHeader(token));
    return UserSettingModel.map(result);
  }

  async signUp({email, fullName, password}: {email: string, fullName: string, password: string}): Promise {
    const body = JSON.stringify({
      email,
      fullName,
      password
    });
    await baseHttpService.sendPost(USER_API_URL.signUp, body, baseHttpService.getBasicHeader());
  }

  async resendVerifyEmail(email: string): Promise {
    const body = JSON.stringify({
      email
    });
    await baseHttpService.sendPost(USER_API_URL.resendVerifyEmail, body, baseHttpService.getBasicHeader());
  }

  async verifyAccount({email, pin}: {email: string, pin: string}): Promise {
    const body = JSON.stringify({
      email,
      pin
    });
    return baseHttpService.sendPost(USER_API_URL.verifyAccount, body, baseHttpService.getBasicHeader());
  }

  removeRecentSearch(token: string, searchTerm: string) {
    const body = JSON.stringify({
      searchTerm
    });
    return baseHttpService.sendPatchDelete(USER_API_URL.removeSearchTerm, body, baseHttpService.getBearerHeader(token));
  }
}

const userService = new UserService();
export default userService;
