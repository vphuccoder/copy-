// @flow
import {GoogleUser} from '../models';

class GoogleService {
  async onSuccess(response: {}): GoogleUser {
    const user = await GoogleUser.map(response);
    return user;
  }

  async onFailure(response: {}) {
    // do something handle error here!
  }
}
const googleService = new GoogleService();
export default googleService;
