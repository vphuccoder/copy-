import * as baseHttpService from './http-service';
import {FILE_API_URL} from 'models/constants';

class FileService {
  async uploadFile(token, file, fileName, fileType) {
    const headers = baseHttpService.getBearerHeader(token);
    const customHeaders = Object.assign(headers, {
      'x-filename': fileName,
      'Content-Type': fileType
    });
    return await baseHttpService.sendPost(FILE_API_URL.base, file, customHeaders);
  }
}

const fileService = new FileService();
export default fileService;
