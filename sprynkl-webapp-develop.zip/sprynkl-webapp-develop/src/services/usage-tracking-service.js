// @flow
// import { analytics } from "react-native-firebase";
// import { deviceService } from ".";
// import { UserType } from "../models";

const events = {
  CREATE_POST: 'create_post',
  CLAP_POST: 'clap_post',
  COMMENT_POST: 'comment_post',
  CREATE_TEAM: 'create_team',
  CREATE_ACCOUNT: 'create_account',
  GET_FEED: 'get_feed',
  FILTER_FEED: 'filter_feed',
  REPOST_POST: 'repost_post',
  DELETE_POST: 'delete_post'
};

class UsageTrackingService {
  setCurrentScreen(currentScreen: string) {
    // try {
    //   analytics().setCurrentScreen(currentScreen);
    // } catch {
    //   // we dont't want this tracking interrupt user flow
    // }
  }

  setUserId(id: string) {
    // try {
    //   analytics().setUserId(id);
    // } catch {
    //   // we dont't want this tracking interrupt user flow
    // }
  }

  logCreateTeam() {
    // try {
    //   analytics().logEvent(events.CREATE_TEAM, { appVerson: deviceService.getAppVersion });
    // } catch {
    //   // we dont't want this tracking interrupt user flow
    // }
  }

  logCreateAccount(type: string = UserType.BUILD_IN) {
    // try {
    //   analytics().logEvent(events.CREATE_ACCOUNT, { appVerson: deviceService.getAppVersion, type });
    // } catch {
    //   // we dont't want this tracking interrupt user flow
    // }
  }

  logCreatePostEvent(type: string) {
    // try {
    //   const params = {
    //     type
    //   };
    //   analytics().logEvent(events.CREATE_POST, params);
    //   analytics().logEvent(`create_${type}`);
    // } catch {
    //   // we dont't want this tracking interrupt user flow
    // }
  }

  logClapAPost(type: string) {
    // try {
    //   const params = {
    //     type
    //   };
    //   analytics().logEvent(events.CLAP_POST, params);
    // } catch {
    //   // we dont't want this tracking interrupt user flow
    // }
  }

  logCommentAPost(type: string) {
    // try {
    //   const params = {
    //     type
    //   };
    //   analytics().logEvent(events.COMMENT_POST, params);
    // } catch {
    //   // we dont't want this tracking interrupt user flow
    // }
  }

  logGetFeed(page: number) {
    // try {
    //   const params = {
    //     page
    //   };
    //   analytics().logEvent(events.GET_FEED, params);
    // } catch {
    //   // we dont't want this tracking interrupt user flow
    // }
  }

  logFilterFeed(page: number, keyWord: stirng, types: string[]) {
    // try {
    //   const params = {
    //     page,
    //     keyWord,
    //     types
    //   };
    //   analytics().logEvent(events.FILTER_FEED, params);
    // } catch {
    //   // we dont't want this tracking interrupt user flow
    // }
  }

  logReportPost() {
    // try {
    //   analytics().logEvent(events.REPOST_POST, {});
    // } catch {
    //   // we dont't want this tracking interrupt user flow
    // }
  }

  logDeletePost() {
    // try {
    //   analytics().logEvent(events.DELETE_POST, {});
    // } catch {
    //   // we dont't want this tracking interrupt user flow
    // }
  }
}

const usageTrackingService = new UsageTrackingService();
export default usageTrackingService;
