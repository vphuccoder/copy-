import uuidv1 from 'uuid/v1';

class UuidService {
  getUUID() {
    return uuidv1();
  }
}

const uuidService = new UuidService();

export default uuidService;
