// @flow

import * as baseHttpService from './http-service';
import {usageTrackingService} from '.';
import {POST_API_URL, SYSTEM_VARIABLE} from 'models/constants';
import {PostModel, FeedModel} from 'models/';

type FilterParamType = {
  isHashtag: boolean,
  types: Array<string>,
  keyword: string,
  pageNumer: number,
  pageSize: number,
  groupId: string
};
class PostService {
  async getPost(token: string, postId: string): Promise<PostModel> {
    const data = await baseHttpService.sendGet(
      `${POST_API_URL.base}/${postId}`,
      baseHttpService.getBearerHeader(token)
    );
    return PostModel.map(data);
  }

  async clapAPost(token: string, postId: string, clapCount: number): Promise<PostModel> {
    const body = JSON.stringify({
      post: postId,
      clapNumber: clapCount
    });
    const data = await baseHttpService.sendPost(POST_API_URL.clap, body, baseHttpService.getBearerHeader(token));
    const model = PostModel.map(data);
    usageTrackingService.logClapAPost(model.type);
    return model;
  }

  async commentAPost(token: string, postId: string, content: string, extraData: {}): Promise<PostModel> {
    const body = JSON.stringify({
      post: postId,
      content,
      hashTags: extraData.hashTags || [],
      tags: extraData.tags || [],
      textContent: extraData.textContent || content
    });
    const data = await baseHttpService.sendPost(POST_API_URL.comment, body, baseHttpService.getBearerHeader(token));
    const model = PostModel.map(data);
    usageTrackingService.logCommentAPost(model.type);
    return model;
  }

  async deletePost(token: string, postId: string): Promise {
    await baseHttpService.sendDelete(`${POST_API_URL.base}/${postId}`, baseHttpService.getBearerHeader(token));
    usageTrackingService.logDeletePost();
  }

  async reportPost(token: string, id: string, description: string): Promise {
    const body = JSON.stringify({
      id,
      description
    });
    await baseHttpService.sendPost(POST_API_URL.reportPost, body, baseHttpService.getBearerHeader(token));
    usageTrackingService.logReportPost();
  }

  async deleteComment(token: string, commentId: string): Promise {
    await baseHttpService.sendDelete(`${POST_API_URL.comment}/${commentId}`, baseHttpService.getBearerHeader(token));
  }

  async reportComment(token: string, id: string, description: string): Promise {
    const body = JSON.stringify({
      id,
      description
    });
    await baseHttpService.sendPost(POST_API_URL.reportComment, body, baseHttpService.getBearerHeader(token));
  }

  async createPost(token: string, postData: {}): Promise {
    const body = JSON.stringify(postData);
    const data = await baseHttpService.sendPost(POST_API_URL.base, body, baseHttpService.getBearerHeader(token));
    const model = PostModel.map(data);
    usageTrackingService.logCreatePostEvent(model.type);
    return model;
  }

  async getAllFeed(token: string, pageSize: number = 60, pageNumber: number = 1): Promise<FeedModel> {
    const url = `${POST_API_URL.getAllFeed}?p=${pageNumber}&s=${pageSize}`;
    const data = await baseHttpService.sendGet(url, baseHttpService.getBearerHeader(token));
    usageTrackingService.logGetFeed(pageNumber);
    return FeedModel.map(data);
  }

  async getGroupFeed(
    token: string,
    pageSize: number = 60,
    pageNumber: number = 1,
    groupId: string
  ): Promise<FeedModel> {
    const url = `${POST_API_URL.getGroupFeed}${groupId}?p=${pageNumber}&s=${pageSize}`;
    const data = await baseHttpService.sendGet(url, baseHttpService.getBearerHeader(token));
    usageTrackingService.logGetFeed(pageNumber);
    return FeedModel.map(data);
  }

  async getUserFeed(
    token: string,
    pageSize: number = SYSTEM_VARIABLE.PAGE_SIZE,
    pageNumber: number = 1,
    filterType: string = '',
    postType: string = ''
  ): Promise<FeedModel> {
    const url = `${POST_API_URL.base}?p=${pageNumber}&s=${pageSize}&filterType=${filterType}&postType=${postType}`;
    const data = await baseHttpService.sendGet(url, baseHttpService.getBearerHeader(token));
    return FeedModel.map(data);
  }

  async responseAsk(token: string, id: string, value: string, reason: string): Promise {
    const body = JSON.stringify({
      id,
      value,
      reason
    });
    const data = await baseHttpService.sendPost(POST_API_URL.responseAsk, body, baseHttpService.getBearerHeader(token));
    return PostModel.map(data);
  }

  async filterFeed(token: string, data: FilterParamType): Promise<FeedModel> {
    const {keyword, hashtag, types, pageNumber, pageSize, groupId} = data;
    const body = JSON.stringify({
      keyword,
      hashtag,
      types,
      p: pageNumber,
      s: pageSize,
      groupId
    });
    const result = await baseHttpService.sendPost(
      POST_API_URL.filterFeed,
      body,
      baseHttpService.getBearerHeader(token)
    );
    const trackKey = keyword || hashtag;
    usageTrackingService.logFilterFeed(pageNumber, trackKey, types);
    return result;
  }
}

const postService = new PostService();
export default postService;
