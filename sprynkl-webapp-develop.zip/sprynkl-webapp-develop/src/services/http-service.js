import {Buffer} from 'buffer';
import axios from 'axios';

import {BASE_AUTH} from '../configs';
import {HTTP_STATUS} from '../models/constants/http-status';
import {appConfig} from '../models';

export const BaseHeaders = {
  Accept: 'application/json',
  'Content-Type': 'application/json'
};

export function getApiUrl(api) {
  return `${appConfig.API_URL}${api}`;
}

export function getBearerHeader(token) {
  return {Authorization: `bearer ${token}`};
}

export function getBasicHeader() {
  const {clientId, clientSecret} = BASE_AUTH;
  const basicCredentials = Buffer.from(`${clientId}:${clientSecret}`).toString('base64');
  return {Authorization: `basic ${basicCredentials}`};
}

export async function handleError(error) {
  // handle error response
  let result;
  const response = error.response || {};
  const data = response.data;
  if (response.status) {
    switch (response.status) {
      case HTTP_STATUS.notFound.code:
        result = {...HTTP_STATUS.notFound, data};
        break;
      case HTTP_STATUS.forbidden.code:
        result = {...HTTP_STATUS.forbidden, data};
        break;
      case HTTP_STATUS.unauthorized.code:
        result = {...HTTP_STATUS.unauthorized, data};
        break;
      case HTTP_STATUS.badRequest.code:
        result = {...HTTP_STATUS.badRequest, data};
        break;
      default:
        result = {message: 'server error', data};
        break;
    }
  } else {
    result = {message: error.message, data};
  }
  return result;
}

export async function send(method, api, body, headers = BaseHeaders) {
  try {
    const response = await axios(getApiUrl(api), {
      method,
      headers: {
        ...BaseHeaders,
        ...headers
      },
      data: body
    });
    return response.data;
  } catch (error) {
    throw await handleError(error);
  }
}

export async function sendPost(api, body, headers = BaseHeaders) {
  return send('POST', api, body, headers);
}

export async function sendPut(api, body, headers = BaseHeaders) {
  return send('PUT', api, body, headers);
}

export async function sendDelete(api, headers = BaseHeaders) {
  return send('DELETE', api, '', headers);
}

export async function sendPatchDelete(api, body, headers = BaseHeaders) {
  return send('DELETE', api, body, headers);
}

export async function sendGet(api, headers = BaseHeaders) {
  return send('GET', api, undefined, headers);
}

export async function getConfig(headers = BaseHeaders) {
  const api = window.location.origin;
  try {
    const response = await axios(`${api}\\config`, {
      method: 'GET',
      headers: {
        ...BaseHeaders,
        ...headers
      }
    });

    return response.data;
  } catch (error) {
    throw await handleError(error);
  }
}
