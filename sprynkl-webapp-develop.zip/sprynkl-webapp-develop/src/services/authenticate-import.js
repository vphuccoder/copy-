import {lazy} from 'react';
import {appModel} from '../models/app-model';
import {storageService, userService, appService} from '.';
import {appConfig} from '../models';

const preLoadInfos = async () => {
  if (!appConfig.API_URL) {
    await appService.getAppSetting();
  }

  const {fcmToken, currentToken, currentUser} = appModel;
  const refreshToken = storageService.getRefreshToken();
  if (refreshToken && (!appModel.currentToken || !appModel.currentUser)) {
    const token = await userService.refreshToken(refreshToken, fcmToken);
    const user = await userService.getUser(token.accessToken);
    appModel.setCurrentToken(token);
    appModel.setCurrentUser(user);
  }
};

const Home = lazy(async () => {
  if (!appConfig.API_URL) {
    await appService.getAppSetting();
  }
  const {fcmToken} = appModel;
  const refreshToken = storageService.getRefreshToken();
  if (appModel.currentToken && appModel.currentUser && refreshToken) {
    return require('../pages/home/Home');
  }
  if (refreshToken && (!appModel.currentToken || !appModel.currentUser)) {
    try {
      const token = await userService.refreshToken(refreshToken, fcmToken);
      const user = await userService.getUser(token.accessToken);
      appModel.setCurrentToken(token);
      appModel.setCurrentUser(user);
      return require('../pages/home/Home');
    } catch (e) {
      return require('../pages/getStart/GetStart');
    }
  }
  return require('../pages/getStart/GetStart');
});

const Profile = lazy(async () => {
  if (appModel.currentToken && appModel.currentUser) {
    return require('../pages/userProfile/UserProfile');
  }

  const refreshToken = storageService.getRefreshToken();
  const {fcmToken} = appModel;
  if (refreshToken) {
    try {
      await preLoadInfos();
      return require('../pages/userProfile/UserProfile');
    } catch (e) {}
  }
  appModel.loginRedirect = window.location.pathname;
  return require('../pages/login/Login');
});

const Settings = lazy(async () => {
  if (appModel.currentToken && appModel.currentUser) {
    return require('../pages/settings/Settings');
  }

  const refreshToken = storageService.getRefreshToken();
  if (refreshToken) {
    try {
      await preLoadInfos();
      return require('../pages/settings/Settings');
    } catch (e) {
      return require('../pages/login/Login');
    }
  }
  appModel.loginRedirect = window.location.pathname;
  return require('../pages/login/Login');
});

const PostDetail = lazy(async () => {
  if (appModel.currentToken && appModel.currentUser) {
    return require('../pages/postDetail/PostDetail');
  }

  const refreshToken = storageService.getRefreshToken();
  if (refreshToken) {
    try {
      await preLoadInfos();
      return require('../pages/postDetail/PostDetail');
    } catch (e) {
      return require('../pages/login/Login');
    }
  }
  appModel.loginRedirect = window.location.pathname;
  return require('../pages/login/Login');
});

const Search = lazy(async () => {
  if (appModel.currentToken && appModel.currentUser) {
    return require('../pages/search/Search');
  }

  const refreshToken = storageService.getRefreshToken();
  if (refreshToken) {
    try {
      await preLoadInfos();
      return require('../pages/search/Search');
    } catch (e) {
      return require('../pages/login/Login');
    }
  }
  appModel.loginRedirect = window.location.pathname;
  return require('../pages/login/Login');
});

export {Home, Profile, Settings, PostDetail, Search};
