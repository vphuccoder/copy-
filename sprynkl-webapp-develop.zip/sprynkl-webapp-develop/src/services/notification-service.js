// @flow

import * as baseHttpService from './http-service';
import {NOTIFICATION_API_URL} from '../models/constants/index';
import {NotificationListModel, Notification} from '../models/index';

class NotificationService {
  async getNotification(token: string, pageSize: number = 60, pageNumber: number = 1): Promise {
    const url = `${NOTIFICATION_API_URL.base}?p=${pageNumber}&s=${pageSize}&minify=true`;
    const data = await baseHttpService.sendGet(url, baseHttpService.getBearerHeader(token));
    return NotificationListModel.map(data);
  }

  async getNotificationById(token: string, id: string): Promise {
    const data = await baseHttpService.sendGet(
      `${NOTIFICATION_API_URL.base}/${id}`,
      baseHttpService.getBearerHeader(token)
    );
    return Notification.map(data);
  }

  async checkNotSeenNotification(token: string, pageSize: number = 60, pageNumber: number = 1): Promise {
    const url = `${NOTIFICATION_API_URL.checkNotSeen}?p=${pageNumber}&s=${pageSize}`;
    const data = await baseHttpService.sendGet(url, baseHttpService.getBearerHeader(token));
    const {status} = data;
    return status;
  }

  async updateSeen(token: string, ids: []): Promise {
    const body = JSON.stringify({
      ids
    });
    await baseHttpService.sendPost(NOTIFICATION_API_URL.seen, body, baseHttpService.getBearerHeader(token));
  }

  async updateRead(token: string, ids: []): Promise {
    const body = JSON.stringify({
      ids
    });
    await baseHttpService.sendPost(NOTIFICATION_API_URL.read, body, baseHttpService.getBearerHeader(token));
  }

  async deletePatchNotification(token: string, ids: []): Promise {
    const body = JSON.stringify({
      ids
    });
    await baseHttpService.sendPatchDelete(
      NOTIFICATION_API_URL.deletePatch,
      body,
      baseHttpService.getBearerHeader(token)
    );
  }

  async deleteNotification(token: string, id: string): Promise {
    await baseHttpService.sendDelete(`${NOTIFICATION_API_URL.base}/${id}`, baseHttpService.getBearerHeader(token));
  }
}

const notificationService = new NotificationService();
export default notificationService;
