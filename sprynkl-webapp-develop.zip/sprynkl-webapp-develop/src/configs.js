export const API_URL = 'https://dev-api.sprynkl.com'; // Dev environment

const BASE_AUTH = {
  clientId: 'web',
  clientSecret: 'YbtvqGzWSxGnDELxD'
};
export {BASE_AUTH};

export const WEB_CLIENT_ID = '406557674692-0448v0mshapsmn735fia73orp6r0dek0.apps.googleusercontent.com';

export const URL_ABOUT_US = 'https://www.sprynkl.io/';
export const URL_TERM_OF_USE = 'https://www.sprynkl.io/terms-of-use/';
export const URL_HELP_CENTER = 'https://www.sprynkl.io/help-center/';
export const URL_PRIVACY_POLICY = 'https://www.sprynkl.io/privacy-policy/';
export const URL_ACCEPTABLE_USE_POLICY = 'https://www.sprynkl.io/acceptable-use-policy/';
export const URL_BLOG = 'https://www.sprynkl.io/blog/';

export const FIRE_BASE_CONFIG = {
  apiKey: 'AIzaSyBqHXNM-MeCuG6t5o3b20Xpd2frdx8lrh0',
  authDomain: 'sprynkl-431b2.firebaseapp.com',
  databaseURL: 'https://sprynkl-431b2.firebaseio.com',
  projectId: 'sprynkl-431b2',
  storageBucket: 'sprynkl-431b2.appspot.com',
  messagingSenderId: '406557674692',
  appId: '1:406557674692:web:7a89058e19f59bb9'
};

export const FIRE_BASE_PUBLIC_KEY =
  'BBXkYzQtwD-JkO8lID6i7Iqi98kIGtQZVjQAJuyk4J2kq6IR2DIb9_KsOmNzxKC4gsEWvepljrImzaqJ1OQvT6s';
