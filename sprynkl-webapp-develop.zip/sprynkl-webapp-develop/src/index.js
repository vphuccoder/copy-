import React from 'react';
import ReactDOM from 'react-dom';
import {BrowserRouter} from 'react-router-dom';
import * as firebase from 'firebase/app';
import 'firebase/messaging';
import {FIRE_BASE_CONFIG, FIRE_BASE_PUBLIC_KEY} from './configs';
import './assets/images/favicon.png';
import './style.scss';
import App from './App';

if (firebase.messaging.isSupported()) {
  // Initialize Firebase
  firebase.initializeApp(FIRE_BASE_CONFIG);
  const messaging = firebase.messaging();
  messaging.usePublicVapidKey(FIRE_BASE_PUBLIC_KEY);
}

if (process.env.NODE_ENV === 'development') {
  ReactDOM.render(
    <BrowserRouter>
      <App />
    </BrowserRouter>,
    document.getElementById('root')
  );
} else {
  ReactDOM.hydrate(
    <BrowserRouter>
      <App />
    </BrowserRouter>,
    document.getElementById('root')
  );
}
