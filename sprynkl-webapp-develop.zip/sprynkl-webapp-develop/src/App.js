// @flow

import autobind from 'autobind-decorator';
import 'babel-polyfill';
import {observer} from 'mobx-react';
import React, {Suspense} from 'react';
import {Button, Modal, Spinner} from 'react-bootstrap';
import {Route, Switch} from 'react-router-dom';
import {AlertMessage, AlertMessageViewModel, PrivateRoute, RemountingRoute} from './components/baseComponents';
import {ModalProvider, ModalRoot} from './components/context';
import {DialogViewModel} from './components/modals';
import {appModel} from './models/app-model';
import {GetStart, Login, MagicLink, ResetPassword, SignUp, NotFound, PageForbidden} from './pages';
import {appService, pushMessageService} from './services';
import {Home, Profile, Settings, PostDetail, Search} from './services/authenticate-import';

@observer
class App extends React.Component {
  state = {
    isConfigReady: false
  };
  dialogViewModel = new DialogViewModel();

  alertMessageViewModel = new AlertMessageViewModel();

  async componentDidMount() {
    appModel.dialogViewModel = this.dialogViewModel;
    appModel.alertMessageViewModel = this.alertMessageViewModel;
    window.onpopstate = this.onPopState;
    await appService.getAppSetting();
    await this.updateFCMToken();
    this.setState({
      isConfigReady: true
    });
  }

  @autobind
  onPopState(event: PopStateEvent) {
    event.preventDefault();
    this.handleCloseDialog();
  }

  componentWillUnmount() {
    window.onpopstate = undefined;
  }

  @autobind
  async updateFCMToken(): Promise {
    try {
      // Check push notification permission
      const permission = await pushMessageService.checkPermission();
      if (permission === true) {
        const fcmToken = await pushMessageService.getRegistrationToken();
        appModel.fcmToken = fcmToken;
      }

      appModel.notificationPermission = permission;
    } catch (e) {
      console.error(e);
    }
  }

  @autobind
  handleCloseDialog() {
    this.dialogViewModel.hideDialog();
  }

  @autobind
  renderButtons(): React.Node[] {
    const buttons = [];
    const buttonDatas = this.dialogViewModel.modal.buttons;
    buttonDatas.forEach((data: {}) => {
      buttons.push(
        <Button variant={data.variant} onClick={data.handleButtonClick} key={`dialog-button-${data.name}`}>
          {`${data.title}`}
        </Button>
      );
    }, this);

    return buttons;
  }

  @autobind
  renderAlert(): React.Node {
    return (
      <div className="position-fixed top-alert">
        <AlertMessage viewModel={this.alertMessageViewModel} />
      </div>
    );
  }

  render(): React.Node {
    const {isConfigReady} = this.state;
    return !isConfigReady ? null : (
      <Suspense fallback={<Spinner />}>
        <ModalProvider>
          <ModalRoot />
          <Switch>
            <Route path="/get-start" component={GetStart} />
            <Route path="/login" component={Login} />
            <Route path="/signup" component={SignUp} />
            <Route path="/reset-password" component={ResetPassword} />
            <Route path="/magic-link" component={MagicLink} />
            <Route exact path="/notfound" component={NotFound} />
            <Route exact path="/forbidden" component={PageForbidden} />
            <RemountingRoute exact path="/profile/:id" component={Profile} />
            <RemountingRoute exact path="/settings" component={Settings} />
            <RemountingRoute exact path="/post/:id" component={PostDetail} />
            <RemountingRoute exact path="/search/:searchTerm?" component={Search} />
            <RemountingRoute exact path="/group/:id" component={Home} />
            <PrivateRoute exact path="/" component={Home} />
            <Route path="*" component={NotFound} />
          </Switch>
        </ModalProvider>
        <Modal show={this.dialogViewModel.modal.show} onHide={this.handleCloseDialog}>
          <Modal.Header>
            <Modal.Title>{this.dialogViewModel.modal.title || 'Sprynkl'}</Modal.Title>
          </Modal.Header>
          <Modal.Body>
            <div>{this.dialogViewModel.modal.body}</div>
          </Modal.Body>
          <Modal.Footer>{this.renderButtons()}</Modal.Footer>
        </Modal>

        <Modal
          dialogClassName="progress-modal"
          show={this.dialogViewModel.modal.showProgressIndicator}
          onHide={() => {}}
          centered
        >
          <Modal.Body>
            <Spinner animation="border" variant="primary" />
          </Modal.Body>
        </Modal>
        {this.renderAlert()}
      </Suspense>
    );
  }
}
export default App;
