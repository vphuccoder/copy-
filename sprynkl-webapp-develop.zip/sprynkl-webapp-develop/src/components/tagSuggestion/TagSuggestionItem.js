/**
 * @format
 * @flow
 */
import React, {Component} from 'react';
import {ListGroup} from 'react-bootstrap';
import autobind from 'autobind-decorator';
import {TagVM} from '.';
import {renderUserAvatar} from '../baseComponents/svg/Avatar';

type PropsType = {
  tag: TagVM,
  onSelectTag: void
};

class TagSuggestionItem extends Component<PropsType> {
  @autobind
  onSelectTag() {
    const {onSelectTag} = this.props;
    if (onSelectTag) {
      const {tag} = this.props;
      onSelectTag(tag);
    }
  }

  render(): React.Node {
    const {tag} = this.props;
    return (
      <ListGroup.Item action className="no-border-link" onClick={this.onSelectTag}>
        <div className="tag-suggestion-item paddingTopBottom-8">
          {renderUserAvatar(tag.avatar, tag.defaultAvatar, 32)}
          <div className="content">
            <span className="full-name">{tag.name}</span>
          </div>
        </div>
      </ListGroup.Item>
    );
  }
}

export default TagSuggestionItem;
