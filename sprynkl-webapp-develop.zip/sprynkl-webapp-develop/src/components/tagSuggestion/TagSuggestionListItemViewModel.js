/**
 * @format
 * @flow
 */

import {User} from '../../models';
import {isTag} from '../../utils/regex';
import {getTagAttrValue} from '../../utils/string';

export class TagSuggestionListItemViewModel {
  id: string = '';

  avatar: string = '';

  defaultAvatar: string = '';

  name: string = '';

  metaData: string = '';

  static map(user: User): TagSuggestionListItemViewModel {
    const tag = new TagSuggestionListItemViewModel();
    tag.id = user.id;
    tag.avatar = user.avatar;
    tag.defaultAvatar = user.defaultAvatar;
    tag.name = user.fullName;
    tag.metaData = `<tag id="${user.id}" name="${user.fullName}" />`;
    return tag;
  }

  static parseTag(tagComment: string): TagSuggestionListItemViewModel {
    if (!isTag(tagComment)) {
      return null;
    }
    const tag = new TagSuggestionListItemViewModel();
    tag.id = getTagAttrValue(tagComment, 'id');
    tag.name = getTagAttrValue(tagComment, 'name');
    return tag;
  }
}
