/**
 * @format
 * @flow
 */
import React, {Component} from 'react';
import {Overlay, ListGroup} from 'react-bootstrap';
import autobind from 'autobind-decorator';
import {TagVM, TagSuggestionItem} from '.';
import './TagSuggestion.scss';
import {DynamicPopover} from '../baseComponents';

type PropsType = {
  popOverVisible: boolean,
  popOverTarget: {},
  popOverContainer: {},
  tags: TagVM[],
  onSelectTag: void,
  onHide: void,
  offsetStyle: {}
};

class TagSuggestionPopover extends Component<PropsType> {
  @autobind
  onSelectTag(tag: TagVM) {
    const {onSelectTag} = this.props;
    if (onSelectTag) {
      onSelectTag(tag);
    }
  }

  @autobind
  onHide() {
    const {onHide} = this.props;
    if (onHide) {
      onHide();
    }
  }

  @autobind
  renderListItems(): React.Node {
    const {tags} = this.props;
    const nodes = [];
    tags.forEach((tag: TagVM, index: number) => {
      nodes.push(<TagSuggestionItem tag={tag} key={index} onSelectTag={this.onSelectTag} />);
    });
    return nodes;
  }

  render(): React.Node {
    const {tags, popOverVisible, popOverTarget, popOverContainer, offsetStyle} = this.props;
    const {length} = tags;

    const itemHeight = tags.length * 48;

    return length === 0 ? null : (
      <Overlay show={popOverVisible} target={popOverTarget} container={popOverContainer} rootClose onHide={this.onHide}>
        {(...props: {}): React.Node => (
          <DynamicPopover
            {...props}
            offsetLeft={offsetStyle.left}
            offsetTop={offsetStyle.top - itemHeight - 20}
            className="tag-suggestion-popover"
          >
            <ListGroup variant="flush">{this.renderListItems()}</ListGroup>
          </DynamicPopover>
        )}
      </Overlay>
    );
  }
}

export default TagSuggestionPopover;
