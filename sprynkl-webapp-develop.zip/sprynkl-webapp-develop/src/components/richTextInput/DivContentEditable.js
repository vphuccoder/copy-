// @flow
import React, {Component} from 'react';
import autobind from 'autobind-decorator';

type PropsType = {
  caretPosition: number
};

class DivContentEditable extends Component<PropsType, StateType> {
  @autobind
  getEl(): HTMLElement {
    const {innerRef} = this.props;
    return innerRef.current;
  }

  @autobind
  setCaretPosition(el: HTMLElement, position: number): number {
    // Loop through all child nodes
    for (const node of el.childNodes) {
      if (node.nodeType === 3) {
        // we have a text node
        if (node.length >= position) {
          // finally add our range
          const range = document.createRange();
          const sel = window.getSelection();
          range.setStart(node, position);
          range.collapse(true);
          sel.removeAllRanges();
          sel.addRange(range);
          el.focus();
          return -1; // we are done
        } else {
          position -= node.length;
        }
      } else {
        position = this.setCaretPosition(node, position);
        if (position === -1) {
          return -1; // no need to finish the for loop
        }
      }
    }
    return position; // needed because of recursion stuff
  }

  componentDidUpdate() {
    const el = this.getEl();
    if (!el) {
      return;
    }
    const {caretPosition} = this.props;
    this.setCaretPosition(el, caretPosition);
  }

  @autobind
  emitChange(originalEvt: React.SyntheticEvent<>) {
    const el = this.getEl();
    if (!el) {
      return;
    }
    const {onChange} = this.props;
    onChange(originalEvt);
  }

  @autobind
  onKeyDown(event: {}) {
    const {onKeyDown} = this.props;
    if (onKeyDown) {
      onKeyDown(event);
    }
  }

  render(): React.Node {
    const {html, innerRef, children, ...props} = this.props;

    const divProps = Object.assign({}, props);
    delete divProps.caretPosition;

    // eslint-disable-next-line react/no-danger-with-children
    return React.createElement(
      'div',
      {
        ...divProps,
        ref: innerRef,
        onInput: this.emitChange,
        onKeyDown: this.onKeyDown,
        contentEditable: true,
        dangerouslySetInnerHTML: {__html: html}
      },
      children
    );
  }
}

export default DivContentEditable;
