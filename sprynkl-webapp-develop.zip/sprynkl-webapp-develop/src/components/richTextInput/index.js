import RichTextInput from './RichTextInput';

export {RichTextInput};
