// @flow
import {observable, action} from 'mobx';
import {TAG_KEYWORK, HASHTAG_KEYWORK} from '../../models/constants/system';
import {HashTagViewModel} from '../richText';
import {TagVM} from '../tagSuggestion';
import {hashtagRuleRegExp} from '../../utils/regex';
import autobind from 'autobind-decorator';

class RichTextInputViewModel {
  tagSuggestionList = null;

  tagFilterList: TagVM[] = [];

  @observable
  selectedTag: TagVM = null;

  selectedTags = [];

  allowTag: boolean = false;

  allowHashTag: boolean = true;

  displayContent: string = '';

  rawContent: string = '';

  hashTags: string[] = [];

  @observable
  markupHtml: string = '';

  @observable
  tagPopupVisible: boolean = false;

  popOverTarget = null;

  caretStartPos: number = 0;

  caretEndPos: number = 0;

  searchString: string = '';

  offsetStyle: {} = {left: 0, top: 0};

  @action
  reset() {
    this.markupHtml = '';
    this.searchString = '';
    this.caretEndPos = 0;
    this.caretStartPos = 0;
    this.tagPopupVisible = false;
    this.selectedTags = [];
    this.tagFilterList = [];
  }

  @autobind
  updateTagSuggestionList(list: TagVM[]) {
    this.tagSuggestionList = new Set([...list]);
  }

  @action
  updateMarkupHtml(markupHtml: string) {
    this.markupHtml = markupHtml;
  }

  @autobind
  updateCaretPosition(position: {}) {
    this.caretStartPos = position.start;
    this.caretEndPos = position.end;
  }

  @autobind
  filterTag() {
    const strAtCaret = this.displayContent.substring(0, this.caretStartPos);
    const lastIndexOfTag = strAtCaret.lastIndexOf(TAG_KEYWORK);
    const filterStr = strAtCaret.substring(lastIndexOfTag + 1);
    this.tagPopupVisible = false;
    if (lastIndexOfTag >= 0 && filterStr.length > 0) {
      this.filter(filterStr);
    }
  }

  @action
  transformInputContent() {
    this.hashTags = [];
    this.rawContent = this.displayContent;

    if (this.allowTag) {
      this.selectedTags.forEach((tag: TagVM) => {
        this.rawContent = this.rawContent.replace(`${TAG_KEYWORK}${tag.name}`, tag.metaData);
      });
    }

    this.hashTags = [];
    this.rawContent = this.rawContent.replace(
      hashtagRuleRegExp,
      (substring: string): string => {
        const idx = substring.lastIndexOf(HASHTAG_KEYWORK);
        const prefix = substring.substr(0, idx);
        const suffix = substring.substr(idx + 1);
        this.hashTags.push(suffix);
        return prefix.concat(HashTagViewModel.hashtagMeta(suffix));
      }
    );
  }

  @autobind
  isPlainText(): boolean {
    if (this.allowHashTag || this.allowTag) {
      return false;
    }
    return true;
  }

  @autobind
  getExtraData(): {} {
    return {
      textContent: this.displayContent,
      hashTags: this.hashTags,
      tags: this.selectedTags.map((tag: TagVM): string => tag.id)
    };
  }

  @autobind
  formatContent(content: string): string {
    return content.replace('&nbsp;', ' ');
  }

  @action
  filter(keyword: string) {
    if (keyword.trim().length === 0) {
      this.tagPopupVisible = false;
      return;
    }

    this.searchString = keyword;
    let popupVisible = false;

    // find matching tags
    const tagSuggestionArray = [...this.tagSuggestionList];
    const matchingTags = tagSuggestionArray.filter((tag: TagVM): boolean => this.isExists(keyword, tag.name));

    // sort
    if (matchingTags.length > 0) {
      this.tagFilterList = matchingTags.sort(
        (a: TagVM, b: TagVM): number => {
          const aTagName: string = a.name.toLowerCase();
          const bTagName: string = b.name.toLowerCase();
          if (aTagName > bTagName) {
            return 1;
          }
          if (aTagName < bTagName) {
            return -1;
          }
          return 0;
        }
      );

      popupVisible = true;
    }

    // show/not show popup
    this.tagPopupVisible = popupVisible;
  }

  @autobind
  isExists(keyword: string, searchStr: string): boolean {
    const lowerKeyword = keyword.toLowerCase();
    const lowerSearchStr = searchStr.toLowerCase();

    if (lowerSearchStr.indexOf(lowerKeyword) === 0) {
      // match at begin
      return true;
    }

    if (lowerSearchStr.indexOf(' '.concat(lowerKeyword)) >= 0) {
      return true;
    }

    return false;
  }

  @autobind
  addSelectTagToList(tag: TagVM) {
    this.removeSelectTagOutOfList(tag);
    this.selectedTags.push(tag);
  }

  @autobind
  removeSelectTagOutOfList(tag: TagVM) {
    this.selectedTags = this.selectedTags.filter((t: TagVM): boolean => t.id !== tag.id);
  }

  @action
  onSelectTag(tag: TagVM) {
    // hide popup and track selected tag
    this.tagPopupVisible = false;

    // remove out of suggestion list and add to tracking list
    this.removeTagOutOfSuggestionList(tag);
    this.addSelectTagToList(tag);

    // update display content
    const contentAtCaret = this.displayContent.substring(0, this.caretStartPos - this.searchString.length);
    const contentAfterCaret = this.displayContent.substring(this.caretEndPos);
    this.displayContent = contentAtCaret.concat(tag.name).concat(contentAfterCaret);

    // update caret position
    this.caretStartPos = contentAtCaret.indexOf(TAG_KEYWORK) + tag.name.length + 1;
  }

  @autobind
  onRemoveTag(tagName: string) {
    if (this.selectedTags.length === 0) {
      return;
    }

    const {selectedTags, displayContent, caretStartPos} = this;
    const deletedTag = selectedTags.find((tag: TagVM): boolean => tag.name === tagName.substring(1).trim()); // remove @
    if (!deletedTag) {
      return;
    }

    // remove out of tracking list and add again to suggestion list
    this.removeSelectTagOutOfList(deletedTag);
    this.addTagToSuggestionList(deletedTag);

    // update display content
    const contentAtCaret = displayContent.substring(0, caretStartPos);
    const lastIndexOfTag = contentAtCaret.lastIndexOf(TAG_KEYWORK);
    const contentAtTag = displayContent.substring(0, lastIndexOfTag);
    const contentAfterTag = displayContent.substring(lastIndexOfTag + tagName.length);
    this.displayContent = contentAtTag.concat(contentAfterTag);
    this.caretStartPos = lastIndexOfTag;
  }

  @autobind
  addTagToSuggestionList(tag: TagVM) {
    this.tagSuggestionList.add(tag);
  }

  @autobind
  removeTagOutOfSuggestionList(tag: TagVM) {
    this.tagSuggestionList.delete(tag);
  }
}

export default RichTextInputViewModel;
