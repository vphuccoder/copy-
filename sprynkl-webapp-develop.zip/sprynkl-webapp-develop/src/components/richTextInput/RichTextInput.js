// @flow
import React, {Component, Fragment} from 'react';
import ReactDOMServer from 'react-dom/server';
import autobind from 'autobind-decorator';
import {hashtagRegExp, isHashTag, isTag, tagRegExp} from '../../utils/regex';
import RichTextInputViewModel from './RichTextInputViewModel';
import {HashTagViewModel as HashTagVM, HashTag, Tag, TAG_STATUS} from '../richText';
import {TagVM, TagSuggestionPopover} from '../tagSuggestion';
import {observer} from 'mobx-react';
import DivContentEditable from './DivContentEditable';
import './RichTextInput.scss';

type PropsType = {
  onSubmit: void,
  tagUserList: TagVM[],
  allowTag: boolean
};

@observer
class RichTextInput extends Component {
  viewModel: RichTextInputViewModel;

  constructor(props: PropsType) {
    super(props);

    this.richTextInputRef = React.createRef();

    const {tagUserList, allowTag} = this.props;
    this.viewModel = new RichTextInputViewModel();
    this.viewModel.updateTagSuggestionList(tagUserList);
    this.viewModel.allowTag = allowTag || false;
  }

  componentWillReceiveProps(nextProps: PropsType) {
    const {viewModel} = this;
    viewModel.updateTagSuggestionList(nextProps.tagUserList);
  }

  @autobind
  focusRichTextInput() {
    if (this.richTextInputRef && this.richTextInputRef.current) {
      this.richTextInputRef.current.focus();
    }
  }

  @autobind
  onHidePopover() {
    const {viewModel} = this;
    viewModel.tagPopupVisible = false;
  }

  @autobind
  getTagNode(): Node {
    const selection = window.getSelection();
    const {focusNode} = selection;
    const {parentNode} = focusNode;
    if (parentNode && parentNode.className === 'tag-active') {
      return parentNode;
    }
    return null;
  }

  @autobind
  getCurrentCaretPosition() {
    const {viewModel} = this;
    const selection = window.getSelection();
    const {focusNode} = selection;
    const {parentNode} = focusNode;
    if (parentNode) {
      viewModel.offsetStyle = {
        top: parentNode.offsetTop,
        left: parentNode.offsetLeft
      };
    }

    const {rangeCount} = selection;
    if (rangeCount > 0) {
      const range = selection.getRangeAt(0);
      const preCaretRange = range.cloneRange();
      preCaretRange.selectNodeContents(this.richTextInputRef.current);
      preCaretRange.setEnd(range.startContainer, range.startOffset);
      viewModel.caretStartPos = preCaretRange.toString().length;
      preCaretRange.setEnd(range.endContainer, range.endOffset);
      viewModel.caretEndPos = preCaretRange.toString().length;
    }
  }

  @autobind
  onTextChange() {
    const {viewModel} = this;

    this.getCurrentCaretPosition();

    // get display content
    viewModel.displayContent = this.richTextInputRef.current.innerText;

    // re-render rich text input
    this.forceRenderRichTextInput();

    // filter tag
    viewModel.filterTag();
  }

  @autobind
  onKeyDown(event: KeyboardEvent) {
    switch (event.keyCode) {
      case 13:
        if (!event.shiftKey) {
          this.onEnterPress(event);
        }
        break;
      case 8:
        this.onBackspacePress(event);
        break;
      default:
        break;
    }
  }

  @autobind
  onEnterPress(event: KeyboardEvent) {
    event.preventDefault();

    const {viewModel} = this;
    const {rawContent} = viewModel;
    if (rawContent.trim().length === 0) {
      viewModel.reset();
      return;
    }

    const {onSubmit} = this.props;
    if (onSubmit) {
      onSubmit(viewModel.rawContent, viewModel.getExtraData());
    }
    viewModel.reset();
  }

  @autobind
  onBackspacePress(event: KeyboardEvent) {
    const tagNode = this.getTagNode();
    if (tagNode) {
      event.preventDefault();
      const {viewModel} = this;
      viewModel.onRemoveTag(tagNode.textContent);
      this.forceRenderRichTextInput();
    }
  }

  @autobind
  onSelectTag(tag: TagVM) {
    const {viewModel} = this;
    viewModel.onSelectTag(tag);

    this.forceRenderRichTextInput();
    this.focusRichTextInput();
  }

  @autobind
  renderHashTag(hashTag: string, index: number): React.Node {
    if (hashTag.length === 0) {
      return null;
    }

    const hashTagVM = HashTagVM.parseHashTag(hashTag);
    if (hashTagVM) {
      return <HashTag key={`hash_tag_${index}`} hashTag={hashTagVM} />;
    }

    return null;
  }

  @autobind
  renderTag(tag: string, index: number): React.Node {
    const tags = tag.split(tagRegExp);
    return tags.map(
      (text: string, idx: number): React.Node => {
        if (text.length === 0) {
          return null;
        }

        const tagVM = TagVM.parseTag(text);
        if (tagVM) {
          return <Tag key={`${index}_${idx}`} status={TAG_STATUS.ACTIVE} tag={tagVM} />;
        }

        return <span key={`${index}_${idx}`}>{text}</span>;
      }
    );
  }

  @autobind
  renderRichText(): React.Node {
    const {viewModel} = this;
    const {rawContent} = viewModel;
    const rawContents = rawContent.split(hashtagRegExp);
    return rawContents.map(
      (text: string, index: number): React.Node => {
        if (text.length === 0) {
          return null;
        }

        if (isHashTag(text)) {
          return this.renderHashTag(text, index);
        }

        if (viewModel.allowTag && isTag(text)) {
          return this.renderTag(text, index);
        }

        return <span key={index}>{text}</span>;
      }
    );
  }

  @autobind
  renderRichTextInput(): React.Node {
    const {viewModel} = this;
    viewModel.transformInputContent();
    const {rawContent} = viewModel;
    if (rawContent.length === 0) {
      return null;
    }

    if (viewModel.isPlainText()) {
      return <span>{rawContent}</span>;
    }
    return <div className="rich-text">{this.renderRichText()}</div>;
  }

  @autobind
  forceRenderRichTextInput() {
    const {viewModel} = this;
    const richTextInputNodes = this.renderRichTextInput();
    let markupHtml = ReactDOMServer.renderToStaticMarkup(richTextInputNodes);
    // wrap @ string by <span> tag to get top left position when showing popup
    markupHtml = markupHtml.replace(
      /[^>]@[^\s]+/gm,
      (substring: string): string => {
        const result = `<span>${substring}</span>`;
        return result;
      }
    );
    viewModel.updateMarkupHtml(markupHtml);
  }

  render(): React.Node {
    const {viewModel} = this;
    const {tagPopupVisible, tagFilterList, markupHtml, offsetStyle, caretStartPos} = viewModel;
    return (
      <Fragment>
        <TagSuggestionPopover
          tags={tagFilterList}
          popOverVisible={tagPopupVisible}
          popOverTarget={this.richTextInputRef.current}
          onSelectTag={this.onSelectTag}
          popOverContainer={this}
          onHide={this.onHidePopover}
          offsetStyle={offsetStyle}
        />
        <div className="rich-text-input-container">
          <DivContentEditable
            innerRef={this.richTextInputRef}
            html={markupHtml}
            onChange={this.onTextChange}
            className="rich-text-input"
            data-placeholder="Write a comment..."
            onKeyDown={this.onKeyDown}
            caretPosition={caretStartPos}
          />
        </div>
      </Fragment>
    );
  }
}

export default RichTextInput;
