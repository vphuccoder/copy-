import React, {Component} from 'react';
import {URL_ABOUT_US, URL_HELP_CENTER} from '../../configs';
import './footer.scss';

class AppFooter extends Component {
  render() {
    const {color, style} = this.props;
    const colorStyle = {
      color
    };
    const currentYear = 2019;
    return (
      <div className="footer" style={{...style, ...colorStyle}}>
        <div>
          <a href={URL_ABOUT_US} style={colorStyle}>
            <span>About Us</span>
          </a>
          <span> • </span>
          <a href={URL_HELP_CENTER} style={colorStyle}>
            <span>Support</span>
          </a>
          <span> • </span>
          <span>© {currentYear} Sprynkl</span>
        </div>
      </div>
    );
  }
}

export default AppFooter;
