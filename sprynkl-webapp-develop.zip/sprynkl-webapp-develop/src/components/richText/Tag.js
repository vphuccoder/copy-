// @flow
import React from 'react';
import autobind from 'autobind-decorator';
import {TagVM} from '../tagSuggestion';
import {TAG_KEYWORK} from 'models/constants/system';

export const TAG_STATUS = {
  ACTIVE: 'active',
  INACTIVE: 'inactive'
};

type PropsType = {
  status: string,
  tag: TagVM,
  onClickTag: void
};

class Tag extends React.Component<PropsType> {
  render(): React.Node {
    const {status, tag} = this.props;
    const tagName = `${TAG_KEYWORK}${tag.name}`;
    if (status === TAG_STATUS.ACTIVE) {
      return this.renderActiveTag(tagName);
    }
    return this.renderInactiveTag(tagName);
  }

  @autobind
  renderActiveTag(tagName: string): React.Node {
    return (
      <a onClick={this.onClickTag} className="tag-active">
        {tagName}
      </a>
    );
  }

  @autobind
  renderInactiveTag(tagName: string): React.Node {
    return <span className="tag-inactive">{tagName}</span>;
  }

  @autobind
  onClickTag() {
    const {onClickTag, tag} = this.props;
    if (onClickTag) {
      onClickTag(tag);
    }
  }
}

export default Tag;
