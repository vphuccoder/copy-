/**
 * @flow
 * @format
 */
import { isHashTag } from "../../utils/regex";
import { getTagAttrValue } from "../../utils/string";

export class HashTagViewModel {
  name: string = "";

  metaData: string = "";

  static map(data: {}): HashTagViewModel {
    if (!data) {
      return null;
    }
    const hashTag = new HashTagViewModel();
    hashTag.name = data.name;
    hashTag.metaData = `<hashtag name="${data.name}" />`;
    return hashTag;
  }

  static parseHashTag(content: string): HashTagViewModel {
    if (!isHashTag(content)) {
      return null;
    }
    const hashTag = new HashTagViewModel();
    hashTag.name = getTagAttrValue(content, "name");
    return hashTag;
  }

  static hashtagMeta(content: string): string {
    return `<hashtag name="${content}" />`;
  }
}
