/**
 * @flow
 * @format
 */
import autobind from 'autobind-decorator';
import {observer} from 'mobx-react';
import {HASHTAG_KEYWORK} from 'models/constants/system';
import React from 'react';
import {HashTag, HashTagViewModel as HashTagVM, TAG_STATUS, Tag} from '.';
import {User} from '../../models';
import {hashtagRegExp, isHashTag, isTag, isURL, tagRegExp, urlReg} from '../../utils/regex';
import {TagVM} from '../tagSuggestion';
import './RichText.scss';

type PropsType = {
  activeUserList: User[],
  content: string,
  onClickHashTag: void,
  onClickTag: void
};

@observer
class RichText extends React.Component<PropsType> {
  render(): React.Node {
    const {content} = this.props;
    if (isTag(content) || isHashTag(content) || isURL(content)) {
      return (
        <span className="rich-text" key={`rich_text_${Math.random()}`}>
          {this.renderRichText(content)}
        </span>
      );
    }
    return <span>{this.renderPureContent(content)}</span>;
  }

  @autobind
  renderPureContent(content: string): React.Node {
    return content.split('\n').map(
      (item: string, index: number): React.Node => {
        return (
          <React.Fragment key={index}>
            {index !== 0 && <br key={`${Math.random()}`} />}
            <span className="rich-text" key={`${Math.random()}`}>
              {item}{' '}
            </span>
          </React.Fragment>
        );
      }
    );
  }

  @autobind
  formatUrl(url: string): string {
    if (url.indexOf('http') < 0 && url.indexOf('https') < 0) {
      return `http://${url}`;
    }
    return url;
  }

  @autobind
  renderURL(content: string, key: number): React.Node {
    const urlContents = content.split(urlReg);
    return urlContents.map(
      (subContent: string, index: number): React.Node => {
        if (isURL(subContent)) {
          return (
            <a
              href={this.formatUrl(subContent)}
              key={`${key}_${index}`}
              rel="noopener noreferrer"
              target="_blank"
            >
              {`${subContent} `}
            </a>
          );
        }
        return this.renderPureContent(subContent);
      }
    );
  }

  @autobind
  renderRichText(content: string): React.Node {
    const {activeUserList} = this.props;
    let tagSuggestionList = [];
    if (activeUserList) {
      tagSuggestionList =
        activeUserList && activeUserList.map((user: User): TagVM => TagVM.map(user));
    }

    const tagContents = content.split(tagRegExp);
    return tagContents.map(
      (tag: string, index: number): React.Node => {
        if (tag === '') {
          return null;
        }
        const urlContents = tag.split(urlReg);
        return urlContents.map(
          (url: string, index2: number): React.Node => {
            if (url === '') {
              return null;
            }

            if (isTag(url)) {
              return this.renderTag(url, tagSuggestionList, `${index}_${index2}`);
            }

            if (isHashTag(url)) {
              return this.renderHashTag(url, `${index}_${index2}`);
            }

            if (isURL(url)) {
              return this.renderURL(url, `${index}_${index2}_${Math.random()}`);
            }

            return this.renderPureContent(url);
          }
        );
      }
    );
  }

  @autobind
  renderTag(tag: string, tagSuggestionList: TagVM[], index: number): React.Node {
    const tagVM = TagVM.parseTag(tag);

    if (!tagVM) {
      return null;
    }

    let status = TAG_STATUS.INACTIVE;
    const activeTag = tagSuggestionList.find((item: TagVM): boolean => tagVM.id === item.id);
    if (activeTag) {
      tagVM.name = activeTag.name;
      status = TAG_STATUS.ACTIVE;
    }

    return <Tag key={index} onClickTag={this.onClickTag} status={status} tag={tagVM} />;
  }

  @autobind
  renderHashTag(content: string, index: number): React.Node {
    const hashTags = content.split(hashtagRegExp);
    return hashTags.map(
      (hashTag: string, idx: number): React.Node => {
        if (hashTag.length === 0) {
          return null;
        }

        const hashTagVM = HashTagVM.parseHashTag(hashTag);
        if (hashTagVM) {
          return (
            <HashTag
              hashTag={hashTagVM}
              key={`${index}_${idx}`}
              onClickHashTag={this.onClickHashTag}
            />
          );
        }

        return this.renderPureContent(hashTag);
      }
    );
  }

  @autobind
  onClickTag(tag: TagVM) {
    const {activeUserList, onClickTag} = this.props;
    if (onClickTag) {
      const taggedUser = activeUserList.find((user: User): boolean => user.id === tag.id);
      onClickTag(taggedUser);
    }
  }

  @autobind
  onClickHashTag(hashTag: HashTagVM) {
    const {onClickHashTag} = this.props;
    if (onClickHashTag) {
      onClickHashTag(`${HASHTAG_KEYWORK}${hashTag.name}`);
    }
  }
}

export default RichText;
