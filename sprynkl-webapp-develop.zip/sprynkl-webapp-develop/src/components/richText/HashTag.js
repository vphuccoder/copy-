// @flow
import autobind from 'autobind-decorator';
import React from 'react';
import {HashTagViewModel as HashTagVM} from '.';
import {HASHTAG_KEYWORK} from '../../models/constants/system';

type PropsType = {
  hashTag: HashTagVM,
  onClickHashTag: void
};

class HashTag extends React.Component<PropsType> {
  render(): React.Node {
    const {hashTag} = this.props;
    return (
      <a className="hash-tag" onClick={this.onClickHashTag}>
        <span>{`${HASHTAG_KEYWORK}${hashTag.name}`}</span>
      </a>
    );
  }

  @autobind
  onClickHashTag() {
    const {onClickHashTag, hashTag} = this.props;
    if (onClickHashTag) {
      onClickHashTag(hashTag);
    }
  }
}

export default HashTag;
