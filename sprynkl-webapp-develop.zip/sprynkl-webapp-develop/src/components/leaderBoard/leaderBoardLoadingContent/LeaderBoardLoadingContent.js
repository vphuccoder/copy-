// @flow

import React from 'react';
import autobind from 'autobind-decorator';
import {LeaderBoardLoadingItem} from '../../baseComponents/svg/Svg';
import './LeaderBoardLoadingContent.scss';

type PropsType = {};

type StateType = {};

class LeaderBoardLoadingContent extends React.Component<PropsType, StateType> {
  @autobind
  renderLoadingPattern(): React.Node {
    return <LeaderBoardLoadingItem />;
  }

  render(): React.Node {
    return (
      <div className="leader-board-loading-content">
        {this.renderLoadingPattern()}
        <div className="leader-board-loading-content-separator" />
        {this.renderLoadingPattern()}
        <div className="leader-board-loading-content-separator" />
        {this.renderLoadingPattern()}
        <div className="leader-board-loading-content-separator" />
      </div>
    );
  }
}

export default LeaderBoardLoadingContent;
