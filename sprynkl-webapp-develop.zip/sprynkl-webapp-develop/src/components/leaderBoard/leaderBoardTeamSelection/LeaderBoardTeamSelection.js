// @flow

import React, {Component} from 'react';
import autobind from 'autobind-decorator';
import {observer} from 'mobx-react';
import {Dropdown} from 'react-bootstrap';
import {icons} from '../../themes/Icons';
import Icon from '../../baseComponents/Icon';
import LeaderBoardTeamItem from './LeaderBoardTeamItem';
import TeamSelectionToggle from '../../baseComponents/CustomSelectToggle';
import TextOverFlow from '../../baseComponents/textOverFlow/TextOverFlow';
import {Group} from '../../../models';
import './LeaderBoardTeamSelection.scss';

type PropsType = {};

@observer
class LeaderBoardTeamSelection extends Component<PropsType> {
  @autobind
  selectTeam(group: Group) {
    const {selectTeam} = this.props;
    if (selectTeam) {
      selectTeam(group);
    }
  }

  renderGroups(): React.Node {
    const {groups, selectedGroup} = this.props;
    if (groups && groups.length) {
      return groups.map(
        (item: {}): React.Node => {
          if (selectedGroup && selectedGroup.id === item.group.id) {
            return null;
          }
          return <LeaderBoardTeamItem item={item} key={item.group.id} selectTeam={this.selectTeam} />;
        }
      );
    }
  }

  renderSelectGroup(): React.Node {
    const {selectedGroup} = this.props;
    if (selectedGroup) {
      return <TextOverFlow className="group-name" textOverflow={selectedGroup.name} placement="right" />;
    }

    return <span>{'All Team'}</span>;
  }

  @autobind
  selectAllTeam() {
    this.selectTeam();
  }

  renderSelectAll(): React.Node {
    const {selectedGroup, groups} = this.props;
    if (selectedGroup && groups.length > 1) {
      return (
        <Dropdown.Item className="dropdown-item" key={'all_team'} onClick={this.selectAllTeam}>
          {'All Team'}
        </Dropdown.Item>
      );
    }
  }

  render(): React.Node {
    const {groups} = this.props;
    return (
      <div className="leader-board-selection-team">
        <Dropdown>
          <Dropdown.Toggle className="dropdown-toggle" as={TeamSelectionToggle}>
            {this.renderSelectGroup()}
            {groups && groups.length > 1 && (
              <div className="dropdown-icon">
                <Icon color={'#777b7d'} size={30} iconName={icons.angleDown} />
              </div>
            )}
          </Dropdown.Toggle>
          {groups && groups.length > 1 && (
            <Dropdown.Menu className="dropdown-menu">
              {this.renderSelectAll()}
              {this.renderGroups()}
            </Dropdown.Menu>
          )}
        </Dropdown>
      </div>
    );
  }
}

export default LeaderBoardTeamSelection;
