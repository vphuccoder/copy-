// @flow
import React, {PureComponent} from 'react';
import {Dropdown} from 'react-bootstrap';
import autobind from 'autobind-decorator';
import TextOverFlow from '../../baseComponents/textOverFlow/TextOverFlow';
import './LeaderBoardTeamSelection.scss';

class LeaderBoardTeamItem extends PureComponent {
  @autobind
  selectTeam() {
    const {selectTeam, item} = this.props;
    if (selectTeam && item) {
      selectTeam(item.group);
    }
  }

  render(): React.Node {
    const {item} = this.props;
    const {group} = item;
    return (
      <Dropdown.Item className="dropdown-item" key={group.id} onClick={this.selectTeam}>
        <div className="dropdown-text">
          <TextOverFlow className="group-name" tooltip={group.name} textOverflow={`Switch to ${group.name}`}>
            <div className="group-name-text" title={group.name}>
              <span className="group-text">{'Switch to'}</span>
              <span className="group-name">{` ${group.name}`}</span>
            </div>
          </TextOverFlow>
        </div>
      </Dropdown.Item>
    );
  }
}

export default LeaderBoardTeamItem;
