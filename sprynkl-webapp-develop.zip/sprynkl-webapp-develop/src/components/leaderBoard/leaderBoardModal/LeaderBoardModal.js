// @flow
import React from 'react';
import {observer} from 'mobx-react';
import autobind from 'autobind-decorator';
import {LeaderBoard, FocusedLeaderBoard} from '../../baseComponents/svg/Icons';
import {LeaderBoardMemberListView} from '../leaderBoardMemberList';
import {ModalConsumer} from '../../context';
import './LeaderBoardModal.scss';

type PropsType = {};

type StateType = {
  isFocused: boolean
};

@observer
class LeaderBoardModal extends React.Component<PropsType, StateType> {
  constructor(props: PropsType) {
    super(props);
    this.state = {
      isFocused: false
    };
  }

  @autobind
  onClickLeaderBoardItem() {
    this.setState({isFocused: true});
  }

  @autobind
  onExit() {
    this.setState({isFocused: false});
  }

  render(): React.Node {
    return (
      <ModalConsumer>
        {({showModal, hideModal}: {}): React.Node => (
          <div
            className="show-leader-board-modal"
            onClick={(): {} => {
              this.onClickLeaderBoardItem();
              showModal(LeaderBoardMemberListView, {
                hideModal: () => {
                  this.onExit();
                  hideModal();
                },
                dialogClassName: 'show-leader-board-modal-dialog'
              });
            }}
          >
            <div className="leader-board-icon">{this.state.isFocused ? <FocusedLeaderBoard /> : <LeaderBoard />}</div>
          </div>
        )}
      </ModalConsumer>
    );
  }
}

export default LeaderBoardModal;
