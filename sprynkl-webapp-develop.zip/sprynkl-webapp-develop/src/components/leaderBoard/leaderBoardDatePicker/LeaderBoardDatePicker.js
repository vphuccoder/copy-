// @flow

import React from 'react';
import {observer} from 'mobx-react';
import autobind from 'autobind-decorator';
import DateTimePicker from '../../baseComponents/datePicker/DatePicker';
import './LeaderBoardDatePicker.scss';

type PropsType = {};

type StateType = {
  startDate: Date,
  endDate: Date
};

@observer
class LeaderBoardDatePicker extends React.Component<PropsType, StateType> {
  constructor(props: PropsType) {
    super(props);
    this.state = {
      startDate: null,
      endDate: null
    };
  }

  componentDidMount() {
    const {viewModel} = this.props;
    const {timeFrom, timeEnd} = viewModel;
    this.setState({startDate: timeFrom, endDate: timeEnd});
  }

  @autobind
  handleChangeStart(value: Date) {
    this.setState({startDate: value});
  }

  @autobind
  handleChangeEnd(value: Date) {
    this.setState({endDate: value});
  }

  @autobind
  onSubmit() {
    const {onSetDate, viewModel} = this.props;
    const {startDate, endDate} = this.state;
    viewModel.setTime(startDate, endDate);
    if (onSetDate) {
      onSetDate();
    }
  }

  @autobind
  onCancel() {
    const {onCancel} = this.props;
    if (onCancel) {
      onCancel();
    }
  }

  @autobind
  onClickButton() {
    const {startDate, endDate} = this.state;
    if (startDate && endDate) {
      this.onSubmit();
    } else {
      this.onCancel();
    }
  }

  @autobind
  renderButton(): React.Node {
    const {startDate, endDate} = this.state;
    const btName = startDate && endDate ? 'Set' : 'Cancel';
    return (
      <div className="leader-board-date-picker-header" onClick={this.onClickButton}>
        <span className="leader-board-date-picker-header-text">{btName}</span>
      </div>
    );
  }

  render(): React.Node {
    const {startDate, endDate} = this.state;
    return (
      <div className="leader-board-date-picker">
        <div className="leader-board-date-picker-calendar">
          <DateTimePicker
            placeholderText="From"
            className="leader-board-date-time-picker"
            dateFormat="MMM dd, yyyy"
            selected={startDate}
            selectsStart
            startDate={startDate}
            endDate={endDate}
            onChange={this.handleChangeStart}
            maxDate={endDate ? endDate : new Date()}
            isClearable
            showYearDropdown
            dropdownMode="scroll"
          />
          <div> - </div>
          <DateTimePicker
            placeholderText={'To'}
            className="leader-board-date-time-picker"
            dateFormat="MMM dd, yyyy"
            selected={endDate}
            selectsEnd
            startDate={startDate}
            endDate={endDate}
            onChange={this.handleChangeEnd}
            minDate={startDate}
            maxDate={new Date()}
            isClearable
            showYearDropdown
            dropdownMode="scroll"
          />
        </div>

        {this.renderButton()}
      </div>
    );
  }
}

export default LeaderBoardDatePicker;
