// @flow

import {action, computed, observable, runInAction} from 'mobx';
import autobind from 'autobind-decorator';
import {BasePageViewModel} from '../../../pages/BasePageViewModel';
import {appModel} from '../../../models/app-model';
import {groupService} from '../../../services';
import {Group, User} from '../../../models';
import {dateStringToTimeStamp} from '../../../utils/utils';
import {shortMonths} from '../../../utils/string';

class LeaderBoardMemberListViewModel extends BasePageViewModel {
  @observable
  userKarmaList: Array = [];

  @observable
  joinGroups: Array = [];

  @observable
  selectedGroup: Group;

  @observable
  timeFrom: Date = null;

  @observable
  timeEnd: Date = null;

  @observable
  isUserChooseDefaultFilterDay: boolean = true;

  @observable
  isLoadingKarmaList: boolean = false;

  @observable
  isShowTimeModal: boolean = false;

  constructor() {
    super();
    this.setUserGroups();
  }

  @action
  resetData() {
    this.userKarmaList = [];
    this.setSelectedGroup(null);
    this.timeFrom = null;
    this.timeEnd = null;
    this.isUserChooseDefaultFilterDay = true;
    this.isLoadingKarmaList = false;
    this.isShowTimeModal = false;
  }

  @action
  setUserChooseDefaultFilterDay(value: boolean) {
    this.isUserChooseDefaultFilterDay = value;
  }

  @action
  showTimeModal(value: boolean) {
    this.isShowTimeModal = value;
  }

  @autobind
  setJoinGroups(groups: []) {
    this.joinGroups = groups;
  }

  @action
  setSelectedGroup(group: Group) {
    this.selectedGroup = group;
  }

  @action
  setUserGroups() {
    const user = appModel.currentUser;
    const groups = user.getJoinedUserGroup();
    if (appModel.currentGroup) {
      this.setSelectedGroup(appModel.currentGroup);
      this.setJoinGroups(groups);
    } else if (groups.length === 1) {
      this.selectedGroup = groups[0].group;
    } else {
      this.setJoinGroups(groups);
    }
  }

  @computed
  get isAllTeam(): boolean {
    return !this.selectedGroup;
  }

  @action
  setTime(startDate: Date, endDate: Date) {
    this.timeFrom = startDate;
    this.timeEnd = endDate;
  }

  @autobind
  getTime(date: Date): {} {
    return {
      date: date.getDate().toString(),
      month: (date.getMonth() + 1).toString(),
      year: date.getFullYear().toString()
    };
  }

  @action
  async getLeaderBoardByGroupId(timeFrom: number, timeEnd: number) {
    const {accessToken} = appModel.currentToken;
    if (this.selectedGroup) {
      try {
        this.isLoadingKarmaList = true;
        const data = await groupService.getLeaderBoard(accessToken, this.selectedGroup.id, timeFrom, timeEnd);
        runInAction(() => {
          this.userKarmaList = data.sort((user1: User, user2: User): number => user2.karma - user1.karma);
        });
        this.isLoadingKarmaList = false;
      } catch (e) {
        this.handleError(e, true);
      }
    } else {
      this.selectedGroup = null;
      this.userKarmaList = [];
    }
  }

  // last 30 day
  @action
  async resetDefaultFilterDay(): Promise {
    const timeEnd = new Date();
    const timeEndObj = this.getTime(timeEnd);
    const timeEndStamp = dateStringToTimeStamp(timeEndObj.date, timeEndObj.month, timeEndObj.year, 23, 59, 59);
    const timeFromLast30Days = timeEndStamp - 30 * 24 * 3600 * 1000;

    await this.getLeaderBoardByGroupId(timeFromLast30Days, timeEndStamp);
  }

  @action
  async updateData(): Promise {
    if (this.isUserChooseDefaultFilterDay) {
      await this.resetDefaultFilterDay();
    } else {
      const {timeFrom, timeEnd} = this;
      const timeFromObj = this.getTime(timeFrom);
      const timeEndObj = this.getTime(timeEnd);

      const timeStampFrom = dateStringToTimeStamp(timeFromObj.date, timeFromObj.month, timeFromObj.year);
      const timeStampTo = dateStringToTimeStamp(timeEndObj.date, timeEndObj.month, timeEndObj.year, 23, 59, 59);
      await this.getLeaderBoardByGroupId(timeStampFrom, timeStampTo);
    }
  }

  @autobind
  getDayString(day: string): string {
    if (day.length === 1) {
      return `0${day}`;
    }
    return day;
  }

  @autobind
  getTimeString(date: Date): string {
    const timeObj = this.getTime(date);
    const nowYear = new Date().getFullYear().toString();

    const dateStr = this.getDayString(timeObj.date);
    const monthStr = shortMonths[timeObj.month - 1];
    const yearStr = timeObj.year === nowYear ? '' : timeObj.year;

    return ` ${monthStr} ${dateStr}${yearStr !== '' ? ',' : ''} ${yearStr.substr(2, 2)}`;
  }

  @action
  buildTimeString(): string {
    if (this.isUserChooseDefaultFilterDay) {
      return 'Last 30 days';
    }

    const finalTime = `${this.getTimeString(this.timeFrom)} - ${this.getTimeString(this.timeEnd)}`;
    return finalTime;
  }
}

export default LeaderBoardMemberListViewModel;
