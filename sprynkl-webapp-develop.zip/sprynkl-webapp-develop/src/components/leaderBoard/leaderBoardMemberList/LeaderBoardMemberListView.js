// @flow

import React from 'react';
import {observer} from 'mobx-react';
import autobind from 'autobind-decorator';
import {Group} from '../../../models';
import LeaderBoardMemberListItem from '../LeaderBoardMemberListItem';
import LeaderBoardHeader from '../leaderBoardHeader/LeaderBoardHeader';
import LeaderBoardAllTeam from '../leaderBoardAllTeam/LeaderBoardAllTeam';
import LeaderBoardMemberListViewModel from './LeaderBoardMemberListViewModel';
import LeaderBoardLoadingContent from '../leaderBoardLoadingContent/LeaderBoardLoadingContent';
import LeaderBoardEmptyState from '../leaderBoardEmptyState/LeaderBoardEmptyState';
import LeaderBoardDatePicker from '../leaderBoardDatePicker/LeaderBoardDatePicker';
import './LeaderBoardMemberListView.scss';

type PropsType = {};

@observer
class LeaderBoardMemberListView extends React.Component<PropsType> {
  constructor(props: PropsType) {
    super(props);
    this.viewModel = new LeaderBoardMemberListViewModel();
  }

  componentDidMount() {
    const {selectedGroup} = this.viewModel;
    if (selectedGroup) {
      this.viewModel.resetDefaultFilterDay();
    }
  }

  @autobind
  async selectTeam(group: Group) {
    this.viewModel.setSelectedGroup(group);
    this.viewModel.updateData();
  }

  @autobind
  closeModalWhenSelectMember() {
    const {hideModal} = this.props;
    hideModal();
  }

  @autobind
  onChooseDefaultTime() {
    this.viewModel.setTime();
    this.viewModel.resetDefaultFilterDay();
    this.viewModel.setUserChooseDefaultFilterDay(true);
  }

  @autobind
  onChooseTimeRange() {
    this.viewModel.showTimeModal(true);
  }

  @autobind
  onSetDate() {
    this.viewModel.setUserChooseDefaultFilterDay(false);
    this.viewModel.updateData();
    this.viewModel.showTimeModal(false);
  }

  @autobind
  onCancelDatePicker() {
    this.viewModel.showTimeModal(false);
  }

  @autobind
  renderLeaderBoardAllTeam(): React.Node {
    this.viewModel.resetData();
    return <LeaderBoardAllTeam />;
  }

  @autobind
  renderLeaderBoardHeader(): React.Node {
    const {joinGroups, selectedGroup} = this.viewModel;
    return (
      <LeaderBoardHeader
        selectedGroup={selectedGroup}
        groups={joinGroups}
        selectTeam={this.selectTeam}
        isAllTeam={this.viewModel.isAllTeam}
        time={this.viewModel.buildTimeString()}
        onChooseDefaultTime={this.onChooseDefaultTime}
        onChooseTimeRange={this.onChooseTimeRange}
      />
    );
  }

  @autobind
  renderMemberItem(item: {}, index: number, isLastIndex: boolean): React.Node {
    const {karma, user} = item;
    return (
      <LeaderBoardMemberListItem
        key={user.id}
        index={index + 1}
        karma={karma}
        user={user}
        beforeSelectUser={this.closeModalWhenSelectMember}
        isLastIndex={isLastIndex}
      />
    );
  }

  @autobind
  renderHeader(): React.Node {
    const {isShowTimeModal} = this.viewModel;
    if (isShowTimeModal) {
      return (
        <LeaderBoardDatePicker
          onSetDate={this.onSetDate}
          onCancel={this.onCancelDatePicker}
          viewModel={this.viewModel}
        />
      );
    }
    return this.renderLeaderBoardHeader();
  }

  @autobind
  renderList(): React.Node {
    const {userKarmaList, isLoadingKarmaList} = this.viewModel;
    const userKarmas = userKarmaList || [];

    if (isLoadingKarmaList) {
      return <LeaderBoardLoadingContent />;
    }

    if (userKarmas.length === 0) {
      return <LeaderBoardEmptyState />;
    }

    return userKarmas.map(
      (userKarma: {}, index: number): React.Node => {
        const isLastIndex = index === userKarmas.length - 1;
        return this.renderMemberItem(userKarma, index, isLastIndex);
      }
    );
  }

  render(): React.Node {
    return (
      <div className="leader-board-member-list">
        {this.renderHeader()}
        <div className="leader-board-member-list-container">
          {this.viewModel.isAllTeam ? this.renderLeaderBoardAllTeam() : this.renderList()}
        </div>
      </div>
    );
  }
}

export default LeaderBoardMemberListView;
