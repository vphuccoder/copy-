// @flow

import React, {Component} from 'react';
import {Dropdown} from 'react-bootstrap';
import autobind from 'autobind-decorator';
import {observer} from 'mobx-react';
import TimeActionToggle from '../baseComponents/CustomSelectToggle';

type PropsType = {};

type StateType = {};

@observer
class LeaderBoardTimeAction extends Component<PropsType, StateType> {
  @autobind
  onChooseTimeRange() {
    const {onChooseTimeRange} = this.props;
    if (onChooseTimeRange) {
      onChooseTimeRange();
    }
  }

  @autobind
  renderCustomAction(): React.Node {
    return <Dropdown.Item onClick={this.onChooseTimeRange}>Custom</Dropdown.Item>;
  }

  @autobind
  onChooseDefaultTime() {
    const {onChooseDefaultTime} = this.props;
    if (onChooseDefaultTime) {
      onChooseDefaultTime();
    }
  }

  @autobind
  renderDefaultAction(): React.Node {
    return <Dropdown.Item onClick={this.onChooseDefaultTime}>Last 30 days</Dropdown.Item>;
  }

  render(): React.Node {
    return (
      <div className="leader-board-header-time-container">
        <Dropdown>
          <Dropdown.Toggle className="dropdown-toggle" as={TimeActionToggle}>
            {this.props.children}
          </Dropdown.Toggle>
          <Dropdown.Menu className="dropdown-menu">
            {this.renderCustomAction()}
            {this.renderDefaultAction()}
          </Dropdown.Menu>
        </Dropdown>
      </div>
    );
  }
}

export default LeaderBoardTimeAction;
