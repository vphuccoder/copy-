// @flow

import React from 'react';
import {observer} from 'mobx-react';
import autobind from 'autobind-decorator';
import {LeaderBoardTeamSelection} from '../leaderBoardTeamSelection';
import {Group} from '../../../models';
import LeaderBoardTimeAction from '../LeaderBoardTimeAction';
import './LeaderBoardHeader.scss';

type PropsType = {
  title?: Node
};

@observer
class LeaderBoardHeader extends React.Component<PropsType> {
  @autobind
  selectTeam(group: Group) {
    const {selectTeam} = this.props;
    if (selectTeam) {
      selectTeam(group);
    }
  }

  @autobind
  onChooseDefaultTime() {
    const {onChooseDefaultTime} = this.props;
    if (onChooseDefaultTime) {
      onChooseDefaultTime();
    }
  }

  @autobind
  onChooseTimeRange() {
    const {onChooseTimeRange} = this.props;
    if (onChooseTimeRange) {
      onChooseTimeRange();
    }
  }

  @autobind
  renderTitleOrTeams(): React.ReactNode {
    const {groups, selectedGroup, title} = this.props;
    return title ? (
      <div className="header-title">{title}</div>
    ) : (
      <LeaderBoardTeamSelection selectTeam={this.selectTeam} selectedGroup={selectedGroup} groups={groups} />
    );
  }

  @autobind
  renderTime(): React.Node {
    const {time} = this.props;

    return (
      time !== '' && (
        <LeaderBoardTimeAction onChooseDefaultTime={this.onChooseDefaultTime} onChooseTimeRange={this.onChooseTimeRange}>
          <div className="leader-board-header-time">
            <span className="leader-board-header-time-text">{time}</span>
          </div>
        </LeaderBoardTimeAction>
      )
    );
  }

  render(): React.Node {
    return (
      <div className="leader-board-header">
        {this.renderTitleOrTeams()}
        {!this.props.isAllTeam && this.renderTime()}
      </div>
    );
  }
}

export default LeaderBoardHeader;
