// @flow

import React from 'react';
import {
  LEADER_BOARD_EMPTY_STATE_DESCRIPTION,
  LEADER_BOARD_EMPTY_STATE_TITLE
} from '../../../models/constants/string-constant';
import './LeaderBoardEmptyState.scss';

type PropsType = {};

class LeaderBoardEmptyState extends React.Component<PropsType> {
  render(): React.Node {
    return (
      <div className="leader-board-empty-state">
        <div className="leader-board-empty-state-title">{LEADER_BOARD_EMPTY_STATE_TITLE}</div>
        <div className="leader-board-empty-state-description">{LEADER_BOARD_EMPTY_STATE_DESCRIPTION}</div>
      </div>
    );
  }
}

export default LeaderBoardEmptyState;
