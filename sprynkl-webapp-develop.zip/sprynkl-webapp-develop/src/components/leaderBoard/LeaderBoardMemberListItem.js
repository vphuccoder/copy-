// @flow

import React from 'react';
import {Top1, Top2, Top3} from '../baseComponents/svg/Svg';
import {renderUserAvatar} from '../baseComponents/svg/Avatar';
import autobind from 'autobind-decorator';
import {order1st, order2nd, order3rd, orderMore} from '../../models/constants/string-constant';
import {User} from '../../models';
import ProfileLink from '../baseComponents/profileLink';
import TextOverFlow from '../baseComponents/textOverFlow/TextOverFlow';
import './LeaderBoardMemberListItem.scss';

type PropsType = {
  index: number,
  karma: number,
  user: User,
  onSelect: void
};

const topIcons = [Top1, Top2, Top3];
const AVATAR_SIZE = 48;
const ORDER_COLORS = [order1st, order2nd, order3rd, orderMore];

class LeaderBoardMemberListItem extends React.Component<PropsType> {
  @autobind
  beforeSelectUser() {
    const {beforeSelectUser} = this.props;
    if (beforeSelectUser) {
      beforeSelectUser();
    }
  }

  @autobind
  getOrderColor(): {} {
    const {index} = this.props;
    if (index <= ORDER_COLORS.length) {
      return {
        color: ORDER_COLORS[index - 1]
      };
    }
    return {
      color: orderMore
    };
  }

  @autobind
  renderOrder(index: number): React.node {
    if (index < 1) {
      return null;
    }

    if (index > 3) {
      return (
        <span style={this.getOrderColor()} className="leader-board-list-item-index">
          {index}
        </span>
      );
    }

    const Top = topIcons[index - 1];
    return (
      <span className="leader-board-list-item-icon">
        <Top />
      </span>
    );
  }

  render(): React.Node {
    const {index, karma, user} = this.props;
    const {defaultAvatar, fullName, avatar} = user;
    return (
      <ProfileLink user={user} beforeSelectUser={this.beforeSelectUser}>
        <div className="leader-board-list-item-container">
          {this.renderOrder(index)}
          <div className="leader-board-list-item-right">
            <div className="leader-board-list-item-info">
              <div className="leader-board-list-item-avatar">
                {renderUserAvatar(avatar, defaultAvatar, AVATAR_SIZE)}
              </div>
              <TextOverFlow className="leader-board-list-item-name" tooltip={fullName} textOverflow={fullName}>
                <div className="leader-board-list-item-name-text">{fullName}</div>
              </TextOverFlow>
            </div>
            <div className="leader-board-list-item-karma">
              <span className="leader-board-list-item-karma-text">{karma}</span>
            </div>
          </div>
        </div>
      </ProfileLink>
    );
  }
}

export default LeaderBoardMemberListItem;
