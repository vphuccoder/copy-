// @flow

import React from 'react';
import {
  LEADER_BOARD_ALL_TEAM_TITLE,
  LEADER_BOARD_ALL_TEAM_DESCRIPTION
} from '../../../models/constants/string-constant';
import {LeaderBoardAllTeamBackground, LeaderBoardAllTeamArrow} from '../../baseComponents/svg/Svg';
import './LeaderBoardAllTeam.scss';

class LeaderBoardAllTeam extends React.Component {
  render(): React.Node {
    return (
      <div className="leader-board-all-team-container">
        <div className="leader-board-all-team-background">
          <div className="leader-board-all-team-arrow">
            <LeaderBoardAllTeamArrow />
          </div>
          <LeaderBoardAllTeamBackground />
        </div>
        <div className="leader-board-all-team-title">{LEADER_BOARD_ALL_TEAM_TITLE}</div>
        <div className="leader-board-all-team-description">{LEADER_BOARD_ALL_TEAM_DESCRIPTION}</div>
      </div>
    );
  }
}

export default LeaderBoardAllTeam;
