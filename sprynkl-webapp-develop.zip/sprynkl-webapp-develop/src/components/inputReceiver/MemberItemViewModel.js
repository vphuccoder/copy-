// @flow
import {observable, action} from 'mobx';

export default class MemberItemViewModel {
  id: string = '';
  email: string = '';
  fullName: string = '';
  defaultAvatar: string = '';
  avatar: string = '';
  userStatus: string = '';

  @observable
  selected: boolean = false;

  static map(member: {}): MemberItemViewModel {
    const viewModel = new MemberItemViewModel();
    viewModel.email = member.email;
    viewModel.id = member.id;
    viewModel.fullName = member.fullName;
    viewModel.avatar = member.avatar;
    viewModel.defaultAvatar = member.defaultAvatar;
    viewModel.userStatus = member.userStatus;
    return viewModel;
  }

  @action
  setSelected() {
    this.selected = !this.selected;
  }
}
