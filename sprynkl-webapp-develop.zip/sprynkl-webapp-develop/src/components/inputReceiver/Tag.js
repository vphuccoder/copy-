// @flow
import autobind from 'autobind-decorator';
import {observer} from 'mobx-react';
import React, {Component} from 'react';
import {MemberItemViewModel} from '.';
import TextOverFlow from '../baseComponents/textOverFlow/TextOverFlow';

type PropType = {
  item: MemberItemViewModel,
  onDelete: () => mixed
};

@observer
class Tag extends Component<PropType> {
  @autobind
  onDelete() {
    const {onDelete} = this.props;

    if (onDelete) {
      onDelete();
    }
  }

  render(): React.Node {
    const {
      item: {fullName}
    } = this.props;
    return (
      <label className="tag-item marginLeftRight-4">
        <div className="member-data">
          <span className="member-name paddingLeftRight-8">{fullName}</span>
        </div>
      </label>
    );
  }
}

export default Tag;
