// @flow
import autobind from 'autobind-decorator';
import React, {PureComponent} from 'react';
import {renderGroupAvatar} from '../baseComponents/svg/Avatar';
import TextOverFlow from '../baseComponents/textOverFlow/TextOverFlow';
import GroupItemViewModel from './GroupItemViewModel';

type PropType = {
  group: GroupItemViewModel,
  onSelect: () => mixed
};

class GroupItem extends PureComponent<PropType> {
  @autobind
  onSelect() {
    const {selectGroup, group} = this.props;
    if (selectGroup) {
      selectGroup(group);
    }
  }

  render(): React.Node {
    const {
      group: {name, avatar, defaultAvatar}
    } = this.props;
    return (
      <a className="group-item" onClick={this.onSelect}>
        <div className="group-avatar">{renderGroupAvatar(name, avatar, defaultAvatar, 40)}</div>
        <TextOverFlow className="group-name" tooltip={name}>
          <span className="group-name" title={name}>
            {name}
          </span>
        </TextOverFlow>
      </a>
    );
  }
}

export default GroupItem;
