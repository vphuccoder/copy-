// @flow
import autobind from 'autobind-decorator';
import React, {Component} from 'react';
import {renderUserAvatar} from '../baseComponents/svg/Avatar';
import TextOverFlow from '../baseComponents/textOverFlow/TextOverFlow';
import RoundCheckBox from '../baseComponents/roundCheckbox/RoundCheckbox';
import {observer} from 'mobx-react';
import MemberItemViewModel from './MemberItemViewModel';
type PropType = {
  member: MemberItemViewModel
};

@observer
class MemberItem extends Component<PropType> {
  @autobind
  onSelect() {
    const {member} = this.props;
    member.setSelected();
  }

  render() {
    const {
      member: {avatar, defaultAvatar, fullName, email, selected, id}
    } = this.props;
    return (
      <label className="member-item">
        <div className="member-info">
          <div className="member-avatar">{renderUserAvatar(avatar, defaultAvatar, 40)}</div>
          <TextOverFlow className="member-name" tooltip={fullName}>
            <div className="member-data">
              <span className="member-name" title={fullName}>
                {fullName}
              </span>
              <span className="">{email}</span>
            </div>
          </TextOverFlow>
        </div>
        <RoundCheckBox checked={selected} id={id} onChange={this.onSelect} />
      </label>
    );
  }
}

export default MemberItem;
