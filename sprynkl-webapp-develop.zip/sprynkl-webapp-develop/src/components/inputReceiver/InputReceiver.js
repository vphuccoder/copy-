// @flow
import autobind from 'autobind-decorator';
import {observer} from 'mobx-react';
import React from 'react';
import LoadingContent from '../baseComponents/loadingContent/LoadingContent';
import Group from './Groups';
import InputRecevierViewModel from './InputRecevierViewModel';
import MemberList from './MemberList';
import SearchBar from './SearchBar';
import './InputReceiver.scss';

type PropType = {};

@observer
class InputReceiver extends React.Component<PropType> {
  viewModel: InputRecevierViewModel = null;

  constructor(props: PropType) {
    super(props);
    this.viewModel = props.viewModel || {};
  }

  @autobind
  changeSearchValue(value: string) {
    const {viewModel} = this;
    viewModel.isLoading = true;
    viewModel.changeSearchValue(value);
  }

  @autobind
  backToSelectTeam() {
    const {viewModel} = this;
    viewModel.setSelectGroup({});
  }

  @autobind
  selectAll() {
    const {viewModel} = this;
    viewModel.selectAll();
  }

  @autobind
  unselectAll() {
    const {viewModel} = this;
    viewModel.unselectAll();
  }

  renderMembers(): React.Node {
    const {
      filterMembers,
      selectedMembers,
      selectedGroup,
      enableSearch,
      isLoading,
      canBackToSelectTeam,
      activeMembers
    } = this.viewModel;
    if (!selectedGroup.id || !enableSearch || isLoading) {
      return null;
    }

    return (
      <MemberList
        members={filterMembers}
        onBack={this.backToSelectTeam}
        canBackToSelectTeam={canBackToSelectTeam}
        activeMembers={activeMembers}
        selectedMembers={selectedMembers}
        selectAll={this.selectAll}
        unselectAll={this.unselectAll}
      />
    );
  }

  @autobind
  selectGroup(group: {}) {
    const {viewModel} = this;
    viewModel.setSelectGroup(group);
  }

  renderGroups(): React.Node {
    const {filterGroups, selectedGroup, enableSearch, isLoading} = this.viewModel;
    if (selectedGroup.id || !enableSearch || isLoading) {
      return null;
    }
    return <Group groups={filterGroups} selectGroup={this.selectGroup} />;
  }

  renderLoadingContent(): React.Node {
    const {isLoading, enableSearch} = this.viewModel;
    if (isLoading && enableSearch) {
      return (
        <div className="loading-container">
          <div className="loading-item">
            <LoadingContent firstLineWidth={'60%'} secondLineWidth={'50%'} />
          </div>
          <div className="loading-item">
            <LoadingContent />
          </div>
          <div className="loading-item">
            <LoadingContent firstLineWidth={'30%'} secondLineWidth={'40%'} />
          </div>
          <div className="loading-item">
            <LoadingContent firstLineWidth={'50%'} secondLineWidth={'80%'} />
          </div>
        </div>
      );
    }
    return null;
  }

  @autobind
  onDone() {
    const {viewModel} = this;
    viewModel.turnOffSearch();
  }

  @autobind
  turnOnSearch() {
    const {viewModel} = this;
    viewModel.turnOnSearch();
  }

  render(): React.Node {
    const {searchText, displaySelectedMember, selectedGroup, selectedMembers} = this.viewModel;

    return (
      <div className="input-receiver">
        <div className="search">
          <SearchBar
            selectedItem={selectedMembers}
            selectedGroup={selectedGroup}
            searchValue={searchText}
            changeSearchValue={this.changeSearchValue}
            turnOnSearch={this.turnOnSearch}
            displaySelectedMember={displaySelectedMember}
          />
        </div>
        <div className="search-result">
          {this.renderLoadingContent()}
          {this.renderGroups()}
          {this.renderMembers()}
        </div>
      </div>
    );
  }
}

export default InputReceiver;
