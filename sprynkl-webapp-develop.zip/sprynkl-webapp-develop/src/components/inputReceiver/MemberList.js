// @flow
import React, {Component} from 'react';
import MemberItem from './MemberItem';
import autobind from 'autobind-decorator';
import {observer} from 'mobx-react';
import {NO_MEMBER_MESSAGE} from '../../models/constants/string-constant';
import {User} from '../../models/index';

type PropType = {};

@observer
class MemberList extends Component<PropType> {
  @autobind
  renderMemberList(): React.Node {
    const {members, activeMembers} = this.props;
    if (members && members.length > 0) {
      return members.map(
        (member: User): React.Node => {
          return <MemberItem member={member} key={member.id} />;
        }
      );
    }

    if (activeMembers && activeMembers.length === 0) {
      return <div className="no-member-in-team">{NO_MEMBER_MESSAGE}</div>;
    }

    return <div className="no-result-found"> No results founds</div>;
  }

  renderBackToSelectTeam(): React.Node {
    const {onBack, canBackToSelectTeam} = this.props;
    if (canBackToSelectTeam) {
      return (
        <a onClick={onBack}>
          <div className="back-to-select-team">Back to select team</div>
        </a>
      );
    }
  }

  @autobind
  selectAll() {
    const {selectAll} = this.props;
    if (selectAll) {
      selectAll();
    }
  }

  @autobind
  unselectAll() {
    const {unselectAll} = this.props;
    if (unselectAll) {
      unselectAll();
    }
  }

  renderSelectAll(): React.Node {
    const {selectedMembers, activeMembers} = this.props;
    if (activeMembers.length === 0) {
      return null;
    }
    if (selectedMembers.length < activeMembers.length) {
      return (
        <a onClick={this.selectAll}>
          <div className="select-all">{'Select all'}</div>
        </a>
      );
    }
    return (
      <a onClick={this.unselectAll}>
        <div className="unselect-all">{'Unselect all'}</div>
      </a>
    );
  }

  render(): React.Node {
    return (
      <div className="search-result-container">
        <div className="list-header">
          {this.renderBackToSelectTeam()}
          {this.renderSelectAll()}
        </div>
        {this.renderMemberList()}
      </div>
    );
  }
}

export default MemberList;
