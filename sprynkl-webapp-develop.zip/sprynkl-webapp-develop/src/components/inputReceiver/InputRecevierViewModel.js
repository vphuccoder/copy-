// @flow
import {BasePageViewModel} from '../../pages/BasePageViewModel';
import {observable, action, computed} from 'mobx';
import {userService} from '../../services';
import {appModel} from '../../models/app-model';
import {GroupUser, UserStatus} from '../../models';
import GroupItemViewModel from './GroupItemViewModel';
import MemberItemViewModel from './MemberItemViewModel';
import {debounce, isContains} from '../../utils/utils';

export default class InputRecevierViewModel extends BasePageViewModel {
  @observable
  searchText: string = '';

  @observable
  groups: Array<> = [];

  @observable
  members: Array<> = [];

  @observable
  isLoading: boolean = false;

  @observable
  selectedGroup: GroupUser = [];

  @observable
  enableSearch: boolean = false;

  @observable
  filterGroups: Array<> = [];

  @observable
  filterMembers: Array = [];

  @computed
  get canBackToSelectTeam(): boolean {
    return this.groups && this.groups.length > 1;
  }

  @computed
  get activeMembers(): Array<MemberItemViewModel> {
    const {currentUser} = appModel;
    return this.members.filter(
      (member: MemberItemViewModel): boolean => {
        return member.userStatus === UserStatus.ACTIVE && member.id !== currentUser.id;
      }
    );
  }

  @computed
  get selectedMembers(): Array<MemberItemViewModel> {
    return this.members.filter(
      (member: MemberItemViewModel): boolean => {
        return member.selected;
      }
    );
  }

  @computed
  get displaySelectedMember(): string {
    const MAX_MEMBER = 5;
    const selectedMember = this.members.filter(
      (item: MemberItemViewModel): boolean => item.selected
    );

    const displayMember = selectedMember.slice(0, MAX_MEMBER).map(
      (member: MemberItemViewModel, index: number): string => {
        if (index < MAX_MEMBER - 2) {
          return `${member.fullName}, `;
        } else if (index === MAX_MEMBER - 1 && selectedMember.length > MAX_MEMBER) {
          return `${member.fullName}... `;
        } else {
          return member.fullName;
        }
      }
    );
    return displayMember.toString() || '';
  }

  constructor() {
    super();
    this.loadReceviers();
  }

  async loadReceviers() {
    try {
      this.isLoading = true;
      const res = await userService.getAllUserTeam(appModel.currentToken.accessToken);
      this.populateGroups(res);
      this.updateFilter();
    } catch (ex) {
      this.isLoading = false;
      this.handleError(ex, true);
    }
  }

  @action
  populateGroups(group: {}) {
    const joinGroups = group.joined;
    const {currentGroup} = appModel;

    if (joinGroups && joinGroups.length === 1) {
      const selectedGroup = joinGroups[0];
      this.selectedGroup = GroupItemViewModel.map(selectedGroup);
      this.populateUser(this.selectedGroup.members);
    } else if (currentGroup) {
      const selectedGroup = joinGroups.find((group: Group): Group => group.id === currentGroup.id);
      this.selectedGroup = GroupItemViewModel.map(selectedGroup);
      this.populateUser(this.selectedGroup.members);
    }
    if (joinGroups && joinGroups.length > 1) {
      this.groups = joinGroups.map(
        (group: {}): GroupItemViewModel => GroupItemViewModel.map(group)
      );
    }
  }

  @action
  populateUser(members: Array<MemberItemViewModel>) {
    this.members = members;
  }

  updateFilter = debounce(function() {
    if (!this.selectedGroup.id) {
      this.filterGroups = this.groups
        .filter(
          (group: {}): boolean => {
            return isContains(group.name, this.searchText);
          }
        )
        .sort(
          (group1: GroupItemViewModel, group2: GroupItemViewModel): boolean => {
            return group1.name.localeCompare(group2.name);
          }
        );
    } else {
      const {currentUser} = appModel;
      this.filterMembers = this.members
        .filter(
          (member: MemberItemViewModel): boolean => {
            return (
              currentUser.id !== member.id &&
              member.userStatus === UserStatus.ACTIVE &&
              (isContains(member.fullName, this.searchText) ||
                isContains(member.email, this.searchText))
            );
          }
        )
        .sort(
          (user1: MemberItemViewModel, user2: MemberItemViewModel): boolean => {
            // TODO: selected first
            return user1.fullName.localeCompare(user2.fullName);
          }
        );
    }
    this.isLoading = false;
  }, 300);

  @action
  changeSearchValue(value: string) {
    this.isLoading = true;
    this.searchText = value;
    this.updateFilter();
  }

  @action
  setSelectGroup(group: GroupItemViewModel) {
    this.isLoading = true;
    this.unselectAll();
    this.selectedGroup = group;
    const member = group.members || [];
    this.populateUser(member);
    this.changeSearchValue('');
  }

  @action
  turnOnSearch() {
    this.enableSearch = true;
  }

  @action
  turnOffSearch() {
    this.enableSearch = false;
  }

  @action
  unselectAll() {
    this.activeMembers.forEach((member: MemberItemViewModel) => {
      member.selected = false;
    });
  }

  @action
  selectAll() {
    this.activeMembers.forEach((member: MemberItemViewModel) => {
      member.selected = true;
    });
  }
}
