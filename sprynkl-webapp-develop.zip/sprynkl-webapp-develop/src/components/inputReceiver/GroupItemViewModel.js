// @flow
import MemberItemViewModel from './MemberItemViewModel';

export default class GroupItemViewModel {
  id: string = '';
  email: string = '';
  name: string = '';
  defaultAvatar: string = '';
  avatar: string = '';
  members: Array<MemberItemViewModel> = [];

  static map(group: {}): GroupItemViewModel {
    const viewModel = new GroupItemViewModel();
    viewModel.email = group.email;
    viewModel.id = group.id;
    viewModel.name = group.name;
    viewModel.avatar = group.avatar;
    viewModel.defaultAvatar = group.defaultAvatar;
    viewModel.members = group.members.map((member: {}): MemberItemViewModel => MemberItemViewModel.map(member));
    return viewModel;
  }
}
