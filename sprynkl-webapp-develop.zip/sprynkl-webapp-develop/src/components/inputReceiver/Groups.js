// @flow
import autobind from 'autobind-decorator';
import {observer} from 'mobx-react';
import React, {Component} from 'react';
import GroupItem from './GroupItem';
import GroupItemViewModel from './GroupItemViewModel';

type PropType = {
  groups: Array<GroupItemViewModel>,
  selectGroup: () => mixed
};

@observer
class Groups extends Component<PropType> {
  @autobind
  renderGroups(): React.Node {
    const {groups, selectGroup} = this.props;
    if (groups && groups.length > 0) {
      return groups.map(
        (group: GroupItemViewModel): React.Node => {
          return <GroupItem group={group} key={group.id} selectGroup={selectGroup} />;
        }
      );
    }
    return <div className="no-result-found"> No results founds</div>;
  }

  render(): React.Node {
    return <div className="search-result-container">{this.renderGroups()}</div>;
  }
}

export default Groups;
