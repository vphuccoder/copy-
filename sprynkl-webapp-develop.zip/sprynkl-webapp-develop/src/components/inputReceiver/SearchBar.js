// @flow
import autobind from 'autobind-decorator';
import {observer} from 'mobx-react';
import React, {Component, Fragment} from 'react';
import {Form} from 'react-bootstrap';
import Tag from './Tag';

type PropType = {
  changeSearchValue: () => mixed,
  searchValue: string,
  turnOnSearch: boolean
};

@observer
class SearchBar extends Component<PropType> {
  @autobind
  changeSearchValue(e: {}) {
    const {changeSearchValue} = this.props;
    if (changeSearchValue) {
      changeSearchValue(e.target.value);
    }
  }
  renderSelectedItem(): React.Node {
    const {selectedItem} = this.props;
    return (
      <div className="tag-container paddingLeftRight-20">
        {selectedItem.map(
          (item: {}): React.Node => {
            return <Tag key={item.id} item={item} />;
          }
        )}
      </div>
    );
  }

  render(): React.Node {
    const {searchValue, turnOnSearch, selectedGroup} = this.props;
    const displaySelectedMember = selectedGroup ? selectedGroup.name || '' : '';
    return (
      <Fragment>
        <div className="search-container paddingLeftRight-24">
          <Form.Label>To:</Form.Label>
          <Form.Control
            className="search-input"
            type="search"
            placeholder={`${displaySelectedMember}`}
            value={searchValue}
            onChange={this.changeSearchValue}
            onFocus={turnOnSearch}
          />
        </div>
        {this.renderSelectedItem()}
      </Fragment>
    );
  }
}

export default SearchBar;
