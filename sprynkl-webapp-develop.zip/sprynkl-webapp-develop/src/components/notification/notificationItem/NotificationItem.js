/**
 * @format
 * @flow
 */

import React from 'react';
import autobind from 'autobind-decorator';
import {NOTIFICATION_TYPE} from '../../../models';
import {upperFirstChar, shortString} from '../../../utils';
import {NotificationViewModel} from '../NotificationViewModel';
import './NotificationItem.scss';

type PropsType = {
  notificationVM: NotificationViewModel,
  postType: string,
  renderFromUser: React.Node,
  renderPostContent: React.Node,
  reportType: string,
  renderGroupName: string
};

class NotificationItem extends React.Component<PropsType> {
  @autobind
  renderAuthorPrePostContent(): React.Node {
    const {reportType, postType} = this.props;
    let content = '';
    switch (reportType) {
      case NOTIFICATION_TYPE.postComment:
        content = ` commented on your ${upperFirstChar(postType)} in `;
        break;
      case NOTIFICATION_TYPE.postClap:
        content = ` clapped on your ${upperFirstChar(postType)} in `;
        break;
      default:
        break;
    }
    return <span>{content}</span>;
  }

  @autobind
  renderAnonymousPrePostContent(): React.Node {
    const {reportType, postType, notificationVM} = this.props;
    const {post} = notificationVM;
    let content = '';
    switch (reportType) {
      case NOTIFICATION_TYPE.postComment:
        content = ' commented on ';
        break;
      case NOTIFICATION_TYPE.postClap:
        content = ' clapped on ';
        break;
      default:
        break;
    }

    return (
      <span>
        {content}
        <span className="notification-item-anonymous-pre-post-content">
          {post.author ? shortString(post.author.fullName) : 'Someone'}
        </span>
        {`'s ${upperFirstChar(postType)} in `}
      </span>
    );
  }

  @autobind
  renderPrePostContent(): React.Node {
    const {notificationVM} = this.props;
    const {post} = notificationVM;
    const isAuthor = post.author && post.author.id === notificationVM.currentUser.id;
    if (isAuthor) {
      return this.renderAuthorPrePostContent();
    }
    return this.renderAnonymousPrePostContent();
  }

  render(): React.Node {
    const {renderFromUser, renderPostContent, renderGroupName} = this.props;
    return (
      <span>
        {renderFromUser}
        {this.renderPrePostContent()}
        {renderGroupName}
        {renderPostContent}
      </span>
    );
  }
}

export default NotificationItem;
