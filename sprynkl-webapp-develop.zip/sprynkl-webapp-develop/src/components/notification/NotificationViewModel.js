// @flow

import {action, observable} from 'mobx';
import {Notification, NOTIFICATION_TYPE, User, PostModel, Group} from '../../models/index';
import {BasePageViewModel} from '../../pages/BasePageViewModel';

class NotificationViewModel extends BasePageViewModel {
  key: string;

  type: string;

  post: PostModel;

  group: Group;

  @observable
  notifications: Notification[];

  seen: boolean = false;

  avatar: string;

  defaultAvatar: string;

  description: string;

  createdDate: string;

  currentUser: User;

  fromUsers: User[];

  @observable
  read: boolean = false;

  @action
  setNotifications(notifications: Notification[]) {
    this.notifications = notifications;
    const notification = notifications[0];

    this.post = notification.post;
    const temp = notifications.find((n: Notification): boolean => n.seen === false);
    const tempRead = notifications.find((n: Notification): boolean => n.read === false);
    const user = notification.fromUser;
    const chooseAvatar =
      notification.type === NOTIFICATION_TYPE.newPost || notification.type === NOTIFICATION_TYPE.sendPostTo;
    this.avatar = this.post.anonymous === true && chooseAvatar ? '' : user.avatar;
    this.defaultAvatar = this.post.anonymous === true && chooseAvatar ? '1' : user.defaultAvatar;
    this.seen = !temp;
    this.read = !tempRead;
    this.createdDate = notification.createdDate;
    this.description = notification.description;
  }

  setCurrentUser(user: User) {
    this.currentUser = user;
  }

  markAsRead() {
    this.read = true;
  }
}

export {NotificationViewModel};
