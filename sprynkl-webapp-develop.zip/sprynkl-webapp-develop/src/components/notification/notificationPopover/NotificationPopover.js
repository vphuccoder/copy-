// @flow
import React from 'react';
import {OverlayTrigger, Popover, Button} from 'react-bootstrap';
import {withRouter} from 'react-router';
import autobind from 'autobind-decorator';
import NotificationListItem from '../notificationListItem/NotificationListItem';
import {NotificationEmptyState, notificationListViewModel as viewModel} from '../index';
import {NotificationViewModel} from '../NotificationViewModel';
import {appModel} from '../../../models/app-model';
import {observer} from 'mobx-react';
import NotificationIcon from '../NotificationIcon';
import NotificationLoadingContent from '../notificationLoadingContent/NotificationLoadingContent';
import {NOTIFICATION_TYPE} from '../../../models';
import {ALLOW_GO_TO_POST_DETAIL_NOTIFICATION} from '../../../models/constants/notification-type';
import './NotificationPopover.scss';

type PropsType = {
  history: History
};

type StateType = {};

@withRouter
@observer
class NotificationPopover extends React.Component<PropsType, StateType> {
  componentDidMount() {
    viewModel.getNotifications();
    viewModel.checkNotSeenNotification();
  }

  @autobind
  onExitOverlay() {
    viewModel.isFocused = false;
  }

  @autobind
  onClickNotificationItem() {
    viewModel.isFocused = true;
    viewModel.markSeenForNotifications();
    appModel.hasNotSeenNotification = false;
  }

  @autobind
  async onDeleteNotificationItem(notificationVM: NotificationViewModel) {
    await viewModel.deleteNotification(notificationVM);
  }

  @autobind
  onPressInviteNotification() {
    const {onPressInviteNotification} = this.props;
    if (onPressInviteNotification) {
      onPressInviteNotification();
    }
  }

  @autobind
  async onPressNotificationItem(notificationVM: NotificationViewModel): Promise {
    const {post} = notificationVM;

    await viewModel.onPressNotification(notificationVM);

    if (post && post.id && ALLOW_GO_TO_POST_DETAIL_NOTIFICATION.includes(notificationVM.type)) {
      this.onExitOverlay();
      this.props.history.push(`/post/${post.id}`);
    } else if (notificationVM.type === NOTIFICATION_TYPE.inviteUser) {
      this.onPressInviteNotification();
    } else {
      // TODO: handle other cases for notification
    }
  }

  @autobind
  renderNotificationListItem(notificationVM: NotificationViewModel, isLastIndex: boolean): React.Node {
    return (
      <NotificationListItem
        key={notificationVM.key}
        notificationVM={notificationVM}
        onDeleteNotification={(): void => this.onDeleteNotificationItem(notificationVM)}
        onPressNotification={(): void => this.onPressNotificationItem(notificationVM)}
        isLastIndex={isLastIndex}
      />
    );
  }

  @autobind
  renderListNotification(): React.Node {
    if (viewModel.notificationVMs.length <= 0) {
      return <NotificationEmptyState />;
    }

    if (viewModel.isShowLoadingContent) {
      return <NotificationLoadingContent />;
    }

    return viewModel.notificationVMs.map(
      (notificationVM: NotificationViewModel, index: number): React.Node => {
        const isLastIndex = index === viewModel.notificationVMs.length - 1;
        return this.renderNotificationListItem(notificationVM, isLastIndex);
      }
    );
  }

  render(): React.Node {
    return (
      <OverlayTrigger
        trigger="click"
        placement="bottom"
        rootClose
        onExit={this.onExitOverlay}
        container={this}
        overlay={
          <Popover className="notification-popover">
            <div className="notification-header">Notifications</div>
            <div className="notification-container">{this.renderListNotification()}</div>
          </Popover>
        }
      >
        <div className="notification-icon">
          <Button variant="link" onClick={this.onClickNotificationItem}>
            <NotificationIcon focused={viewModel.isFocused} />
          </Button>
        </div>
      </OverlayTrigger>
    );
  }
}

export default NotificationPopover;
