/**
 * @format
 * @flow
 */

import {action, observable, runInAction} from 'mobx';
import {BasePageViewModel} from '../../../pages/BasePageViewModel';
import {Notification, NOTIFICATION_TYPE, User} from '../../../models/index';
import {NotificationViewModel} from '../NotificationViewModel';
import {notificationService, groupService} from '../../../services/index';
import {appModel} from '../../../models/app-model';
import autobind from 'autobind-decorator';
import {ALLOW_GO_TO_POST_DETAIL_NOTIFICATION} from '../../../models/constants/notification-type';

class NotificationPopoverViewModel extends BasePageViewModel {
  @observable
  notificationVMs: NotificationViewModel[] = [];

  @observable
  isFocused: boolean = false;

  @observable
  isShowLoadingContent: boolean = false;

  @action
  setNotifications(notifications: Notification[]) {
    this.notificationVMs = this.groupNotification(notifications);
  }

  @action
  async checkNotSeenNotification(): Promise {
    try {
      const {currentToken} = appModel;
      if (currentToken) {
        const status = await notificationService.checkNotSeenNotification(currentToken.accessToken);
        appModel.hasNotSeenNotification = status;
      }
    } catch (e) {
      //
    }
  }

  @autobind
  canNavigateToPostDetail(notificationVM: NotificationViewModel): boolean {
    const {type} = notificationVM;
    switch (type) {
      case NOTIFICATION_TYPE.postClap:
      case NOTIFICATION_TYPE.postComment:
      case NOTIFICATION_TYPE.newPost:
      case NOTIFICATION_TYPE.sendPostTo:
      case NOTIFICATION_TYPE.tagInComment:
      case NOTIFICATION_TYPE.responseAsk:
        return true;
      default:
        break;
    }

    return false;
  }

  @autobind
  canNavigateToViewReport(notificationVM: NotificationViewModel): boolean {
    const {type} = notificationVM;
    switch (type) {
      case NOTIFICATION_TYPE.reportComment:
      case NOTIFICATION_TYPE.reportPost:
        return true;
      default:
        break;
    }

    return false;
  }

  @autobind
  shouldNotNavigate(notificationVM: NotificationViewModel): boolean {
    const {type} = notificationVM;
    return type === NOTIFICATION_TYPE.deletePost;
  }

  @action
  async onPressNotification(notificationVM: NotificationViewModel): Promise {
    this.markReadForNotifications(notificationVM);
  }

  @action
  async getNotifications(): Promise {
    try {
      this.isShowLoadingContent = true;
      const list = await notificationService.getNotification(appModel.currentToken.accessToken);
      this.setNotifications(list.notifications);
      this.isShowLoadingContent = false;
    } catch (e) {
      this.handleError(e, true);
    }
  }

  @action
  markSeenForNotifications() {
    const seenNotificationIds = [];
    this.notificationVMs.forEach((notiViewModel: NotificationViewModel) => {
      if (notiViewModel) {
        notiViewModel.notifications.forEach((n: Notification) => {
          if (n.seen === false) {
            seenNotificationIds.push(n.id);
          }
        });
      }
    });
    if (seenNotificationIds.length > 0) {
      try {
        notificationService.updateSeen(appModel.currentToken.accessToken, seenNotificationIds);
      } catch (err) {
        // skip if having error
      }
    }
  }

  @action
  markReadForNotifications(notificationVM: NotificationViewModel) {
    const readNotificationIds = [];
    notificationVM.markAsRead();
    notificationVM.notifications.forEach((n: Notification) => {
      if (n.read === false) {
        readNotificationIds.push(n.id);
      }
    });

    if (readNotificationIds.length > 0) {
      try {
        notificationService.updateRead(appModel.currentToken.accessToken, readNotificationIds);
      } catch (err) {
        // skip if having error
      }
    }
  }

  @action
  async deleteNotification(notificationVM: NotificationViewModel): Promise {
    try {
      this.notificationVMs = this.notificationVMs.filter(
        (notiVM: NotificationViewModel): boolean => notificationVM.key !== notiVM.key
      );
      const notificationIds = notificationVM.notifications.map((n: Notification): string => n.id);
      notificationService.deletePatchNotification(appModel.currentToken.accessToken, notificationIds);
    } catch (ex) {
      // dont promt anything...
    }
  }

  groupNotification(notifications: Notification[]): NotificationViewModel[] {
    const tempMap = {};
    const notificationMap = {};
    const notificationVMs: NotificationViewModel[] = [];

    notifications.forEach((notification: Notification) => {
      const key = `${notification.type}-${notification.post.id}-${notification.group.id}`;
      let vm;
      if (!tempMap[key]) {
        tempMap[key] = [];
        vm = new NotificationViewModel();
        notificationMap[key] = vm;
        vm.key = key;
        vm.type = notification.type;
        vm.post = notification.post;
        vm.group = notification.group;
        vm.fromUsers = [];
        notificationVMs.push(vm);
      } else {
        vm = notificationMap[key];
      }

      tempMap[key].push(notification);
      const index = vm.fromUsers.findIndex((n: User): boolean => n.id === notification.fromUser.id);
      if (index === -1) {
        vm.fromUsers.push(notification.fromUser);
      }
    });

    notificationVMs.forEach((vm: NotificationViewModel) => {
      vm.setNotifications(tempMap[vm.key]);
      vm.setCurrentUser(appModel.currentUser);
    }, this);

    return notificationVMs;
  }
}

const notificationListViewModel = new NotificationPopoverViewModel();
export {notificationListViewModel};
