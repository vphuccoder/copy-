/**
 * @flow
 * @format
 */

import React from 'react';
import {NOTIFICATION_EMPTY_STATE} from '../../../models/constants/string-constant';
import {NotificationEmptyStateIcon} from "../../baseComponents/svg/Svg";
import './NotificationEmptyState.scss';

class NotificationEmptyState extends React.Component {
  render(): React.Node {
    return (
      <div className="notification-empty-state">
        <div className="notification-icon">
          <NotificationEmptyStateIcon />
        </div>
        <span className="notification-empty-state-text">{NOTIFICATION_EMPTY_STATE}</span>
      </div>
    );
  }
}

export default NotificationEmptyState;
