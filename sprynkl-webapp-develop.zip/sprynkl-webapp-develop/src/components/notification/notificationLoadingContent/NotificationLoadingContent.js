// @flow

import React from 'react';
import autobind from 'autobind-decorator';
import {NotificationLoadingContentBackground} from '../../baseComponents/svg/Svg';
import './NotificationLoadingContent.scss';

type PropsType = {};

type StateType = {};

class NotificationLoadingContent extends React.Component<PropsType, StateType> {
  @autobind
  renderLoadingPattern(): React.Node {
    return <NotificationLoadingContentBackground />;
  }

  render(): React.Node {
    return (
      <div className="notification-loading-content">
        <div className="notification-loading-content-separator" />
        {this.renderLoadingPattern()}
        <div className="notification-loading-content-separator" />
        {this.renderLoadingPattern()}
        <div className="notification-loading-content-separator" />
        {this.renderLoadingPattern()}
      </div>
    );
  }
}

export default NotificationLoadingContent;
