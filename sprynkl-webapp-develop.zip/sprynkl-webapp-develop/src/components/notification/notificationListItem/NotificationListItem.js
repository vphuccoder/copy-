/**
 * @flow
 * @format
 */

import React from 'react';
import autobind from 'autobind-decorator';
import {observer} from 'mobx-react';
import {NOTIFICATION_TYPE, ASK} from '../../../models/index';
import {shortString, upperFirstChar} from '../../../utils/index';
import NotificationItem from '../notificationItem/NotificationItem';
import {NotificationViewModel} from '../NotificationViewModel';
import {renderUserAvatar} from '../../baseComponents/svg/Avatar';
import NotificationMoreAction from '../NotificationMoreAction';
import './NotificationListItem.scss';

const MAXIMUM_CHARACTER_PER_LINE = 90;

type PropsType = {
  notificationVM: NotificationViewModel,
  onPressNotification: void,
  onDeleteNotification: void,
  isLastIndex: boolean
};

type StateType = {
  isMouseOver: boolean
};

@observer
class NotificationListItem extends React.Component<PropsType, StateType> {
  constructor(props: PropsType) {
    super(props);
    this.state = {
      isMouseOver: false
    };
  }

  @autobind
  onPressNotification() {
    const {onPressNotification, notificationVM} = this.props;
    if (onPressNotification) {
      onPressNotification(notificationVM);
    }
  }

  @autobind
  isNotUseAvatar(type: string): boolean {
    return type === NOTIFICATION_TYPE.deletePost;
  }

  @autobind
  onDeleteNotification() {
    const {onDeleteNotification} = this.props;
    if (onDeleteNotification) {
      onDeleteNotification();
    }
  }

  @autobind
  onMouseOver() {
    this.setState({isMouseOver: true});
  }

  @autobind
  onMouseLeave() {
    this.setState({isMouseOver: false});
  }

  @autobind
  renderEndString(content: string): React.Node {
    if (content.endsWith('.')) {
      return '';
    }
    return '.';
  }

  @autobind
  renderAvatar(): React.Node {
    const {notificationVM} = this.props;
    let {defaultAvatar, avatar} = notificationVM;
    const {
      post: {askContent},
      type
    } = notificationVM;

    if (this.isNotUseAvatar(type)) {
      avatar = '';
    }
    if (askContent && type === NOTIFICATION_TYPE.responseAsk) {
      if (askContent.anonymousAnswer) {
        defaultAvatar = '1';
      }
    }
    return renderUserAvatar(avatar, defaultAvatar, 48);
  }

  @autobind
  renderTime(): React.Node {
    const {notificationVM} = this.props;
    const {createdDate} = notificationVM;

    return <div className="notification-time">{createdDate}</div>;
  }

  @autobind
  renderSomeone(): React.Node {
    return <span className="bolder-text">Someone</span>;
  }

  @autobind
  renderSendTo(sendTo: []): React.Node {
    if (sendTo && sendTo.length > 0) {
      return sendTo.map(
        (item: {}, index: number): React.Node => {
          return (
            <span key={item.id}>
              <span className="bolder-text">{` ${shortString(item.fullName)}`}</span>
              {index !== sendTo.length - 1 && index !== sendTo.length - 2 && <span>{', '}</span>}
              {index === sendTo.length - 2 && <span> and</span>}
            </span>
          );
        }
      );
    }
    return null;
  }

  @autobind
  renderOtherSendTo(otherSendTo: []): React.Node {
    return (
      otherSendTo &&
      otherSendTo.length > 0 && (
        <span>
          {' and '}
          <span className="bolder-text">{`${otherSendTo.length} others`}</span>
        </span>
      )
    );
  }

  @autobind
  renderMembersAnswer(totalAnswers: number): React.Node {
    return <span className="bolder-text">{`${totalAnswers} members`}</span>;
  }

  @autobind
  renderFromUser(): React.Node {
    const {notificationVM} = this.props;
    const {
      post: {askContent},
      type
    } = notificationVM;
    let fromUser = [];
    let fromOtherUser = [];

    if (askContent) {
      const {anonymousAnswer, totalAnswers} = askContent;
      if (anonymousAnswer && type === NOTIFICATION_TYPE.responseAsk) {
        return totalAnswers === 1 ? this.renderSomeone() : this.renderMembersAnswer(totalAnswers);
      }
    }

    const fromUsers = [...notificationVM.fromUsers];
    if (fromUsers.length > 2) {
      fromUser = fromUsers.slice(0, 1);
      fromOtherUser = fromUsers.slice(1, fromUsers.length);
    } else {
      fromUser = fromUsers.slice();
    }

    return (
      <span>
        {this.renderSendTo(fromUser)}
        {this.renderOtherSendTo(fromOtherUser)}
      </span>
    );
  }

  @autobind
  renderGroupName(groupName: string): React.Node {
    return <span className="bolder-text">{groupName}</span>;
  }

  @autobind
  renderPostContent(content: string, notiType: string): React.Node {
    if (notiType !== NOTIFICATION_TYPE.postComment && content) {
      const postContent =
        content.length > MAXIMUM_CHARACTER_PER_LINE ? `"${content.substring(0, 20)}...".` : `"${content}".`;
      return <span>{`: ${postContent}`}</span>;
    }

    return <span>.</span>;
  }

  @autobind
  renderReportNotification(notiType: string = NOTIFICATION_TYPE.reportPost): React.Node {
    const {notificationVM} = this.props;
    const {group, post} = notificationVM;
    let headerText = '';
    switch (notiType) {
      case NOTIFICATION_TYPE.reportComment:
        headerText = 'A Comment in ';
        break;
      case NOTIFICATION_TYPE.reportPost:
        headerText = post.type !== ASK ? 'A' : 'An';
        headerText = headerText.concat(` ${upperFirstChar(post.type)} in `);
        break;
      default:
        break;
    }

    return (
      <span>
        {headerText}
        {this.renderGroupName(group.name)}
        {' has been reported. Review it now.'}
      </span>
    );
  }

  @autobind
  renderAssignNotification(notiType: string = NOTIFICATION_TYPE.assignLead): React.Node {
    const {
      notificationVM: {group}
    } = this.props;
    let fromUser;
    let middleText = '';
    let tailText = '';

    switch (notiType) {
      case NOTIFICATION_TYPE.assignLead:
        fromUser = this.renderFromUser();
        middleText = ' made you a team lead in ';
        tailText = '. Go to Team feed to connect with your team.';
        break;
      case NOTIFICATION_TYPE.unassignLead:
        middleText = 'You are no longer a team lead in ';
        tailText = '.';
        break;
      default:
        break;
    }

    return (
      <span>
        {fromUser}
        {middleText}
        {this.renderGroupName(group.name)}
        {tailText}
      </span>
    );
  }

  @autobind
  renderPostNotification(notiType: string): React.Node {
    const {notificationVM} = this.props;
    const {post, group, type} = notificationVM;
    const {textContent} = post;
    return (
      <NotificationItem
        notificationVM={notificationVM}
        renderFromUser={this.renderFromUser()}
        renderPostContent={this.renderPostContent(textContent, type)}
        renderGroupName={this.renderGroupName(group.name)}
        postType={post.type}
        reportType={notiType}
      />
    );
  }

  @autobind
  renderSendPostToNotification(): React.Node {
    const {notificationVM} = this.props;
    const {post, group, type} = notificationVM;

    const headText = `You got a new ${upperFirstChar(post.type)} from `;
    const fromUser = post.anonymous ? this.renderSomeone() : this.renderFromUser();

    return (
      <span>
        {headText}
        {fromUser}
        {' in '}
        {this.renderGroupName(group.name)}
        {this.renderPostContent(post.textContent, type)}
      </span>
    );
  }

  @autobind
  renderTagInCommentNotification(): React.Node {
    const {notificationVM} = this.props;
    const {group} = notificationVM;
    return (
      <span>
        {this.renderFromUser()}
        {' mentioned you in a comment in '}
        {this.renderGroupName(group.name)}
        {this.renderEndString(group.name)}
      </span>
    );
  }

  @autobind
  renderResponseAskNotification(): React.Node {
    const {notificationVM} = this.props;
    const {group} = notificationVM;
    return (
      <span>
        {this.renderFromUser()}
        {' answered your Ask in '}
        {this.renderGroupName(group.name)}
        {this.renderEndString(group.name)}
      </span>
    );
  }

  @autobind
  renderRemoveUserNotification(): React.Node {
    const {
      notificationVM: {group}
    } = this.props;
    return (
      <span>
        {'You are no longer a member of '}
        {this.renderGroupName(group.name)}
        {this.renderEndString(group.name)}
      </span>
    );
  }

  @autobind
  renderInviteUserNotification(): React.Node {
    const {
      notificationVM: {group}
    } = this.props;
    return (
      <span>
        {this.renderFromUser()}
        {' invited you to join '}
        {this.renderGroupName(group.name)}
        {this.renderEndString(group.name)}
      </span>
    );
  }

  @autobind
  renderAssignOwnerNotification(): React.Node {
    const {
      notificationVM: {group}
    } = this.props;
    return (
      <span>
        {this.renderFromUser()}
        {' made you a team owner in '}
        {this.renderGroupName(group.name)}
        {'. Go to Team feed to connect with your team.'}
      </span>
    );
  }

  @autobind
  renderDeletePostNotification(): React.Node {
    return <span>{'Your team lead has removed one of your posts. Contact them to find out why.'}</span>;
  }

  @autobind
  renderMoreActions(): React.Node {
    return <NotificationMoreAction canDeleteNoti onDelete={this.onDeleteNotification} iconSize={20} />;
  }

  @autobind
  renderNotificationInfo(): React.Node {
    const {notificationVM} = this.props;

    switch (notificationVM.type) {
      case NOTIFICATION_TYPE.reportPost:
      case NOTIFICATION_TYPE.reportComment:
        return this.renderReportNotification(notificationVM.type);
      case NOTIFICATION_TYPE.assignLead:
      case NOTIFICATION_TYPE.unassignLead:
        return this.renderAssignNotification(notificationVM.type);
      case NOTIFICATION_TYPE.postClap:
      case NOTIFICATION_TYPE.postComment:
        return this.renderPostNotification(notificationVM.type);
      case NOTIFICATION_TYPE.newPost:
      case NOTIFICATION_TYPE.sendPostTo:
        return this.renderSendPostToNotification();
      case NOTIFICATION_TYPE.tagInComment:
        return this.renderTagInCommentNotification();
      case NOTIFICATION_TYPE.responseAsk:
        return this.renderResponseAskNotification();
      case NOTIFICATION_TYPE.removeUser:
        return this.renderRemoveUserNotification();
      case NOTIFICATION_TYPE.inviteUser:
        return this.renderInviteUserNotification();
      case NOTIFICATION_TYPE.assignOwner:
        return this.renderAssignOwnerNotification();
      case NOTIFICATION_TYPE.deletePost:
        return this.renderDeletePostNotification();
      case NOTIFICATION_TYPE.tagInPost:
      default:
        return null;
    }
  }

  render(): React.Node {
    const {notificationVM, isLastIndex} = this.props;
    const {isMouseOver} = this.state;
    const itemStyle = {
      backgroundColor: notificationVM.read === false ? '#F2F3F4' : 'transparent',
      borderBottomColor: isLastIndex ? 'transparent' : '#d8d8d8',
      borderBottomWidth: isLastIndex ? 0 : 1
    };

    return (
      <div
        className="notification-info-container"
        style={itemStyle}
        onMouseOver={this.onMouseOver}
        onMouseLeave={this.onMouseLeave}
      >
        <div className="notification-info" onClick={this.onPressNotification}>
          <div className="notification-info-left">
            <div className="notification-avatar">{this.renderAvatar()}</div>
            <div className="notification-title">
              <div className="notification-sender">{this.renderNotificationInfo()}</div>
              {this.renderTime()}
            </div>
          </div>
        </div>
        <div className="notification-more-action-container">{isMouseOver && this.renderMoreActions()}</div>
      </div>
    );
  }
}

export default NotificationListItem;
