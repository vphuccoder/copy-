// @flow

import React, {Component} from 'react';
import {Dropdown} from 'react-bootstrap';
import autobind from 'autobind-decorator';
import {observer} from 'mobx-react';
import {icons} from '../themes/Icons';
import Icon from '../baseComponents/Icon';
import NotificationMoreActionToggle from '../baseComponents/CustomSelectToggle';
import {SYSTEM_VARIABLE} from '../../models/constants/index';

type PropsType = {
  canDeleteNoti: boolean,
  iconSize: number
};

type StateType = {
  dropdownOpen: boolean
};

@observer
class NotificationMoreAction extends Component<PropsType, StateType> {
  constructor(props: PropsType) {
    super(props);
    this.state = {
      dropdownOpen: false
    };
  }

  @autobind
  toggle() {
    this.setState(
      (prevState: StateType): {} => ({
        dropdownOpen: !prevState.dropdownOpen
      })
    );
  }

  @autobind
  onMouseLeave() {
    this.setState({dropdownOpen: false});
  }

  @autobind
  onDelete() {
    const {onDelete} = this.props;
    if (onDelete) {
      onDelete();
    }
  }

  @autobind
  renderDeleteNotification(canDelete: boolean): React.Node {
    return canDelete === true ? <Dropdown.Item onClick={this.onDelete}>Delete</Dropdown.Item> : null;
  }

  render(): React.Node {
    const {canDeleteNoti, iconSize} = this.props;
    const iconSizeValue = iconSize ? iconSize : SYSTEM_VARIABLE.ICON_SIZE;

    return (
      <div className="notification-more-action">
        <Dropdown onMouseLeave={this.onMouseLeave} show={this.state.dropdownOpen} onToggle={this.toggle}>
          <Dropdown.Toggle className="dropdown-toggle" as={NotificationMoreActionToggle}>
            <Icon color="#777b7d" iconName={icons.more} size={iconSizeValue} />
          </Dropdown.Toggle>
          <Dropdown.Menu alignRight>{this.renderDeleteNotification(canDeleteNoti)}</Dropdown.Menu>
        </Dropdown>
      </div>
    );
  }
}

export default NotificationMoreAction;
