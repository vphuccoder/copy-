// @flow

import React from 'react';
import {observer} from 'mobx-react';
import {appModel} from '../../models/app-model';
import {InActiveNotification, ActiveNotification, FocusedNotification} from '../baseComponents/svg/Icons';

type PropsType = {
  focused: boolean
};

@observer
class NotificationIcon extends React.Component<PropsType> {
  render(): React.Node {
    const {focused} = this.props;
    if (focused) {
      return <FocusedNotification />;
    }
    return <NotificationIconNotFocused hasNoti={appModel.hasNotSeenNotification} />;
  }
}

const NotificationIconNotFocused = observer(
  (props: {hasNoti: boolean}): React.Node => {
    const {hasNoti} = props;
    return hasNoti ? <ActiveNotification /> : <InActiveNotification />;
  }
);

export default NotificationIcon;
