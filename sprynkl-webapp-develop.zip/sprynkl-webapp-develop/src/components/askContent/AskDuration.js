// @flow
import * as React from 'react';
class AskDuration extends React.Component {
  render(): React.ReactNode {
    const {duration} = this.props;
    return <div> {duration}</div>;
  }
}

export default AskDuration;
