// @flow
import * as React from 'react';
import {AskBody, AskFooter} from './';
import './AskContent.scss';
class AskContent extends React.Component {
  renderBody(): React.Node {
    const {viewModel} = this.props;
    return <AskBody viewModel={viewModel} />;
  }

  renderFooter(): React.Node {
    const {viewModel} = this.props;

    return <AskFooter viewModel={viewModel} />;
  }
  render(): React.ReactNode {
    return (
      <div className="ask-content">
        {this.renderBody()}
        {this.renderFooter()}
      </div>
    );
  }
}
export default AskContent;
