// @flow
import {ModalConsumer} from '../../components/context/ModalContext';
import {ResultsDetailModal} from '../modals';
import {AskDuration, AskResponse, AskStatus} from './';
import React, {Fragment} from 'react';

class AskFooter extends React.Component {
  renderAskStatus(): React.Node {
    const {
      viewModel,
      viewModel: {isCreator}
    } = this.props;
    if (!viewModel.hasAnswered) {
      const duration = viewModel.getExpireInfo(new Date(viewModel.expireDate));
      return (
        <div className="ask-footer paddingLeftRight-16">
          <AskDuration duration={duration} />
          <AskStatus
            isCreator={isCreator}
            privateResults={viewModel.privateResults}
            anonymousAnswer={viewModel.anonymousAnswer}
          />
        </div>
      );
    }
  }

  renderAskResponse(): React.Node {
    const {
      viewModel: {
        answers,
        polls,
        type,
        totalReceiver,
        isCreator,
        hasAnswered,
        privateResults,
        hasExpired,
        anonymousAnswer
      }
    } = this.props;
    if (
      isCreator === true ||
      (!isCreator && hasAnswered) ||
      (!isCreator && !hasAnswered && hasExpired)
    ) {
      return (
        <div>
          <ModalConsumer>
            {({showModal, hideModal}: {}): ReactNode => (
              <a
                className="result-details"
                onClick={(): {} => {
                  if (answers.length > 0) {
                    showModal(ResultsDetailModal, {
                      anonymousAnswer,
                      hideModal,
                      header: 'Detailed Results',
                      dialogClassName: 'result-details-dialog',
                      answers,
                      options: polls,
                      type
                    });
                  }
                }}
              >
                <AskResponse
                  isCreator={isCreator}
                  privateResults={privateResults}
                  numberOfResponse={answers.length}
                  numberOfRecevier={totalReceiver}
                />
              </a>
            )}
          </ModalConsumer>
        </div>
      );
    } else {
      return (
        <AskStatus
          isCreator={isCreator}
          privateResults={privateResults}
          anonymousAnswer={anonymousAnswer}
        />
      );
    }
  }

  renderAskDuration(): React.Node {
    const {viewModel} = this.props;
    const duration = viewModel.getExpireInfo(new Date(viewModel.expireDate));
    return (
      <div className="ask-duration">
        <AskDuration duration={duration} />
      </div>
    );
  }

  render(): React.ReactNode {
    return (
      <div className="ask-footer paddingLeftRight-16">
        {this.renderAskDuration()}
        {this.renderAskResponse()}
      </div>
    );
  }
}

export default AskFooter;
