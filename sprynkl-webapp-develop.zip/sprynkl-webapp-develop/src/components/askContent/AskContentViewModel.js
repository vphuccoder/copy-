// @flow
import {action, computed, observable} from 'mobx';
import {AskContent, AskType} from 'models';
import {appModel} from 'models/app-model';
import {
  CLOSE_QUESTION_IN_DAY,
  CLOSE_QUESTION_IN_EXPIRED,
  CLOSE_QUESTION_IN_FOOTER
} from 'models/constants/string-constant';
import {postService} from 'services';
import {isExpiredDate} from 'utils/string';
import {DATE_OF_MONTH, DATE_OF_YEAR, MINIMUN_CHARACTER} from '../../models/constants/system';
import PollItemViewModel from '../askContent/answers/PollItemViewModel';

const MS_PER_DAY = 1000 * 24 * 60 * 60;
export default class AskContentViewModel {
  totalReceiver: number = 0;
  from: number = 1;
  to: number = 5;
  fromLabel: string = '';
  toLabel: string = '';
  privateResults: boolean = false;
  anonymousAnswer: boolean = false;
  expireInfo: string = '';
  id: string = '';

  @observable
  answers: [] = [];

  @observable
  answer: string = '';

  polls: Array<> = [];

  @observable
  hasExpired: boolean = false;

  @observable
  reasonText: string = '';

  @observable
  scaleAnswerValue: number = 1;

  @computed
  get showResult(): boolean {
    const {hasAnswered, hasExpired, haveAnswers, isCreator, privateResults} = this;
    return (
      hasExpired ||
      (!hasExpired &&
        ((isCreator && haveAnswers) || (!isCreator && !privateResults && hasAnswered)))
    );
  }

  @computed
  get showAnswer(): boolean {
    const {hasAnswered, hasExpired} = this;
    return !hasExpired && !hasAnswered;
  }

  @computed
  get haveAnswers(): boolean {
    const {answers} = this;
    return answers && answers.length > 0;
  }

  @computed
  get disabledAnswer(): boolean {
    const {hasExpired, isCreator} = this;

    return hasExpired || isCreator;
  }

  @computed
  get isCreator(): boolean {
    const {author} = this;
    return author && author.id === appModel.currentUser.id;
  }

  @computed
  get isValid(): boolean {
    const {answer, type} = this;
    switch (type) {
      case AskType.OPEN:
        return answer.trim() !== '' && answer.length >= MINIMUN_CHARACTER;
      case AskType.POLL:
        return true;
      case AskType.SCALE:
        return true;
      default:
        return false;
    }
  }

  constructor(data: AskContent) {
    this.populateData(data);
  }

  @action
  populateData(data: AskContent) {
    const {
      askContent: {
        anonymousAnswer,
        answers,
        expiredDate,
        id,
        options = [],
        privateResults,
        rank = {},
        type
      },
      author,
      postId,
      question,
      totalReceiver
    } = data;
    this.id = id;
    this.type = type;
    this.answers.push(...answers);
    this.author = author;
    this.question = question;
    this.postId = postId;
    this.privateResults = privateResults;
    this.anonymousAnswer = anonymousAnswer;
    this.expireDate = expiredDate;
    this.polls = options.map((option: {}): PollItemViewModel => PollItemViewModel.map(option));
    this.totalReceiver = totalReceiver;
    this.from = rank.from;
    this.to = rank.to;
    this.fromLabel = rank.fromLabel;
    this.toLabel = rank.toLabel;
    if (expiredDate) {
      this.hasExpired = isExpiredDate(expiredDate);
    }
  }

  @action
  updateAnswer(answers: []) {
    this.answers.clear();
    this.answers.push(...answers);
  }

  @action
  setSelectedPoll(poll: PollItemViewModel) {
    this.polls.forEach((poll: PollItemViewModel) => {
      poll.selected && poll.setSelected(false);
    });
    poll.setSelected(true);
  }

  @action
  updateHasExpired(hasExpired: boolean) {
    this.hasExpired = hasExpired;
  }

  @computed
  get hasAnswered(): boolean {
    const {answers, isCreator} = this;
    if (isCreator) {
      return answers.length > 0;
    }
    if (answers.length > 0) {
      const userResponse = answers.find(
        (answer: {}): boolean =>
          appModel.currentUser && answer.user && answer.user.id === appModel.currentUser.id
      );
      if (userResponse) {
        return true;
      }
    }

    return false;
  }

  @action
  writeAnswer(answer: string) {
    this.answer = answer;
  }

  @action
  clean() {
    this.polls.forEach((poll: PollItemViewModel) => {
      poll.selected && poll.setSelected(false);
    });
    this.scaleAnswerValue = 1;
    this.reasonText = '';
  }

  @action
  async responseAsk(): Promise {
    this.isLoading = false;

    const {expiredDate, postId, reasonText, scaleAnswerValue, type} = this;
    if (expiredDate && isExpiredDate(expiredDate)) {
      return;
    }
    const selectedOption = this.polls.find(
      (poll: PollItemViewModel): PollItemViewModel => poll.selected
    );

    let value = '';

    switch (type) {
      case AskType.OPEN:
        value = this.answer.trim();
        break;
      case AskType.POLL:
        value = selectedOption.value;
        break;
      case AskType.SCALE:
        value = `${scaleAnswerValue}`;
        break;
      default:
        break;
    }

    if (value !== '') {
      try {
        const result = await postService.responseAsk(
          appModel.currentToken.accessToken,
          postId,
          value,
          reasonText
        );
        if (result.askContent && result.askContent.answers) {
          this.updateAnswers(result.askContent.answers);
        }
        this.isLoading = true;
      } catch (ex) {
        this.isLoading = false;
        this.handleError(ex, false);
      } finally {
        this.isLoading = false;
      }
    }
  }

  @action
  updateAnswers(answers: Array<{}>) {
    this.answers = [];
    this.answers.push(...answers);
  }

  getDifferenceBetween(a: Date, b: Date): number {
    const utc1 = Date.UTC(a.getFullYear(), a.getMonth(), a.getDate());
    const utc2 = Date.UTC(b.getFullYear(), b.getMonth(), b.getDate());
    return Math.floor((utc2 - utc1) / MS_PER_DAY);
  }

  getExpireInfo(expireDate: Date): string {
    if (isNaN(expireDate)) return '';

    if (isExpiredDate(expireDate)) {
      return CLOSE_QUESTION_IN_EXPIRED;
    }

    const today = new Date();
    const timeDiff = Math.abs(today.getTime() - expireDate.getTime());
    const remainingDate = Math.ceil(timeDiff / MS_PER_DAY) - 1;

    if (remainingDate > DATE_OF_YEAR) {
      const yearDiff = Math.floor(remainingDate / DATE_OF_YEAR);

      if (yearDiff === 1) {
        return `${CLOSE_QUESTION_IN_FOOTER} ${yearDiff.toString()} year`;
      }
      return `${CLOSE_QUESTION_IN_FOOTER} ${yearDiff.toString()} years`;
    }

    if (remainingDate > DATE_OF_MONTH) {
      const monthDiff = Math.floor(remainingDate / DATE_OF_MONTH);

      if (monthDiff === 1) {
        return `${CLOSE_QUESTION_IN_FOOTER} ${monthDiff.toString()} month`;
      }
      return `${CLOSE_QUESTION_IN_FOOTER} ${monthDiff.toString()} months`;
    }

    if (remainingDate === 0) {
      return `${CLOSE_QUESTION_IN_DAY}`;
    } else if (remainingDate === 1) {
      return `${CLOSE_QUESTION_IN_FOOTER} ${remainingDate.toString()} day`;
    }
    return `${CLOSE_QUESTION_IN_FOOTER} ${remainingDate.toString()} days`;
  }

  @action
  setReasonText(text: string) {
    this.reasonText = text;
  }

  @action
  onScaleAnswerValueChange(value: number) {
    this.scaleAnswerValue = value;
  }
}
