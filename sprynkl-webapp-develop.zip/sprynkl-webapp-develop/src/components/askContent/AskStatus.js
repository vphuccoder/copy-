// @flow
import * as React from 'react';
import {AnonymousIcon, PrivateIcon} from '../baseComponents/svg/Svg';
import {DISABLED_COLOR, ACTIVE_COLOR, PRIMARY_COLOR} from 'models/constants/system';
import {
  ANONYMOUS_TRUE_TOOLTIP,
  ANONYMOUS_FALSE_TOOLTIP,
  PRIVATE_RESULT_TOOLTIP,
  PUBLISH_RESULT_TOOLTIP
} from 'models/constants/string-constant';

class AskStatus extends React.Component {
  render(): React.ReactNode {
    const {privateResults, anonymousAnswer, isCreator} = this.props;

    if (isCreator) {
      return null;
    }

    const privateColor = privateResults ? ACTIVE_COLOR : DISABLED_COLOR;
    const anonymousColor = anonymousAnswer ? PRIMARY_COLOR : DISABLED_COLOR;
    const privateTooltip = privateResults ? ANONYMOUS_TRUE_TOOLTIP : ANONYMOUS_FALSE_TOOLTIP;
    const anonymousTooltip = anonymousAnswer ? PRIVATE_RESULT_TOOLTIP : PUBLISH_RESULT_TOOLTIP;
    return (
      <div className="ask-status">
        <span className="margin-left-right-16" title={anonymousTooltip}>
          <AnonymousIcon fill={anonymousColor} />
        </span>
        <span title={privateTooltip}>
          <PrivateIcon fill={privateColor} />
        </span>
      </div>
    );
  }
}

export default AskStatus;
