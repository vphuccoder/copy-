// @flow
import * as React from 'react';
import './AskResponse.scss';
type PropsType = {
  isCreator: boolean,
  numberOfRecevier: number,
  numberOfResponse: number,
  privateResults: boolean
};

class AskResponse extends React.Component<PropsType> {
  render() {
    const {isCreator, numberOfRecevier, numberOfResponse, privateResults} = this.props;
    const className = numberOfResponse ? 'active response-box' : 'disabled response-box';

    if (!isCreator && privateResults) {
      return (
        <div>
          <div className="response">
            <div className={className}>
              <span className="response-text">My response</span>
            </div>
          </div>
        </div>
      );
    }

    return (
      <div>
        <div className="response">
          <div className={className}>
            <span className="num-of-response">{numberOfResponse}</span>/
            <span className="num-of-receiver">{numberOfRecevier}</span>
            <span className="response-text"> responses</span>
          </div>
        </div>
      </div>
    );
  }
}

export default AskResponse;
