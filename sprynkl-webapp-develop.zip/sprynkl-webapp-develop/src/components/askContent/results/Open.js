// @flow
import * as React from 'react';
class Open extends React.Component {
  render(): React.ReactNode {
    return <div />;
  }
}

export default Open;
