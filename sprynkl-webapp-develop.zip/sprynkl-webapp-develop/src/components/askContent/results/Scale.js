// @flow
import * as React from 'react';
import {observer} from 'mobx-react';
@observer
class Scale extends React.Component {
  getAverageRate(answers: []): number {
    if (answers.length === 0) {
      return 0;
    }

    let totalResponses = 0;
    let totalRates = 0;
    answers.forEach((answer: {}) => {
      if (!answer) {
        return;
      }
      const value: number = +answer.value;
      totalResponses += 1;
      totalRates += value;
    });

    if (totalResponses === 0) {
      return 0;
    }

    let averageRate = totalRates / totalResponses;
    if (totalRates % totalResponses !== 0) {
      averageRate = averageRate.toFixed(1);
    }
    return averageRate;
  }
  render(): React.ReactNode {
    const {answers, to} = this.props;
    const averageRate = this.getAverageRate(answers);
    return (
      <div className="average-rate">
        <span>
          <span className="rate">{averageRate}</span>
          <span className="total">/{to}</span>
        </span>
      </div>
    );
  }
}

export default Scale;
