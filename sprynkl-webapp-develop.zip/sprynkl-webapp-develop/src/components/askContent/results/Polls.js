// @flow
import * as React from 'react';
import BarChart from '../../baseComponents/barChart/BarChart';
import {groupBy} from '../../../utils/utils';
import {observer} from 'mobx-react';
import autobind from 'autobind-decorator';
const MAX_POLLS_ON_VIEW = 5;

type PropsType = {};
@observer
class Polls extends React.Component<PropsType> {
  constructor(props: PropsType) {
    super(props);
    const {options} = this.props;
    this.state = {
      viewAll: options.length <= MAX_POLLS_ON_VIEW
    };
  }

  initData(props: {}): Array<{}> {
    const {answers = [], options = [], total} = props;
    const answerGroups = groupBy(answers, 'value');

    return options.map(
      (item: {}): {} => {
        const {value, label} = item;
        const selectedValue = answerGroups[value] || [];
        return {
          label,
          value: total === 0 ? 0 : ((selectedValue.length / total) * 100).toFixed(0)
        };
      }
    );
  }

  valueFormat(label: string): string {
    return `${label}%`;
  }

  @autobind
  viewAll() {
    const {viewAll} = this.state;

    this.setState({viewAll: !viewAll});
  }

  renderViewAll(): React.Node {
    const {viewAll} = this.state;
    if (!viewAll) {
      return (
        <div className="text-center">
          <div className="view-all-button" onClick={this.viewAll}>
            View all
          </div>
        </div>
      );
    }
  }

  render(): React.ReactNode {
    const options = this.initData(this.props);
    const {viewAll} = this.state;
    const chartData = viewAll ? options : options.slice(0, 5);
    return (
      <div>
        <BarChart data={chartData} valueFormat={this.valueFormat} />
        {this.renderViewAll()}
      </div>
    );
  }
}

export default Polls;
