// @flow
import * as React from 'react';
import {AskType} from 'models';
import {Open, Scale, Polls} from './';
import {observer} from 'mobx-react';
import './Results.scss';
@observer
class Results extends React.Component {
  renderResult(): React.ReactNode {
    const {
      viewModel,
      viewModel: {answers, polls: options, to}
    } = this.props;
    switch (viewModel.type) {
      case AskType.OPEN:
        return <Open />;
      case AskType.POLL:
        return (
          <Polls
            polls={viewModel.polls}
            answers={answers}
            total={answers.length}
            options={options}
          />
        );
      case AskType.SCALE:
        return <Scale answers={viewModel.answers} to={to} />;
    }
  }
  render(): React.ReactNode {
    return <div className="padding-16 ask-result">{this.renderResult()}</div>;
  }
}

export default Results;
