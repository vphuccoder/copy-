// @flow
import * as React from 'react';
import {OPEN_ANSWER_PLACEHOLDER} from 'models/constants/string-constant';

class Open extends React.Component {
  render(): React.ReactNode {
    const {disabled} = this.props;
    const className = disabled ? 'disabled open-question' : 'open-question';
    return <div className={className}>{OPEN_ANSWER_PLACEHOLDER}</div>;
  }
}

export default Open;
