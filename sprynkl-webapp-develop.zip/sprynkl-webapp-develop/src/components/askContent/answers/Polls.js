// @flow
import * as React from 'react';
import PollItem from './PollItem';
import autobind from 'autobind-decorator';
import {observer} from 'mobx-react';
const MAX_POLLS_ON_VIEW = 5;

type PropsType = {};

@observer
class Polls extends React.Component<PropsType> {
  constructor(props: PropsType) {
    super(props);
    const {polls, showAll} = this.props;
    this.state = {
      viewAll: showAll || polls.length <= MAX_POLLS_ON_VIEW
    };
  }

  @autobind
  setSelected(item: PollItemViewModel) {
    const {setSelected, disabled} = this.props;
    if (!disabled) {
      setSelected(item);
    }
  }

  renderPolls(): React.ReactNode {
    const {polls, disabled, keyValue} = this.props;
    const {viewAll} = this.state;
    if (polls && polls.length > 0) {
      const pollsData = viewAll ? polls : polls.slice(0, 5);
      return pollsData.map(
        (poll: {}): React.Node => {
          return (
            <PollItem
              keyValue={keyValue}
              poll={poll}
              key={poll.value}
              setSelected={this.setSelected}
              disabled={disabled}
            />
          );
        }
      );
    }
  }

  @autobind
  viewAll(event: Event) {
    event.preventDefault();
    event.stopPropagation();
    const {viewAll} = this.state;
    this.setState({viewAll: !viewAll});
  }

  renderViewAll(): React.Node {
    const {viewAll} = this.state;
    if (!viewAll) {
      return (
        <div className="text-center">
          <div className="view-all-button" onClick={this.viewAll}>
            View all
          </div>
        </div>
      );
    }
  }

  render(): React.ReactNode {
    const {disabled} = this.props;

    return (
      <div className={`${disabled ? 'disabled' : ''} poll-question`}>
        {this.renderPolls()}
        {this.renderViewAll()}
      </div>
    );
  }
}

export default Polls;
