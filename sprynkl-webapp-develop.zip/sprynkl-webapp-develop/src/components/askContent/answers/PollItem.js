// @flow
import autobind from 'autobind-decorator';
import React, {Component} from 'react';
import TextOverFlow from '../../baseComponents/textOverFlow/TextOverFlow';
import RoundCheckBox from '../../baseComponents/roundCheckbox/RoundCheckbox';
import {Form} from 'react-bootstrap';
import {observer} from 'mobx-react';
import './Polls.scss';
type PropType = {};

@observer
class PollItem extends Component<PropType> {
  @autobind
  onSelect() {
    const {setSelected, poll} = this.props;
    setSelected(poll);
  }

  render(): React.Node {
    const {
      poll: {label, selected, value},
      keyValue
    } = this.props;
    return (
      <Form.Label className="poll-item">
        <RoundCheckBox checked={selected} id={`${keyValue}_${value}`} onChange={this.onSelect} />
        <TextOverFlow textOverflow={label} tooltip={label} className="poll-value paddingLeftRight-8" />
      </Form.Label>
    );
  }
}

export default PollItem;
