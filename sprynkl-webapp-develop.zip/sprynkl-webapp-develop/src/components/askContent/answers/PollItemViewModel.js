// @flow
import {observable, computed, action} from 'mobx';

class PollItemViewModel {
  label: string = '';

  value: number = 0;

  @observable
  selected: boolean = false;

  @action
  setSelected(value) {
    this.selected = value;
  }

  static map(data: {}): PollItemViewModel {
    const poll = new PollItemViewModel();
    poll.value = data.value;
    poll.label = data.label;
    return poll;
  }
}

export default PollItemViewModel;
