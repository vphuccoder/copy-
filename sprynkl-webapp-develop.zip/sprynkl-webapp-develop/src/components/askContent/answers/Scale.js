// @flow
import * as React from 'react';
import autobind from 'autobind-decorator';
import {observer} from 'mobx-react';
import {SliderBar} from '../../baseComponents';
import './Scale.scss';

@observer
class Scale extends React.Component {
  renderLabel(): React.ReactNode {
    const {fromLabel, toLabel} = this.props;
    return (
      <div className="label-container">
        <span className="from-label">{fromLabel}</span>
        <span className="to-label">{toLabel}</span>
      </div>
    );
  }
  @autobind
  onValueChange(value: number) {
    const {onChangeScale, disabled} = this.props;
    if (!disabled) {
      onChangeScale(value);
    }
  }

  renderScale(): React.ReactNode {
    const {from, to, value, disabled} = this.props;

    return (
      <div className="scale-slide-bar">
        <SliderBar
          disabled={disabled}
          minValue={from}
          maxValue={to}
          currentValue={value}
          onValueChange={this.onValueChange}
        />
      </div>
    );
  }

  render(): React.ReactNode {
    const {disabled} = this.props;
    return (
      <div className={`${disabled ? 'disabled' : ''} scale-answer`}>
        {this.renderLabel()}
        {this.renderScale()}
      </div>
    );
  }
}

export default Scale;
