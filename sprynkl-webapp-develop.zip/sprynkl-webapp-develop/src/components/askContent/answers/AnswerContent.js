// @flow
import autobind from 'autobind-decorator';
import React from 'react';
import {AskType} from '../../../models';
import {Open, Polls, Scale} from './';
import './Answers.scss';
type PropsType = {};
export default class AnswerContent extends React.Component<PropsType> {
  @autobind
  setSelected(item: {}) {
    const {viewModel} = this.props;
    viewModel.setSelectedPoll(item);
  }

  @autobind
  onChangeScale(value: number) {
    const {viewModel, openAnswer} = this.props;
    viewModel.onScaleAnswerValueChange(value);
    openAnswer();
  }
  render() {
    const {
      viewModel,
      viewModel: {from, to, fromLabel, toLabel, scaleAnswerValue, postId}
    } = this.props;
    switch (viewModel.type) {
      case AskType.OPEN:
        return <Open disabled={viewModel.disabledAnswer} />;
      case AskType.POLL:
        return (
          <Polls
            keyValue={postId}
            polls={viewModel.polls}
            disabled={viewModel.disabledAnswer}
            setSelected={this.setSelected}
          />
        );
      case AskType.SCALE:
        return (
          <Scale
            disabled={viewModel.disabledAnswer}
            fromLabel={fromLabel}
            toLabel={toLabel}
            from={from}
            to={to}
            value={scaleAnswerValue}
            onChangeScale={this.onChangeScale}
          />
        );
    }
  }
}
