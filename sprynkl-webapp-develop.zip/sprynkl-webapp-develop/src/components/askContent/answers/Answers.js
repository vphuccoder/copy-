// @flow
import React from 'react';
import {ModalConsumer} from '../../../components/context/ModalContext';
import {AnswersAskModal} from '../../modals/answerAskModal';
import {AnswerContent} from './';
import './Answers.scss';

class Answers extends React.Component {
  onCloseModal() {
    const {viewModel} = this.props;
    viewModel.clean();
  }

  render(): React.ReactNode {
    const {
      viewModel,
      viewModel: {disabledAnswer}
    } = this.props;
    return (
      <ModalConsumer>
        {({showModal, hideModal}: {}): ReactNode => {
          const openAnswer = (): {} => {
            if (!disabledAnswer) {
              showModal(AnswersAskModal, {
                hideModal: () => {
                  this.onCloseModal();
                  hideModal();
                },
                header: 'Answer',
                dialogClassName: 'answer-ask-dialog',
                viewModel
              });
            }
          };

          return (
            <a className="answer-ask" onClick={openAnswer}>
              <div className="answers-container">
                <AnswerContent viewModel={viewModel} openAnswer={openAnswer} />
              </div>
            </a>
          );
        }}
      </ModalConsumer>
    );
  }
}

export default Answers;
