// @flow
import * as React from 'react';
import {Answers} from './answers';
import {Results} from './results';
import {observer} from 'mobx-react';

@observer
class AskBody extends React.Component {
  renderAskContainer(): React.ReactNode {
    const {viewModel} = this.props;
    if (viewModel.showResult) {
      return <Results viewModel={viewModel} />;
    }
    if (viewModel.hasAnswered) {
      return null;
    }
    return <Answers viewModel={viewModel} />;
  }
  render(): React.ReactNode {
    return <div className="ask-container-body">{this.renderAskContainer()}</div>;
  }
}

export default AskBody;
