import React, {PureComponent} from 'react';
import autobind from 'autobind-decorator';
import Item from './Item';
import './KarmaSelection.scss';

export default class KarmaSelection extends PureComponent {
  @autobind
  onChange(value) {
    const {onChange} = this.props;
    onChange(value);
  }

  renderItems() {
    const {value, maxValue = 5} = this.props;
    const items = [];
    for (let i = 1; i <= maxValue; i++) {
      items.push(<Item key={i} value={i} active={i <= value} onChange={this.onChange} />);
    }
    return items;
  }

  render() {
    return <div className="karma-selection">{this.renderItems()}</div>;
  }
}
