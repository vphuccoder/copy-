import React, {PureComponent} from 'react';
import autobind from 'autobind-decorator';
import {icons} from '../../components/themes/Icons';
import IcomoonReact from 'icomoon-react';
import iconSet from '~/selection.json';
import './KarmaSelection.scss';

export default class Item extends PureComponent {
  @autobind
  onChange() {
    const {onChange, value} = this.props;
    onChange(value);
  }

  render() {
    const {active} = this.props;
    const className = active ? 'karma-item active' : 'karma-item';
    const color = active ? '#fc4167' : '#b2b4b5';
    return (
      <a onClick={this.onChange}>
        <div className={className}>
          <IcomoonReact iconSet={iconSet} color={color} size={30} icon={icons.heart} />
        </div>
      </a>
    );
  }
}
