// @flow

import React, {Component} from 'react';
import {Dropdown} from 'react-bootstrap';
import autobind from 'autobind-decorator';
import {observer} from 'mobx-react';
import {icons} from '../themes/Icons';
import Icon from '../baseComponents/Icon';
import PostCommentMoreActionToggle from '../baseComponents/CustomSelectToggle';
import {SYSTEM_VARIABLE} from '../../models/constants/index';

type PropsType = {
  canReport: boolean,
  canDelete: boolean,
  iconSize: number
};

type StateType = {
  dropdownOpen: boolean
};

@observer
class PostCommentMoreAction extends Component<PropsType, StateType> {
  constructor(props: PropsType) {
    super(props);
    this.state = {
      dropdownOpen: false
    };
  }

  @autobind
  toggle() {
    this.setState(
      (prevState: StateType): {} => ({
        dropdownOpen: !prevState.dropdownOpen
      })
    );
  }

  @autobind
  onMouseLeave() {
    this.setState({dropdownOpen: false});
  }

  @autobind
  onDelete() {
    const {onDelete} = this.props;
    if (onDelete) {
      onDelete();
    }
  }

  @autobind
  onReport() {
    const {onReport} = this.props;
    if (onReport) {
      onReport();
    }
  }

  renderDeleteComment(canDelete: boolean): React.Node {
    return canDelete === true ? <Dropdown.Item onClick={this.onDelete}>Delete</Dropdown.Item> : null;
  }

  renderReportComment(canReport: boolean): React.Node {
    return canReport === true ? <Dropdown.Item onClick={this.onReport}>Report</Dropdown.Item> : null;
  }

  renderSeparator(canDelete: boolean, canReport: boolean): React.Node {
    return canDelete === true && canReport === true ? <Dropdown.Divider /> : null;
  }

  render(): React.Node {
    const {canDelete, canReport, iconSize} = this.props;
    const iconSizeValue = iconSize ? iconSize : SYSTEM_VARIABLE.ICON_SIZE;

    return (
      <div className="post-comment-more-action">
        <Dropdown onMouseLeave={this.onMouseLeave} show={this.state.dropdownOpen} onToggle={this.toggle}>
          <Dropdown.Toggle className="dropdown-toggle" as={PostCommentMoreActionToggle}>
            <Icon color="#777b7d" iconName={icons.more} size={iconSizeValue} />
          </Dropdown.Toggle>
          <Dropdown.Menu alignRight>
            {this.renderReportComment(canReport)}
            {this.renderSeparator(canDelete, canReport)}
            {this.renderDeleteComment(canDelete)}
          </Dropdown.Menu>
        </Dropdown>
      </div>
    );
  }
}

export default PostCommentMoreAction;
