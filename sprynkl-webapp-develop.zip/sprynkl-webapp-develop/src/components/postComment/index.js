import PostComment from './PostComment';

export {PostComment};
