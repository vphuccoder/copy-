// @flow
import React from 'react';
import type {Node} from 'react';
import {observer} from 'mobx-react';
import autobind from 'autobind-decorator';
import {appModel} from '../../models/app-model';
import {Comment, Group, User} from '../../models';
import ProfileLink from '../../components/baseComponents/profileLink';
import {RichText} from '../richText';
import {ReportPostModal} from '../modals';
import {renderUserAvatar} from '../baseComponents/svg/Avatar';
import {POST_COMMENT_WARNING} from '../../models/constants/string-constant';
import './PostComment.scss';
import PostCommentMoreAction from './PostCommentMoreAction';
import PostCommentViewModel from './PostCommentViewModel';

type PropsType = {
  comment: Comment,
  postGroup: Group,
  activeUserList: User[],
  onClickHashTag: void,
  onClickTag: void
};

type StateType = {
  isMouseOver: boolean,
  showReportComment: boolean
};

@observer
class PostComment extends React.Component<PropsType, StateType> {
  viewModel: PostCommentViewModel;

  constructor(props: PropsType) {
    super(props);

    const {postGroup} = props;
    this.viewModel = new PostCommentViewModel(postGroup);

    this.state = {
      isMouseOver: false,
      showReportComment: false
    };
  }

  @autobind
  onMouseOver() {
    this.setState({isMouseOver: true});
  }

  @autobind
  onMouseLeave() {
    this.setState({isMouseOver: false});
  }

  @autobind
  onShowReportComment() {
    this.setState({showReportComment: true});
  }

  @autobind
  oncloseReportComment() {
    this.setState({showReportComment: false});
  }

  @autobind
  onClickHashTag(hashTag: string) {
    const {onClickHashTag} = this.props;
    if (onClickHashTag) {
      onClickHashTag(hashTag);
    }
  }

  @autobind
  onClickTag(user: User) {
    const {onClickTag} = this.props;
    if (onClickTag) {
      onClickTag(user);
    }
  }

  @autobind
  onReport(description: string) {
    const {comment} = this.props;
    this.oncloseReportComment();
    this.viewModel.onReportComment(comment, description);
  }

  @autobind
  onDeleteComment() {
    const {onDelete, comment, postGroup} = this.props;
    appModel.dialogViewModel.showConfirm(
      `${POST_COMMENT_WARNING} ${postGroup.name}?`,
      'Delete Comment',
      'Delete',
      'Cancel',
      () => {
        this.viewModel.deleteComment(comment);
        if (onDelete) {
          onDelete(comment);
        }
      },
      () => {}
    );
  }

  @autobind
  renderMoreActions(): Node {
    const canDelete = this.viewModel.canDeleteComment(this.props.comment);
    return (
      <PostCommentMoreAction
        canReport={!canDelete}
        canDelete={canDelete}
        iconSize={20}
        onDelete={this.onDeleteComment}
        onReport={this.onShowReportComment}
      />
    );
  }

  render(): Node {
    const {activeUserList, comment} = this.props;
    const {isMouseOver, showReportComment} = this.state;
    const {author, content} = comment;
    return (
      <div className="post-comment">
        <ReportPostModal
          show={showReportComment}
          title="Report Comment"
          onClose={this.oncloseReportComment}
          onSubmit={this.onReport}
        />
        <ProfileLink user={author}>{renderUserAvatar(author.avatar, author.defaultAvatar, 32)}</ProfileLink>
        <div className="comment-box" onMouseOver={this.onMouseOver} onMouseLeave={this.onMouseLeave}>
          <div className="author">
            <ProfileLink user={author} />
          </div>
          <div className="comment">
            <RichText
              content={content}
              activeUserList={activeUserList}
              onClickTag={this.onClickTag}
              onClickHashTag={this.onClickHashTag}
            />
          </div>
          {isMouseOver && this.renderMoreActions()}
        </div>
      </div>
    );
  }
}
export default PostComment;
