// @flow

import {action} from 'mobx';
import {BasePageViewModel} from '../../pages/BasePageViewModel';
import {Comment, Group} from '../../models';
import {appModel} from '../../models/app-model';
import {postService} from '../../services';

class PostCommentViewModel extends BasePageViewModel {
  group: Group;

  constructor(postGroup: Group) {
    super();
    this.group = postGroup;
  }

  @action
  canDeleteComment(comment: Comment): boolean {
    const {currentUser} = appModel;
    if (!comment) {
      return false;
    }

    if (!currentUser) {
      return false;
    }

    const {author} = comment;
    if (author && author.id === currentUser.id) {
      return true;
    }

    if (!this.group) {
      return false;
    }
    return currentUser.isLeadGroup(this.group.id);
  }

  @action
  async deleteComment(comment: Comment): Promise {
    if (this.canDeleteComment(comment)) {
      const {currentToken, dialogViewModel} = appModel;
      const {accessToken} = currentToken;
      try {
        dialogViewModel.showProgressIndicator();
        await postService.deleteComment(accessToken, comment.id);
        dialogViewModel.hideProgressIndicator();
      } catch (e) {
        dialogViewModel.hideProgressIndicator();
        this.handleError(e, true);
      }
    }
  }

  @action
  async onReportComment(comment: Comment, description: string): Promise {
    if (description && description !== '' && description.length >= 3) {
      const {currentToken, dialogViewModel, alertMessageViewModel} = appModel;
      const {accessToken} = currentToken;
      try {
        dialogViewModel.showProgressIndicator();
        await postService.reportComment(accessToken, comment.id, description);
        dialogViewModel.hideProgressIndicator();
        alertMessageViewModel.showAlert(
          'Thanks for looking out for your team. Your team lead has your report.'
        );
      } catch (e) {
        dialogViewModel.hideProgressIndicator();
        this.handleError(e, true);
      }
    }
  }
}

export default PostCommentViewModel;
