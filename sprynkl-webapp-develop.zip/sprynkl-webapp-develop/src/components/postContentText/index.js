import PostContentText from './PostContentText';

export {PostContentText};
