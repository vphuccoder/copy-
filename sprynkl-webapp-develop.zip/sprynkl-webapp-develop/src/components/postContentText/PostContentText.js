// @flow

import {observer} from 'mobx-react';
import React from 'react';
import autobind from 'autobind-decorator';
import {ACTIVE_BLUE_COLOR} from '../../models/constants/system';
import {hashtagRegExp, isHashTag, isTag, isURL, tagRegExp, urlReg} from '../../utils/regex';
import {icons} from '../../components/themes/Icons';
import Icon from '../baseComponents/Icon';
import {RichText} from '../richText';
import './PostContentText.scss';

type PropsType = {
  postContent: string,
  onClickHashTag: void,
  showFullContent: boolean,
  responsedAsk: () => void
};

type StateType = {
  showSeeMore: boolean
};

@observer
class PostContentText extends React.Component<PropsType, StateType> {
  state = {
    showSeeMore: false
  };

  componentDidMount() {
    const {showFullContent} = this.props;
    if (!showFullContent) {
      this.checkShouldRenderSeeMore();
    }
  }

  @autobind
  checkShouldRenderSeeMore() {
    const {postContent} = this.props;
    const {showSeeMore} = this.state;
    const lines = postContent.split(/\r?\n/);

    if (!showSeeMore) {
      if (postContent.length > 400 || lines.length > 5) {
        this.setState({showSeeMore: true});
      }
    }
  }

  @autobind
  sliceContent(): string {
    const {postContent} = this.props;

    let finalString = '';
    if (postContent.length > 400) {
      if (!isTag(postContent) && !isHashTag(postContent) && !isURL(postContent)) {
        return postContent.slice(0, 350);
      }

      const tagContents = postContent.split(tagRegExp);
      tagContents.forEach(
        (tag: string): string => {
          const urlContents = tag.split(urlReg);
          urlContents.forEach(
            (url: string): string => {
              let urlElements = [];
              if (isHashTag(url)) {
                urlElements = url.split(hashtagRegExp);
              } else if (isURL(url)) {
                urlElements = url.split(urlReg);
              }

              urlElements.forEach((element: string) => {
                const lines = element.split(/\r?\n/);
                lines.forEach((line: string) => {
                  if (finalString.length < 400) {
                    finalString += line;
                  }
                });
              });
            }
          );
        }
      );
      return finalString;
    } else {
      const eachLine = postContent.split(/\r?\n/);
      if (eachLine.length > 5) {
        for (let i = 0, l = 4; i < l; i++) {
          if (eachLine[i] === '' && i <= 2) {
            finalString += i !== 2 ? '\n\n' : '\n';
          }
          finalString += eachLine[i];
        }
        return finalString;
      }
      return postContent;
    }
  }

  @autobind
  setStatus() {
    this.setState({showSeeMore: false});
  }

  @autobind
  onClickHashTag(hashTag: string) {
    const {onClickHashTag} = this.props;
    if (onClickHashTag) {
      onClickHashTag(hashTag);
    }
  }

  @autobind
  renderSeeMore(): React.Node {
    const {showSeeMore} = this.state;
    if (showSeeMore) {
      return (
        <span className="btn-see-more">
          ...
          <span onClick={this.setStatus}>{' See more'}</span>
        </span>
      );
    }
    return null;
  }

  renderResponse(): React.ReactNode {
    const {responsedAsk} = this.props;

    if (responsedAsk) {
      return <Icon color={ACTIVE_BLUE_COLOR} iconName={icons.checkAlt} size={12} />;
    }
  }

  render(): React.Node {
    const {postContent} = this.props;
    const {showSeeMore} = this.state;

    return (
      <span className="post-content-text">
        <RichText content={showSeeMore ? this.sliceContent() : postContent} onClickHashTag={this.onClickHashTag} />
        {this.renderResponse()}
        {this.renderSeeMore()}
      </span>
    );
  }
}

export default PostContentText;
