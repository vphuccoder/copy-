// @flow
import {action, observable} from 'mobx';
import {InputRecevierViewModel} from '../../inputReceiver';
import {BasePageViewModel} from '../../../pages/BasePageViewModel';

export default class CreatePostViewModel extends BasePageViewModel {
  type: string = '';

  @observable
  selectedTeam: {} = null;

  @observable
  content: string = '';

  @observable
  photos: Array<> = [];

  @observable
  anonymous: boolean = false;

  @observable
  recevierViewModel: InputReceiverViewModel = null;

  constructor(data: {}) {
    super();
    this.type = data.type;
    this.recevierViewModel = new InputRecevierViewModel();
  }

  @action
  setAnonymous() {
    this.anonymous = !this.anonymous;
  }

  @action
  changeContent(content: string) {
    this.content = content;
  }

  @action
  addImage(image: {}) {
    // TODO images list
    this.photos.push(image);
  }

  @action
  deleteImage() {
    this.photos = [];
  }
}
