// @flow
import autobind from 'autobind-decorator';
import {icons} from 'components/themes/Icons';
import IcomoonReact from 'icomoon-react';
import {DISABLED_COLOR, PRIMARY_COLOR} from 'models/constants/system';
import React from 'react';
import iconSet from '~/selection.json';
import {isContains} from '../../../utils/utils';
import {AnonymousIcon} from '../../baseComponents/svg/Svg';
import ToggleSwitch from '../../baseComponents/toggleSwitch/ToggleSwitch';

export default class CreatePostConfig extends React.PureComponent {
  @autobind
  setAnonymous() {
    const {setAnonymous} = this.props;
    setAnonymous();
  }

  @autobind
  selectImage(e: SyntheticInputEvent<HTMLInputElement>) {
    const image = e.target.files[0];
    const imageUrl = URL.createObjectURL(image);
    const type = image.type;
    if (!isContains(type, 'image')) {
      return;
    }
    const {selectImage} = this.props;
    selectImage(image, imageUrl);
  }

  render(): React.Node {
    const {anonymous} = this.props;

    const fill = anonymous ? PRIMARY_COLOR : DISABLED_COLOR;

    return (
      <div className="config">
        <label className="add-photo-label">
          <div className="add-photo config-item paddingLeftRight-4">
            <span className="marginLeftRight-8">
              <IcomoonReact color="#2786e9" icon={icons.photo} iconSet={iconSet} size={24} />
            </span>
            <span className="marginLeftRight-8">{'Photo'}</span>
            <input
              accept=".jpg,.jpeg,.png"
              className="file-input"
              onChange={this.selectImage}
              type="file"
              value={''}
            />
          </div>
        </label>
        <label className="select-anonymous-label">
          <div className="anonymous config-item">
            <span className="marginLeftRight-8">
              <AnonymousIcon className="marginLeftRight-8" fill={fill} />
            </span>
            <span className="marginLeftRight-8 ">{'Anonymous'}</span>
            <span className="float-right toggle-switch">
              <ToggleSwitch onChange={this.setAnonymous} type="checkbox" value={anonymous} />
            </span>
          </div>
        </label>
      </div>
    );
  }
}
