// @flow
import React, {Component} from 'react';
import {Container, Row, Col} from 'react-bootstrap';
import {AskIcon, ThanksIcon, VoiceIcon} from '../../baseComponents/svg/Svg';
import './CreatePostModal.scss';
import {ModalConsumer} from '../../context/ModalContext';
import {CreateVoice, CreateThanks, CreateAsk} from '../';
import {DISCARD_ALERT_MESSAGE} from '../../../models/constants/string-constant';

type PropsType = {
  showAlert: void,
  alertMessage?: string
};

class CreatePostModal extends Component<PropsType, StateType> {
  render(): React.Node {
    const {addPostToFeeds, showAlert} = this.props;
    return (
      <Container className="left-panel create-post-dialog">
        <Row>
          <Col>
            <ModalConsumer>
              {({showModal, hideModal}: {}): ReactNode => (
                <div className="post-item">
                  <a
                    className="create-voice"
                    onClick={(): {} =>
                      showModal(CreateVoice, {
                        hideModal: () => {
                          this.props.hideModal(DISCARD_ALERT_MESSAGE);
                        },
                        showAlert,
                        alertMessage: DISCARD_ALERT_MESSAGE,
                        header: 'Create a voice',
                        dialogClassName: 'create-voice-dialog',
                        addPostToFeeds: addPostToFeeds
                      })
                    }
                  >
                    <VoiceIcon width="77" height="77" />
                    <span>Share Voice</span>
                  </a>
                </div>
              )}
            </ModalConsumer>
          </Col>
          <div className="vertical-separator" />
          <Col>
            <ModalConsumer>
              {({showModal, hideModal}: {}): ReactNode => (
                <div className="post-item">
                  <a
                    className="say-thanks"
                    onClick={(): {} =>
                      showModal(CreateThanks, {
                        hideModal: () => {
                          this.props.hideModal(DISCARD_ALERT_MESSAGE);
                        },
                        showAlert,
                        alertMessage: DISCARD_ALERT_MESSAGE,
                        header: 'Say thanks',
                        dialogClassName: 'create-thanks-dialog',
                        addPostToFeeds: addPostToFeeds
                      })
                    }
                  >
                    <ThanksIcon width="77" height="77" />
                    <span>Say thanks</span>
                  </a>
                </div>
              )}
            </ModalConsumer>
          </Col>
          <div className="vertical-separator" />
          <Col>
            <ModalConsumer>
              {({showModal, hideModal}: {}): ReactNode => (
                <div className="post-item">
                  <a
                    className="ask-question"
                    onClick={(): {} =>
                      showModal(CreateAsk, {
                        hideModal: () => {
                          this.props.hideModal(DISCARD_ALERT_MESSAGE);
                        },
                        showAlert,
                        alertMessage: DISCARD_ALERT_MESSAGE,
                        header: 'Say thanks',
                        dialogClassName: 'create-thanks-dialog',
                        addPostToFeeds: addPostToFeeds
                      })
                    }
                  >
                    <AskIcon width="77" height="77" />
                    <span>Ask a question</span>
                  </a>
                </div>
              )}
            </ModalConsumer>
          </Col>
        </Row>
      </Container>
    );
  }
}

export default CreatePostModal;
