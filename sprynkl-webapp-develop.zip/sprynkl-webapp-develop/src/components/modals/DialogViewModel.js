// @flow

import {observable, action} from 'mobx';
const defaultTitle = 'Sprynkl';
const defaultButton = 'OK';

class DialogViewModel {
  @observable
  modal = {
    showProgressIndicator: false,
    title: '',
    show: false,
    body: null,
    buttons: []
  };

  @action
  showProgressIndicator() {
    this.modal.showProgressIndicator = true;
  }

  @action
  hideProgressIndicator() {
    this.hideDialog();
  }

  @action
  showPrompt(message: string, title: string = 'Sprynkl') {
    this.modal.body = message;
    this.modal.show = true;
    this.modal.title = title;
    this.modal.buttons = [
      {
        title: defaultButton,
        name: 'ok',
        variant: 'secondary',
        handleButtonClick: () => {
          this.hideDialog();
        }
      }
    ];
  }

  @action
  showConfirm(
    message: string,
    title: string = defaultTitle,
    buttonOkTitle: string,
    buttonCancelTitle: string,
    okAction: void,
    cancelAction: void
  ) {
    this.modal.body = message;
    this.modal.show = true;
    this.modal.title = title;

    this.modal.buttons = [
      {
        title: buttonOkTitle,
        name: defaultButton,
        variant: 'primary',
        handleButtonClick: () => {
          this.hideDialog();
          if (okAction) {
            okAction();
          }
        }
      },
      {
        title: buttonCancelTitle,
        name: 'cancel',
        variant: 'secondary',
        handleButtonClick: () => {
          this.hideDialog();
          if (cancelAction) {
            cancelAction();
          }
        }
      }
    ];
  }

  @action
  hideDialog() {
    this.modal.body = null;
    this.modal.show = false;
    this.modal.showProgressIndicator = false;
    this.modal.title = '';
  }
}

export {DialogViewModel};
