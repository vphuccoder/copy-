// @flow
import autobind from 'autobind-decorator';
import {action, observable} from 'mobx';
import {User} from 'models';
import {appModel} from 'models/app-model';
import {userService} from 'services';

class ProfileViewModel {
  @observable
  user: User = null;

  @observable
  fetchingData: boolean = false;

  @observable
  userNotFound: boolean = false;

  @autobind
  @action
  async onShow(userId: string) {
    try {
      this.userNotFound = false;
      this.fetchingData = true;
      const user = await userService.getUserById(appModel.currentToken.accessToken, userId);
      this.user = user;
    } catch {
      this.userNotFound = true;
    } finally {
      this.fetchingData = false;
    }
  }
}

export {ProfileViewModel};
