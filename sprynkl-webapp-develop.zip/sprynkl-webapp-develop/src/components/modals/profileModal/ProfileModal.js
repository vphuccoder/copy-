/**
 * @format
 * @flow
 */

import autobind from 'autobind-decorator';
import React, {Component, Fragment} from 'react';
import type {Node} from 'react';
import {withRouter} from 'react-router';
import type {RouterHistory} from 'react-router';
import {observer} from 'mobx-react';
import {Modal, Spinner, Container} from 'react-bootstrap';
import {User, InstantMessage} from 'models';
import {renderUserAvatar} from 'components/baseComponents/svg/Avatar';
import {ProfileViewModel} from './ProfileViewModel';
import './ProfileModal.scss';

type SectionItemType = {
  label: string,
  value: string,
  action?: string
};

type StateType = {};

type PropsType = {
  show: boolean,
  canCloseDialog: boolean,
  onClose: () => void,
  userId: string,
  history: RouterHistory
};

@withRouter
@observer
class ProfileModal extends Component<PropsType, StateType> {
  viewModel: ProfileViewModel;

  constructor(props: PropsType) {
    super(props);
    this.viewModel = new ProfileViewModel();
  }

  componentDidUpdate() {
    if (this.viewModel.userNotFound) {
      document.location.href = '/notfound';
    }
  }

  @autobind
  handleClose() {
    // handle close
    const {canCloseDialog, onClose, history} = this.props;
    if (canCloseDialog === true && onClose) {
      onClose();
      history.push('/');
    }
  }

  @autobind
  onShow() {
    this.viewModel.onShow(this.props.userId);
  }

  @autobind
  renderSectionInfo(header: string, data: Array<SectionItemType>): Node {
    return (
      <div className="section">
        <div className="section-header">{header}</div>
        <div className="section-info">
          {data.map(
            ({label, value, action}: SectionItemType, index: number): ?Node => {
              if (value) {
                return (
                  <div key={index} className="item">
                    <div className="label">{label}</div>
                    {action ? (
                      <a href={action} className="value">
                        {value}
                      </a>
                    ) : (
                      <div className="value">{value}</div>
                    )}
                  </div>
                );
              }
            }
          )}
        </div>
      </div>
    );
  }

  @autobind
  getAboutSectionData(user: User): Array<SectionItemType> {
    const {fullName, nickName, bio, position, team, office} = user || {};
    const {name: officeName} = office || {};
    return [
      {label: 'Full Name', value: fullName},
      {label: 'Nickname', value: nickName},
      {label: 'Bio', value: bio},
      {label: 'Position', value: position},
      {label: 'Team', value: team},
      {label: 'Office', value: officeName}
    ];
  }

  @autobind
  getInstantMessageDetail(instantMessage: InstantMessage): Array<SectionItemType> {
    if (instantMessage) {
      return Object.keys(instantMessage).map(
        (key: string): SectionItemType => {
          const userId = instantMessage[key];
          let action = '';
          if (key === 'skype') {
            action = `skype:${userId}?chat`;
          }
          return {label: key, value: instantMessage[key], action};
        }
      );
    }
    return [];
  }

  @autobind
  getOtherSectionData(user: User): Array<SectionItemType> {
    const {about, instantMessage, email, phone} = user || {};
    return [
      {label: 'About', value: about},
      {label: 'Email', value: email, action: `mailto:${email}`},
      ...this.getInstantMessageDetail(instantMessage),
      {label: 'Phone', value: phone, action: `tel:${phone}`}
    ];
  }
  render(): Node {
    const {show} = this.props;
    const {fetchingData, user, userNotFound} = this.viewModel;
    const {fullName, avatar, defaultAvatar, karma} = user || {};
    return (
      !userNotFound && (
        <Modal dialogClassName="profile-modal" show={show} onHide={this.handleClose} onShow={this.onShow} centered>
          <Modal.Body className="body">
            <Container>
              {fetchingData ? (
                <div className="loading">
                  <Spinner as="span" animation="border" className="status" aria-hidden="true" />
                </div>
              ) : (
                <Fragment>
                  <div className="header">
                    {renderUserAvatar(avatar, defaultAvatar, 84)}
                    <div className="name">{fullName}</div>
                    <div className="karma">{karma} KARMA</div>
                  </div>
                  <div className="info-detail">
                    {this.renderSectionInfo('About', this.getAboutSectionData(user))}
                    {this.renderSectionInfo('Talk to me', this.getOtherSectionData(user))}
                  </div>
                </Fragment>
              )}
            </Container>
          </Modal.Body>
        </Modal>
      )
    );
  }
}

export default ProfileModal;
