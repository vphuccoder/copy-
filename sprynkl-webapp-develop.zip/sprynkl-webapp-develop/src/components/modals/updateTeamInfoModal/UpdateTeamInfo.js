// @flow
import React, {Component, Fragment} from 'react';
import type {Node} from 'react';
import {observer} from 'mobx-react';
import {Modal, Form, Button, Spinner} from 'react-bootstrap';
import autobind from 'autobind-decorator';
import Icon from 'components/baseComponents/Icon';
import AvatarEditor from 'components/baseComponents/avatarEditor';
import {renderGroupAvatar} from '../../baseComponents/svg/Avatar';
import {Group} from '../../../models';
import {UpdateTeamInfoViewModel} from './UpdateTeamInfoViewModel';
import './UpdateTeamInfo.scss';

type PropsType = {
  team: Group,
  show: boolean,
  onClose: () => void,
  canCloseDialog: boolean
};

@observer
class UpdateTeamInfo extends Component<PropsType> {
  viewModel: UpdateTeamInfoViewModel;

  constructor(props: PropsType) {
    super(props);
    this.viewModel = new UpdateTeamInfoViewModel();
  }

  fileInput: ?HTMLInputElement;
  @autobind
  handleClose() {
    const {canCloseDialog, onClose} = this.props;
    if (canCloseDialog === true && onClose) {
      onClose();
    }
  }

  @autobind
  getInputFileElement(e: ?HTMLInputElement) {
    this.fileInput = e;
  }

  @autobind
  openAvatarEditor() {
    if (this.fileInput) {
      this.fileInput.click();
    }
  }

  @autobind
  closeAvatarEditor() {
    this.viewModel.closeAvatarEditor();
  }

  @autobind
  onCompleteEditAvatar(file: File) {
    this.viewModel.completeEditAvatar(file);
  }

  @autobind
  onFileSelected(event: SyntheticInputEvent<HTMLInputElement>) {
    this.viewModel.updateAvatar(event.target.files[0]);
  }

  @autobind
  onShow() {
    this.viewModel.setUpdateInfo(this.props.team);
  }

  @autobind
  updateTeamDescription(event: SyntheticInputEvent<HTMLInputElement>) {
    this.viewModel.updateTeamDescription(event.target.value);
  }

  @autobind
  updateTeamName(event: SyntheticInputEvent<HTMLInputElement>) {
    this.viewModel.updateTeamName(event.target.value);
  }

  @autobind
  async updateTeamInfo() {
    const result = await this.viewModel.updateTeamInfo();
    if (result) {
      this.handleClose();
    }
  }

  render(): Node {
    const {show} = this.props;
    const {
      teamName,
      description,
      avatarFile,
      avatarUrl,
      defaultAvatar,
      isUpdatingTeamInfo,
      isOpenAvatarEditor
    } = this.viewModel;
    const trimmedName = teamName.trim();
    const disableUpdate = trimmedName === '' || trimmedName.length < 3 || isUpdatingTeamInfo;
    return (
      <Fragment>
        <Modal
          dialogClassName="update-team-info-modal"
          show={show}
          onHide={this.handleClose}
          onShow={this.onShow}
          centered
        >
          <Modal.Header>
            <Modal.Title className="title">Update team info</Modal.Title>
          </Modal.Header>
          <Modal.Body className="body">
            <Form.Group className="team-name">
              <div className="team-avatar" role="button" onClick={this.openAvatarEditor}>
                {renderGroupAvatar(teamName, avatarUrl, defaultAvatar, 64)}
                <div className="overlay">
                  <input
                    value={''}
                    type="file"
                    className="file-input"
                    accept=".jpg,.jpeg,.png"
                    onChange={this.onFileSelected}
                    ref={this.getInputFileElement}
                  />
                  <Icon iconName="camera" color="#fff" size={24} />
                </div>
              </div>
              <Form.Control className="team-name-input" name="name" value={teamName} onChange={this.updateTeamName} />
            </Form.Group>
            <Form.Group>
              <Form.Label>ABOUT US</Form.Label>
              <Form.Control
                as="textarea"
                rows="2"
                name="description"
                value={description}
                maxLength="140"
                onChange={this.updateTeamDescription}
              />
            </Form.Group>
            <div className="actions">
              <Button variant="danger" disabled={disableUpdate} onClick={this.updateTeamInfo}>
                {isUpdatingTeamInfo && (
                  <Spinner as="span" animation="border" size="sm" role="status" aria-hidden="true" />
                )}
                <span> Update</span>
              </Button>
            </div>
          </Modal.Body>
        </Modal>
        <AvatarEditor
          onComplete={this.onCompleteEditAvatar}
          file={avatarFile}
          open={isOpenAvatarEditor}
          onClose={this.closeAvatarEditor}
        />
      </Fragment>
    );
  }
}

export default UpdateTeamInfo;
