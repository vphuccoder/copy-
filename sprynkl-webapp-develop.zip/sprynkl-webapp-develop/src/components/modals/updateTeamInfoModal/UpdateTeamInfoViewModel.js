// @flow
import {observable, action} from 'mobx';
import autobind from 'autobind-decorator';
import {appModel} from 'models/app-model';
import {Group} from 'models';
import {groupService, fileService} from 'services';

class UpdateTeamInfoViewModel {
  @observable
  groupId: string;

  @observable
  teamName: string = '';

  @observable
  description: string;

  @observable
  avatarFile: ?File;

  @observable
  editedAvatarFile: ?File;

  @observable
  avatarUrl: string;

  @observable
  defaultAvatar: string;

  @observable
  isUpdatingTeamInfo: ?boolean = false;

  @observable
  isOpenAvatarEditor: boolean = false;

  @autobind
  @action
  async setUpdateInfo(group: $Shape<Group>) {
    const {name, description, avatar, id, defaultAvatar} = group;
    this.isUpdatingTeamInfo = false;
    this.groupId = id;
    this.teamName = name;
    this.description = description;
    this.avatarUrl = avatar;
    this.defaultAvatar = defaultAvatar;
  }

  @autobind
  @action
  async updateTeamInfo(): Promise<boolean> {
    this.isUpdatingTeamInfo = true;
    try {
      const token = appModel.currentToken.accessToken;
      let uploadedAvatarId;
      if (this.editedAvatarFile) {
        const {name: fileName, type: fileType} = this.editedAvatarFile;
        const file = await fileService.uploadFile(token, this.editedAvatarFile, fileName, fileType);
        uploadedAvatarId = file.id;
      }

      const newGroup = await groupService.updateGroup(token, this.groupId, {
        name: this.teamName,
        description: this.description,
        avatar: uploadedAvatarId
      });
      appModel.setCurrentGroup(newGroup);
      this.editedAvatarFile = null;
      return true;
    } finally {
      this.isUpdatingTeamInfo = null;
    }
  }

  @autobind
  @action
  updateTeamName(name: string) {
    this.teamName = name;
  }

  @autobind
  @action
  updateTeamDescription(description: string) {
    this.description = description;
  }

  @autobind
  @action
  updateAvatar(file: ?File) {
    if (file) {
      this.avatarFile = file;
      this.openAvatarEditor();
    }
  }

  @autobind
  revokeAvatar() {
    try {
      this.avatarFile = null;
      URL.revokeObjectURL(this.avatarUrl);
    } catch {
      // do nothing
    }
  }

  @autobind
  openAvatarEditor() {
    this.isOpenAvatarEditor = true;
  }

  @autobind
  closeAvatarEditor() {
    this.isOpenAvatarEditor = false;
  }

  @autobind
  @action
  completeEditAvatar(file: File) {
    this.revokeAvatar();
    this.editedAvatarFile = file;
    this.avatarUrl = URL.createObjectURL(file);
    this.closeAvatarEditor();
  }
}

export {UpdateTeamInfoViewModel};
