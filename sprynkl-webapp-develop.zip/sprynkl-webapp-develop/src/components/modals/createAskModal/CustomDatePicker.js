// @flow
import React from 'react';
import {Clock} from '../../baseComponents/svg/Svg';
import './CreateAsk.scss';

export default class CustomDatePicker extends React.Component {
  render(): React.Node {
    const {value, onClick} = this.props;
    const displayValue = value === '' ? 'Never' : value;
    return (
      <button className="custom-date-picker" onClick={onClick}>
        <span className="clock-icon">
          <Clock />
        </span>
        <span className="date-picker-value paddingLeftRight-4">{displayValue}</span>
        {value !== '' && <span className="paddingLeftRight-8" />}
      </button>
    );
  }
}
