// @flow
import autobind from 'autobind-decorator';
import {observer} from 'mobx-react';
import {ACTIVE_COLOR, DISABLED_COLOR, PRIMARY_COLOR} from 'models/constants/system';
import React, {Fragment} from 'react';
import {Button, Form, Spinner, Tab, Tabs} from 'react-bootstrap';
import DatePicker from '../../baseComponents/datePicker/DatePicker';
import {AnonymousIcon, PrivateIcon} from '../../baseComponents/svg/Svg';
import ToggleSwitch from '../../baseComponents/toggleSwitch/ToggleSwitch';
import InputRecevicer from '../../inputReceiver/InputReceiver';
import './CreateAsk.scss';
import CreateAskViewModel from './CreateAskViewModel';
import CustomDatePicker from './CustomDatePicker';
import {Open, Polls, Scale} from './askContent';
import {Prompt} from 'react-router-dom';

type PropsType = {
  showAlert: void,
  alertMessage: string
};

@observer
class CreateVoice extends React.Component {
  viewModel: CreateAskViewModel = null;

  constructor(props: PropsType) {
    super(props);
    this.viewModel = new CreateAskViewModel();
  }

  @autobind
  setAnonymousAnswer() {
    const {viewModel} = this;
    viewModel.setAnonymousAnswer();
  }

  @autobind
  changeContent(e: React.EventHandler) {
    const {viewModel} = this;
    viewModel.changeContent(e.target.value);
  }

  @autobind
  setPrivateResult() {
    const {viewModel} = this;
    viewModel.setPrivateResult();
  }

  @autobind
  onSelectTab(value: string) {
    const {viewModel} = this;
    viewModel.selectTab(value);
  }

  @autobind
  onChangeQuestion(e: {}) {
    const {viewModel} = this;
    viewModel.updateQuestion(e.target.value);
    this.props.showAlert(viewModel.showAlert);
  }

  @autobind
  changeFromLabel(e: {}) {
    const {viewModel} = this;
    viewModel.changeFromLabel(e.target.value);
  }

  @autobind
  changeToLabel(e: {}) {
    const {viewModel} = this;
    viewModel.changeToLabel(e.target.value);
  }

  @autobind
  deletePoll(item: AnswerChoiceViewModel) {
    const {viewModel} = this;
    viewModel.deletePoll(item);
  }

  @autobind
  onUpdatePoll(value: string, item: AnswerChoiceViewModel) {
    const {viewModel} = this;
    viewModel.onUpdatePoll(value, item);
    this.props.showAlert(viewModel.showAlert);
  }

  renderPostContent(): React.Node {
    const {
      viewModel: {
        activeTab,
        anonymousAnswer,
        answerChoices,
        askDuration,
        changeScaleTo,
        fromLabel,
        privateResults,
        question,
        recevierViewModel,
        to,
        toLabel
      }
    } = this;
    const privateColor = privateResults ? ACTIVE_COLOR : DISABLED_COLOR;
    const anonymousColor = anonymousAnswer ? PRIMARY_COLOR : DISABLED_COLOR;
    if (recevierViewModel.enableSearch) {
      return null;
    }
    return (
      <Fragment>
        <div className="post-content">
          <div className="body">
            <Form.Group>
              <Tabs className="ask-container" defaultActiveKey={activeTab} onSelect={this.onSelectTab}>
                <Tab className="ask-tabs" eventKey="open" title="Open">
                  <Open onChangeQuestion={this.onChangeQuestion} question={question} />
                </Tab>
                <Tab className="ask-tabs" eventKey="poll" title="Poll">
                  <Polls
                    answerChoices={answerChoices}
                    deletePoll={this.deletePoll}
                    onChangeQuestion={this.onChangeQuestion}
                    onUpdatePoll={this.onUpdatePoll}
                    question={question}
                  />
                </Tab>
                <Tab className="ask-tabs" eventKey="scale" title="Scale">
                  <Scale
                    changeFromLabel={this.changeFromLabel}
                    changeToLabel={this.changeToLabel}
                    fromLabel={fromLabel}
                    onChangeQuestion={this.onChangeQuestion}
                    onChangeScaleTo={changeScaleTo}
                    question={question}
                    scaleTo={to}
                    toLabel={toLabel}
                  />
                </Tab>
              </Tabs>
            </Form.Group>
          </div>
          <div className="config">
            <div className="ask-duration-setting">
              <span className="ask-duration-text">Ask Ends</span>
              <DatePicker
                customInput={<CustomDatePicker />}
                isClearable
                minDate={new Date()}
                onChange={this.setAskDuration}
                placeholderText={'mm/dd/yyyy'}
                selected={askDuration}
              />
            </div>
            <label className="select-anonymous-label">
              <div className="anonymous config-item">
                <span className="anonymous-answer-item">
                  <span className="marginLeftRight-8">
                    <AnonymousIcon className="marginLeftRight-8" fill={anonymousColor} />
                  </span>
                  <div className="private-result-text">
                    <span className="marginLeftRight-8">{'Anonymous answer'}</span>
                    <span className="marginLeftRight-8 high-light-text">{'Everyone you ask can see the answers'}</span>
                  </div>
                </span>
                <span className="toggle-switch">
                  <ToggleSwitch onChange={this.setAnonymousAnswer} type="checkbox" value={anonymousAnswer} />
                </span>
              </div>
            </label>
            <label className="private-result-label">
              <div className="private-result config-item paddingLeftRight-4">
                <span className="private-result-item">
                  <span className="marginLeftRight-8">
                    <PrivateIcon fill={privateColor} />
                  </span>
                  <div className="private-result-text">
                    <span className="marginLeftRight-8">{'Private results'}</span>
                    <span className="marginLeftRight-8 high-light-text">{'Keep respondents’ names visible'}</span>
                  </div>
                </span>
                <span className="toggle-switch">
                  <ToggleSwitch type="checkbox" value={privateResults} onChange={this.setPrivateResult} />
                </span>
              </div>
            </label>
          </div>
        </div>
      </Fragment>
    );
  }

  @autobind
  closeSearch() {
    const {viewModel} = this;
    this.props.showAlert(viewModel.showAlert);
    viewModel.recevierViewModel.turnOffSearch();
  }

  renderSearch(): React.Node {
    const {recevierViewModel} = this.viewModel;

    return (
      <div className="search">
        <InputRecevicer viewModel={recevierViewModel} />
      </div>
    );
  }

  @autobind
  async savePost() {
    const {viewModel} = this;
    const {hideModal, addPostToFeeds, showAlert} = this.props;
    const result = await viewModel.save();

    showAlert(false);

    if (result && addPostToFeeds) {
      addPostToFeeds(result);
    }
    hideModal();
  }

  renderFooter(): React.Node {
    const {viewModel} = this;
    const {isLoading} = viewModel;
    if (viewModel.recevierViewModel.enableSearch) {
      return (
        <div className="create-post-footer float-right paddingTop-4">
          <Button className="send-button" onClick={this.closeSearch}>
            Done
          </Button>
        </div>
      );
    }
    return (
      <div className="create-post-footer float-right paddingTop-4">
        <Button className="send-button" disabled={!viewModel.isValid || isLoading} onClick={this.savePost}>
          {isLoading && (
            <Spinner
              as="span"
              className="marginLeftRight-4"
              animation="border"
              size="sm"
              role="status"
              aria-hidden="true"
            />
          )}
          Send
        </Button>
      </div>
    );
  }

  @autobind
  setAskDuration(value: DateTime) {
    const {viewModel} = this;
    viewModel.setAskDuration(value);
  }

  render(): React.Node {
    return (
      <div className="create-ask">
        <Prompt message={this.props.alertMessage} when={this.viewModel.showAlert} />
        {this.renderSearch()}
        {this.renderPostContent()}
        {this.renderFooter()}
      </div>
    );
  }
}

export default CreateVoice;
