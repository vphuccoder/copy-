// @flow
import {CreatePostViewModel} from '../createPostModal';
import {computed, action, observable} from 'mobx';
import {appModel} from '../../../models/app-model';
import {postService} from '../../../services';
import {PostViewModel} from '../../feeds';
import AnswerChoiceViewModel from './AnswerChoiceViewModel';
import {ASK} from '../../../models/post-model';

const MIN_CONTENT = 3;
const MIN_PULLS = 2;
const MAX_PULLS = 20;

export default class CreateVoiceViewModel extends CreatePostViewModel {
  constructor() {
    super({type: ASK});
    const firstPollItem = new AnswerChoiceViewModel({index: 0, id: 0});
    const secondPollItem = new AnswerChoiceViewModel({index: 1, id: 1});
    this.answerChoices.push(firstPollItem, secondPollItem);
  }

  @observable
  isLoading: boolean = false;

  @observable anonymousAnswer: boolean = false;

  @observable privateResults: boolean = false;

  @observable askDuration: DateTime = null;

  @observable question: string = '';

  @observable
  activeTab: string = 'open';

  @observable
  answerChoices: Array<> = [];

  @observable from: number = 1;

  @observable to: number = 5;

  @observable fromLabel: string = '';

  @observable toLabel: string = '';

  get validAnserChoices(): Array<{}> {
    return this.answerChoices.filter((item: AnswerChoiceViewModel): boolean => item.answer.trim() !== '');
  }

  @computed
  get showAlert(): boolean {
    const {recevierViewModel, question, activeTab, validAnserChoices} = this;

    return (
      question.trim().length > 0 ||
      recevierViewModel.selectedMembers.length > 0 ||
      (activeTab === 'poll' && validAnserChoices.length >= 0)
    );
  }

  @computed
  get isValid(): boolean {
    const {
      recevierViewModel: {selectedGroup, members}
    } = this;
    if (this.activeTab === 'poll' && this.validAnserChoices.length < MIN_PULLS) {
      return false;
    }

    return (
      this.question.trim() !== '' &&
      this.question.trim().length >= MIN_CONTENT &&
      selectedGroup &&
      selectedGroup.id &&
      members.filter((member: MemberItemViewModel): boolean => member.selected).length > 0
    );
  }

  @action
  updateQuestion(value: string) {
    this.question = value;
  }

  @action
  selecteTab(tab: string) {
    this.selecteTab = tab;
  }

  buildOptions(): Array<string> {
    if (this.activeTab === 'poll') {
      return this.validAnserChoices.map((item: AnswerChoiceViewModel): string => item.answer);
    }
    return [];
  }

  buildRank(): {} {
    if (this.activeTab === 'scale') {
      return {
        from: this.from,
        fromLabel: this.fromLabel,
        to: this.to,
        toLabel: this.toLabel
      };
    }
  }

  buildExpiredDate(): Date {
    return this.askDuration ? this.askDuration.setHours(23, 59, 59, 999) : null;
  }

  buildDataForSave(): {} {
    const {members, selectedGroup} = this.recevierViewModel;

    const options = this.buildOptions();
    const rank = this.buildRank();
    const expiredDate = this.buildExpiredDate();
    const selectedMember = members.filter((member: MemberItemViewModel): boolean => member.selected);

    return {
      type: this.type,
      sendTo: selectedMember,
      group: selectedGroup.id,
      anonymous: false,
      content: this.question.trim(),
      textContent: this.question.trim(),
      hashTags: [],
      isPrivate: true,
      askContent: {
        type: this.activeTab,
        anonymousAnswer: this.anonymousAnswer,
        privateResults: this.privateResults,
        expiredDate,
        options,
        rank
      }
    };
  }

  @action
  selectTab(tab: string) {
    this.activeTab = tab;
  }

  @action
  async save(): PostViewModel {
    const {accessToken} = appModel.currentToken;
    const data = this.buildDataForSave();
    this.isLoading = true;
    try {
      this.setLoading(true);

      const result = await postService.createPost(accessToken, data);
      this.isLoading = false;
      return result;
    } catch (ex) {
      this.handleError(ex, true);
      this.isLoading = false;
    }
  }

  @action
  setPrivateResult() {
    this.privateResults = !this.privateResults;
  }

  @action
  setAnonymousAnswer() {
    this.anonymousAnswer = !this.anonymousAnswer;
  }

  @action
  setAskDuration(value: DateTime) {
    this.askDuration = value;
  }

  @action
  changeFromLabel = (text: string) => {
    this.fromLabel = text;
  };

  @action
  changeToLabel = (text: string) => {
    this.toLabel = text;
  };

  @action
  changeScaleTo = (range: number) => {
    this.to = range;
  };

  @action
  onUpdatePoll(text: string, answerChoice: AnswerChoiceViewModel) {
    answerChoice.updateAnswer(text);
    const lastItem = this.answerChoices.slice(-1)[0];
    if (
      lastItem.answer.trim() !== '' &&
      this.answerChoices.length < MAX_PULLS &&
      this.validAnserChoices.length === this.answerChoices.length
    ) {
      this.answerChoices.push(new AnswerChoiceViewModel({id: lastItem.index + 1, index: lastItem.index + 1}));
    }
  }

  @action
  deletePoll(answerChoice: AnswerChoiceViewModel) {
    if (this.answerChoices.length > MIN_PULLS) {
      const index = this.answerChoices.indexOf(answerChoice);
      this.answerChoices.splice(index, 1);
    } else {
      answerChoice.updateAnswer('');
    }
  }
}
