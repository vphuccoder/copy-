import React from 'react';
import {Dropdown, DropdownButton, Form} from 'react-bootstrap';
import {SCALE_QUESTION_PLACEHOLDER} from '../../../../models/constants/string-constant';

class Scale extends React.Component {
  onChangeScaleTo(value) {
    const {onChangeScaleTo} = this.props;
    onChangeScaleTo(value);
  }

  render() {
    const {
      changeFromLabel,
      changeToLabel,
      fromLabel,
      onChangeQuestion,
      question,
      scaleTo,
      toLabel
    } = this.props;

    return (
      <Form>
        <Form.Group>
          <Form.Control
            as="textarea"
            className="text-body padding-0 paddingTopBottom-8 question"
            maxLength={250}
            name="description"
            onChange={onChangeQuestion}
            placeholder={SCALE_QUESTION_PLACEHOLDER}
            rows={4}
            value={question}
          />
        </Form.Group>
        <Form.Group className="scale-item">
          <Form.Label className="item-label">From</Form.Label>
          <DropdownButton className="marginLeftRight-8 scale-from" disabled title="1">
            <Dropdown.Item>1</Dropdown.Item>
            <Dropdown.Item>5</Dropdown.Item>
          </DropdownButton>
          <Form.Control
            className="padding-8"
            maxLength={25}
            onChange={changeFromLabel}
            placeholder={'Add label'}
            type="search"
            value={fromLabel}
          />
        </Form.Group>
        <Form.Group className="scale-item">
          <Form.Label className="item-label">To</Form.Label>
          <DropdownButton className="marginLeftRight-8 scale-to" title={scaleTo}>
            <Dropdown.Item onClick={() => this.onChangeScaleTo(5)}>5</Dropdown.Item>
            <Dropdown.Item onClick={() => this.onChangeScaleTo(10)}>10</Dropdown.Item>
          </DropdownButton>
          <Form.Control
            className="padding-8"
            maxLength={25}
            onChange={changeToLabel}
            placeholder={'Add label'}
            type="search"
            value={toLabel}
          />
        </Form.Group>
      </Form>
    );
  }
}

export default Scale;
