// @flow
import autobind from 'autobind-decorator';
import {observer} from 'mobx-react';
import React from 'react';
import {Form} from 'react-bootstrap';
import {POLL_QUESTION_PLACEHOLDER} from '../../../../models/constants/string-constant';
import AnswerChoiceViewModel from '../AnswerChoiceViewModel';
import PollItem from './PollItem';

type PropsType = {
  answerChoices: Array<AnswerChoiceViewModel>,
  deletePoll: () => mixed
};

@observer
class Polls extends React.Component<PropsType> {
  @autobind
  onChange(value: string, item: AnswerChoiceViewModel) {
    const {deletePoll, onUpdatePoll} = this.props;
    if (value === '') {
      deletePoll(item);
    }
    onUpdatePoll(value, item);
  }

  renderPolls(): React.Node {
    const {answerChoices} = this.props;
    return answerChoices.map(
      (item: {}, index: number): React.Node => {
        return <PollItem item={item} key={`${item.id}_${index}`} onChange={this.onChange} />;
      }
    );
  }

  render(): React.Node {
    const {onChangeQuestion, question} = this.props;
    return (
      <Form>
        <Form.Group className="marginTopBotton-0">
          <Form.Control
            as="textarea"
            className="text-body padding-0 paddingTopBottom-8 question"
            maxLength={250}
            name="description"
            onChange={onChangeQuestion}
            placeholder={POLL_QUESTION_PLACEHOLDER}
            rows={4}
            value={question}
          />
        </Form.Group>
        <Form.Group className="polls-options">{this.renderPolls()}</Form.Group>
      </Form>
    );
  }
}

export default Polls;
