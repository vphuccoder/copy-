// @flow
import React from 'react';
import {Form} from 'react-bootstrap';
import autobind from 'autobind-decorator';
import {observer} from 'mobx-react';

type PropType = {
  onChange: () => mixed,
  item: AnswerChoiveViewModel
};

@observer
class PollItem extends React.Component<PropType> {
  @autobind
  onChange(e: Event) {
    const {item, onChange} = this.props;
    onChange(e.target.value, item);
  }
  render(): React.Node {
    const {item} = this.props;
    return (
      <Form.Control
        className="marginTopBottom-8"
        type="search"
        placeholder={'Option'}
        maxLength={120}
        value={item.answer}
        onChange={this.onChange}
      />
    );
  }
}

export default PollItem;
