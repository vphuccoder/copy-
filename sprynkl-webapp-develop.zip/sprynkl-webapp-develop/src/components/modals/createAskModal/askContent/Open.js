import React from 'react';
import {Form} from 'react-bootstrap';
import {OPEN_QUESTION_PLACEHOLDER} from '../../../../models/constants/string-constant';

class Open extends React.Component {
  render() {
    const {onChangeQuestion, question} = this.props;
    return (
      <Form.Group>
        <Form.Control
          as="textarea"
          className="text-body padding-0 paddingTopBottom-8 question"
          maxLength={250}
          name="description"
          onChange={onChangeQuestion}
          placeholder={OPEN_QUESTION_PLACEHOLDER}
          rows={5}
          value={question}
        />
      </Form.Group>
    );
  }
}

export default Open;
