// @flow
import {observable, computed} from 'mobx';

export default class AnswerChoice {
  index: number = 0;

  id: number = 0;

  @observable
  answer: string = '';

  @computed
  get validChoce(): boolean {
    return this.answer !== '';
  }

  constructor(item: {}) {
    this.index = item.index;
    this.id = item.id;
  }

  updateAnswer(text: string) {
    this.answer = text;
  }
}
