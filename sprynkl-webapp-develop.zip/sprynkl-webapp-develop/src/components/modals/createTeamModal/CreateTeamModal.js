// @flow

import React, {Component} from 'react';
import {Modal, Form, Col, Button} from 'react-bootstrap';
import autobind from 'autobind-decorator';
import {getRandomGroupAvatarIndex} from '../../baseComponents/svg/Avatar';
import {groupService, userService} from '../../../services';
import {appModel} from '../../../models/app-model';
import {
  INPUT_TEAM_NAME_ERROR_MESS,
  INPUT_TEAM_NAME_FOOTER_MESSAGE,
  INPUT_TEAM_NAME_FOOTER_TITLE,
  INPUT_TEAM_NAME_SIGN_IN_ANOTHER_EMAIL,
  INPUT_TEAM_NAME_TITLE,
  INPUT_TEAM_NAME_TITLE_DESCRIPTION
} from '../../../models/constants/string-constant';
import {CreateTeamBackground} from '../../baseComponents/svg/Svg';
import './CreateTeamModal.scss';
import {withRouter} from 'react-router-dom';

type StateType = {
  canCloseDialog: boolean,
  show: boolean,
  signInClick: void,
  onClose: void,
  canCreateTeam: boolean
};

type PropsType = {
  show: boolean
};
@withRouter
class CreateTeamModal extends Component<PropsType, StateType> {
  constructor(props: PropsType) {
    super(props);
    this.state = {teamName: '', canCreateTeam: true};
  }

  @autobind
  handleClose() {
    // handle close app
    const {canCloseDialog, onClose} = this.props;
    if (canCloseDialog === true && onClose) {
      onClose();
    }
  }

  @autobind
  signInClick() {
    const {signInClick} = this.props;

    if (signInClick) {
      signInClick();
    }
  }

  @autobind
  isValidateTeamName(): boolean {
    const {teamName} = this.state;
    return teamName.length >= 3;
  }

  @autobind
  async createClick() {
    const {teamName} = this.state;

    if (this.isValidateTeamName() === false) {
      appModel.dialogViewModel.showPrompt(INPUT_TEAM_NAME_ERROR_MESS);
    } else {
      try {
        this.setState({canCreateTeam: false});
        const {accessToken} = appModel.currentToken;
        const group = await groupService.createGroup(accessToken, teamName, getRandomGroupAvatarIndex());
        const user = await userService.getUser(accessToken);
        appModel.setCurrentUser(user);
        appModel.setCurrentGroup(group);
        this.props.history.push(`/group/${group.id}`);
        const {onClose} = this.props;
        if (onClose) {
          onClose();
        }
      } catch (e) {
        this.setState({canCreateTeam: true});
        appModel.dialogViewModel.showPrompt(e.message);
      }
    }
  }

  @autobind
  onTeamNameChange(event) {
    this.setState({teamName: event.target.value});
  }

  @autobind
  handleExited() {
    this.setState({teamName: '', canCreateTeam: true});
  }

  render(): React.Node {
    const {show, canCloseDialog} = this.props;
    const {teamName, canCreateTeam} = this.state;
    return (
      <Modal
        dialogClassName="create-team-modal"
        show={show}
        onHide={this.handleClose}
        centered
        onExited={this.handleExited}
      >
        <Modal.Header closeButton={canCloseDialog}>
          <Modal.Title>{INPUT_TEAM_NAME_TITLE}</Modal.Title>
        </Modal.Header>
        <Modal.Body>
          <div className="message message-1">{INPUT_TEAM_NAME_TITLE_DESCRIPTION}</div>
          <div className="image-container">
            <CreateTeamBackground />
          </div>
          <Form>
            <Form.Row>
              <Col sm={8}>
                <Form.Control
                  type="text"
                  placeholder="Your team name"
                  value={teamName}
                  onChange={this.onTeamNameChange}
                />
              </Col>
              <Col sm={4}>
                <Button
                  className="col-sm-12"
                  type="button"
                  variant="danger"
                  onClick={this.createClick}
                  disabled={!canCreateTeam}
                >
                  Create
                </Button>
              </Col>
            </Form.Row>
          </Form>
          <div className="message message-2">{INPUT_TEAM_NAME_FOOTER_TITLE}</div>
          <div className="message message-1">{INPUT_TEAM_NAME_FOOTER_MESSAGE}</div>
          <div className="sign-in">
            <a href="#" onClick={this.signInClick}>
              {INPUT_TEAM_NAME_SIGN_IN_ANOTHER_EMAIL}
            </a>
          </div>
        </Modal.Body>
      </Modal>
    );
  }
}

export default CreateTeamModal;
