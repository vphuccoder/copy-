/**
 * @format
 * @flow
 */

import autobind from 'autobind-decorator';
import React, {Component} from 'react';
import {Button, Col, Container, Modal, Row} from 'react-bootstrap';
import {Group, User, UserGroup} from '../../../models';
import {appModel} from '../../../models/app-model';
import {GroupRoles} from '../../../models/group-roles';
import {userService} from '../../../services';
import {renderGroupAvatar} from '../../baseComponents/svg/Avatar';
import './JoinTeamModal.scss';
import {TextOverFlow} from '../../baseComponents';
import {withRouter} from 'react-router-dom';

type StateType = {};

type PropsType = {
  createClick: void,
  onClose: void,
  show: boolean,
  signInClick: void,
  user: User
};
@withRouter
class JoinTeamModal extends Component<PropsType, StateType> {
  userGroups: UserGroup = [];

  @autobind
  handleClose() {
    // handle close
    const {canCloseDialog, onClose} = this.props;
    if (canCloseDialog === true && onClose) {
      onClose();
    }
  }

  @autobind
  signInClick() {
    const {signInClick} = this.props;

    if (signInClick) {
      signInClick();
    }
  }

  @autobind
  createClick() {
    const {createClick} = this.props;

    if (createClick) {
      createClick();
    }
  }

  @autobind
  async joinTeam(group: Group) {
    try {
      const user = await userService.confirmGroup(appModel.currentToken.accessToken, group.id, 'join');
      appModel.setCurrentUser(user);
      appModel.setCurrentGroup(group);
      this.props.history.push(`/group/${group.id}`);
      const {onClose} = this.props;
      if (onClose) {
        onClose();
      }
    } catch (e) {
      appModel.dialogViewModel.showPrompt(e.message);
    }
  }

  @autobind
  renderTeamItem(userGroup: UserGroup): React.Node {
    const {group} = userGroup;
    return (
      <Container className="team-item" key={group.id}>
        <Row>
          <Col className="column column-1" sm={2}>
            {renderGroupAvatar(group.name, group.avatar, group.defaultAvatar, 72)}
          </Col>
          <Col className="column column-2" sm={7}>
            <div className="team-item-detail-container">
              <TextOverFlow className="team-name" textOverflow={group.name} />
              <div className="team-detail">{group.totalMembers} members</div>
              <div className="team-detail">Invited by {userGroup.invitedBy.fullName}</div>
            </div>
          </Col>
          <Col className="column column-3" sm={3}>
            <Button className="join-button" onClick={() => this.joinTeam(group)} type="button" variant="danger">
              Join
            </Button>
          </Col>
        </Row>
      </Container>
    );
  }

  @autobind
  renderTeamItems(): React.Node[] {
    const nodes = [];
    this.userGroups.forEach((userGroup) => {
      nodes.push(this.renderTeamItem(userGroup));
    }, this);

    return nodes;
  }

  render(): React.Node {
    const {canCloseDialog, show, user} = this.props;

    if (user) {
      this.userGroups = user.groups.filter((ug) => ug.role == GroupRoles.INVITED);
    }

    return (
      <Modal centered dialogClassName="join-team-modal" onHide={this.handleClose} show={show}>
        <Modal.Header closeButton={canCloseDialog}>
          <Modal.Title>Join a team</Modal.Title>
        </Modal.Header>
        <Modal.Body>
          <div className="team-list">{this.renderTeamItems()}</div>
          <div className="message-1">Want to get your team on Sprynkl?</div>
          <Button className="create-team" onClick={this.createClick} variant="outline-secondary">
            Create a team
          </Button>
          <div className="sign-in">
            <a href="#" onClick={this.signInClick}>
              Sign in with another email address
            </a>
          </div>
        </Modal.Body>
      </Modal>
    );
  }
}

export default JoinTeamModal;
