// @flow
import * as React from 'react';
import {AskType} from 'models';
import {Open, Scale, Polls} from '.';
import {Button, Spinner, Form} from 'react-bootstrap';
import './AnswersAskModal.scss';
import {observer} from 'mobx-react';
import autobind from 'autobind-decorator';
import {ANSWER_REASON_PLACEHOLDER} from '../../../models/constants/string-constant';

@observer
class AnswersAskModal extends React.Component {
  @autobind
  setSelected(item: PollItemViewModel) {
    const {viewModel} = this.props;
    viewModel.setSelectedPoll(item);
  }
  @autobind
  onChangeScale(value: number) {
    const {viewModel} = this.props;
    viewModel.onScaleAnswerValueChange(value);
  }
  renderAnswer(): React.ReactNode {
    const {
      viewModel,
      viewModel: {from, to, fromLabel, toLabel, scaleAnswerValue}
    } = this.props;
    switch (viewModel.type) {
      case AskType.OPEN:
        return <Open viewModel={viewModel} />;
      case AskType.POLL:
        return (
          <Polls
            polls={viewModel.polls}
            disabled={viewModel.disabledAnswer}
            setSelected={this.setSelected}
            showAll
          />
        );
      case AskType.SCALE:
        return (
          <Scale
            fromLabel={fromLabel}
            toLabel={toLabel}
            from={from}
            to={to}
            onChangeScale={this.onChangeScale}
            value={scaleAnswerValue}
          />
        );
    }
  }

  @autobind
  onSubmit() {
    const {viewModel, hideModal} = this.props;
    viewModel.responseAsk();
    hideModal();
  }

  renderFooter(): React.ReactNode {
    const {
      viewModel,
      viewModel: {isLoading}
    } = this.props;
    return (
      <div className="answer-ask-footer float-right paddingTop-4">
        <Button
          className="send-button"
          disabled={!viewModel.isValid || isLoading}
          onClick={this.onSubmit}
        >
          {isLoading && (
            <Spinner
              as="span"
              className="marginLeftRight-4"
              animation="border"
              size="sm"
              role="status"
              aria-hidden="true"
            />
          )}
          Submit
        </Button>
      </div>
    );
  }

  renderQuestion(): React.ReactNode {
    const {viewModel} = this.props;

    return <div className="question">{viewModel.question}</div>;
  }

  @autobind
  changeReasonText(e: Event) {
    const {viewModel} = this.props;
    viewModel.setReasonText(e.target.value);
  }

  renderReason(): React.ReactNode {
    const {
      viewModel: {type}
    } = this.props;
    if (type !== AskType.OPEN) {
      return (
        <div className="answer-reason">
          <Form.Group>
            <Form.Control
              className="text-body paddingLeftRight-16 paddingTopBottom-8"
              as="textarea"
              rows={5}
              name="description"
              placeholder={ANSWER_REASON_PLACEHOLDER}
              maxLength={250}
              onChange={this.changeReasonText}
            />
          </Form.Group>
        </div>
      );
    }
  }

  render(): React.ReactNode {
    return (
      <div className="answers-container-modal">
        {this.renderQuestion()}
        {this.renderAnswer()}
        {this.renderReason()}
        {this.renderFooter()}
      </div>
    );
  }
}

export default AnswersAskModal;
