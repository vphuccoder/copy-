// @flow
import * as React from 'react';
import {Scale as AnswerScale} from '../../askContent/answers';
class Scale extends React.Component {
  render(): React.ReactNode {
    const {props} = this;
    return (
      <div>
        <AnswerScale {...props} />
      </div>
    );
  }
}

export default Scale;
