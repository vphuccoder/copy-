// @flow
import * as React from 'react';
import {Polls as AnswersPoll} from '../../askContent/answers';
class Polls extends React.Component {
  render(): React.ReactNode {
    const {props} = this;
    return (
      <div>
        <AnswersPoll {...props} />
      </div>
    );
  }
}

export default Polls;
