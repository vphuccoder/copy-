// @flow
import * as React from 'react';
import {OPEN_ANSWER_PLACEHOLDER} from 'models/constants/string-constant';
import {Form} from 'react-bootstrap';
import autobind from 'autobind-decorator';
import {observer} from 'mobx-react';

class Open extends React.Component {
  @autobind
  changeAnswer(e) {
    const {viewModel} = this.props;
    viewModel.writeAnswer(e.target.value);
  }
  render(): React.ReactNode {
    const {disabled} = this.props;
    return (
      <Form.Group>
        <Form.Control
          className="text-body paddingLeftRight-16 paddingTopBottom-8"
          as="textarea"
          rows={5}
          name="description"
          placeholder={OPEN_ANSWER_PLACEHOLDER}
          maxLength={250}
          onChange={this.changeAnswer}
        />
      </Form.Group>
    );
  }
}

export default Open;
