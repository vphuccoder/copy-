/**
 * @format
 * @flow
 */

import autobind from 'autobind-decorator';
import React, {Component} from 'react';
import {Button, Modal, Form, Col} from 'react-bootstrap';
import './ReportPostModal.scss';

type PropsType = {
  show: boolean,
  title: string,
  onClose: void,
  onSubmit: void
};

type StateType = {
  isValid: boolean,
  description: string
};

class ReportPostModal extends Component<PropsType, StateType> {
  constructor(props: PropsType) {
    super(props);
    this.state = {isValid: false, description: ''};
  }

  @autobind
  handleClose() {
    const {onClose} = this.props;
    if (onClose) {
      onClose();
    }
  }

  @autobind
  checkValidity(description: string): boolean {
    const isValid = description && description !== '' && description.trim().length >= 3;
    return isValid;
  }

  @autobind
  handleSubmit() {
    event.preventDefault();
    event.stopPropagation();
    const {description} = this.state;
    if (this.checkValidity(description) === true) {
      // handle send report
      const {onSubmit} = this.props;
      if (onSubmit) {
        onSubmit(description);
      }
    }
    this.setState({validated: true});
  }

  @autobind
  onDescriptionChange(event: Event) {
    const description = event.target.value;
    const isValid = this.checkValidity(description);
    this.setState({description, isValid});
  }

  render(): React.Node {
    const {show, title} = this.props;
    const {isValid, description} = this.state;
    return (
      <Modal show={show} onHide={this.handleClose} centered>
        <Modal.Header closeButton>
          <Modal.Title>{title}</Modal.Title>
        </Modal.Header>
        <Modal.Body>
          <Form id="main-form" onSubmit={this.handleSubmit}>
            <Form.Row>
              <Form.Group as={Col} md="12">
                <Form.Label>Tell your Team lead why this isn't appropriate.</Form.Label>
                <Form.Control
                  as="textarea"
                  type="text"
                  name="description"
                  placeholder='For example: "This post uses fould language".'
                  required
                  value={description}
                  onChange={this.onDescriptionChange}
                  maxLength={256}
                />
              </Form.Group>
            </Form.Row>
          </Form>
        </Modal.Body>
        <Modal.Footer>
          <Button variant="primary" form="main-form" type="submit" disabled={!isValid}>
            Send
          </Button>
        </Modal.Footer>
      </Modal>
    );
  }
}

export default ReportPostModal;
