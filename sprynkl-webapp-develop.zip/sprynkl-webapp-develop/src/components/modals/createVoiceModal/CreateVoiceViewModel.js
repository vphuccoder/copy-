// @flow
import {CreatePostViewModel} from '../createPostModal';
import {computed, action, observable} from 'mobx';
import {appModel} from '../../../models/app-model';
import {fileService, postService} from '../../../services';
import {PostViewModel} from 'components/feeds';
const MIN_CONTENT = 3;

export default class CreateVoiceViewModel extends CreatePostViewModel {
  constructor() {
    super({type: 'voice'});
  }

  @observable
  isLoading: boolean = false;

  @computed
  get showAlert(): boolean {
    const {recevierViewModel, content, photos} = this;

    return content.trim().length > 0 || recevierViewModel.selectedMembers.length > 0 || photos.length > 0;
  }

  @computed
  get isValid(): boolean {
    const {
      recevierViewModel: {selectedGroup, members}
    } = this;
    return (
      this.content.trim() !== '' &&
      this.content.trim().length >= MIN_CONTENT &&
      selectedGroup &&
      selectedGroup.id &&
      members.filter((member: MemberItemViewModel): boolean => member.selected).length > 0
    );
  }

  buildDataForSave(): {} {
    const {members, selectedGroup, activeMembers} = this.recevierViewModel;

    const selectedMember = members.filter((member: MemberItemViewModel): boolean => member.selected);
    const isPrivate = selectedMember.length !== activeMembers.length;
    return {
      type: this.type,
      sendTo: isPrivate ? selectedMember : [],
      group: selectedGroup.id,
      anonymous: this.anonymous,
      content: this.content.trim(),
      textContent: this.content.trim(),
      hashTags: [],
      images: this.images,
      isPrivate
    };
  }

  @action
  async save(): PostViewModel {
    const {accessToken} = appModel.currentToken;
    const data = this.buildDataForSave();
    this.isLoading = true;
    try {
      this.setLoading(true);

      const imageObject = this.photos && this.photos[0];

      if (imageObject) {
        const {name: fileName, type: fileType} = imageObject;
        const file = await fileService.uploadFile(accessToken, imageObject, fileName, fileType);
        if (file && file.id) {
          data.images = [file.id];
        }
      }

      const result = await postService.createPost(appModel.currentToken.accessToken, data);
      this.isLoading = false;
      return result;
    } catch (ex) {
      this.handleError(ex, true);
      this.isLoading = false;
    }
  }
}
