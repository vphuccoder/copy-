// @flow
import React, {Component, Fragment} from 'react';
import type {Node} from 'react';
import {observer} from 'mobx-react';
import {Modal, Form, Dropdown, Spinner} from 'react-bootstrap';
import autobind from 'autobind-decorator';
import ProfileLink from 'components/baseComponents/profileLink';
import {renderUserAvatar} from '../../baseComponents/svg/Avatar';
import Icon from '../../baseComponents/Icon';
import {appModel} from '../../../models/app-model';
import {GroupUser} from 'models';
import './SeeAllMembers.scss';
import {SeeAllMembersViewModel} from './SeeAllMembersViewModel';
import MoreActionToggle from '../../baseComponents/CustomSelectToggle';
import {formatStringTemplate} from '../../../utils/string';

type StateType = {};

type ConfirmationType = {
  header: string,
  message: string,
  cancel: string,
  ok: string
};

type ActionType = {
  action: (groupUser: GroupUser) => void,
  name: string,
  confirmation: ConfirmationType,
  highlight?: boolean
};

type PropsType = {
  groupId: string,
  show: boolean,
  onClose: () => void,
  canCloseDialog: boolean,
  isLead: boolean,
  isOwner: boolean,
  showInviteTeammateDialog: () => void
};

@observer
class SeeAllMembers extends Component<PropsType, StateType> {
  actionList = {
    makeOwner: {
      name: 'Make owner',
      action: this.makeOwner,
      confirmation: {
        header: 'Transfer Team Owner?',
        message:
          'A team can have only one owner. By clicking on Transfer, "${fullName}" will be the new team owner, and you will go back to being the team lead.',
        cancel: 'Cancel',
        ok: 'Transfer Owner'
      }
    },
    makeLead: {
      name: 'Make team lead',
      action: this.makeLead,
      confirmation: {
        header: 'Make Team Lead?',
        message: 'As Team Lead, "${fullName}" will help moderate this team.',
        cancel: 'Cancel',
        ok: 'Make Lead'
      }
    },
    removeLead: {
      name: 'Remove as lead',
      action: this.removeLead,
      confirmation: {
        header: 'Remove as Team Lead?',
        message: '"${fullName}" will no longer be able to manage this team.',
        cancel: 'Cancel',
        ok: 'Remove'
      }
    },
    leaveRole: {
      name: 'Remove as lead',
      action: this.removeLead,
      confirmation: {
        header: 'Leave Team Lead Role?',
        message: 'Are you sure that you want to give up your Team Lead privileges?',
        cancel: 'Cancel',
        ok: 'Leave Role'
      }
    },
    removeFromTeam: {
      name: 'Remove from team',
      action: this.removeFromTeam,
      confirmation: {
        header: 'Remove Member',
        message: 'Do you want to remove this members?',
        cancel: 'Cancel',
        ok: 'Remove'
      },
      highlight: true
    }
  };
  viewModel: SeeAllMembersViewModel;

  constructor(props: PropsType) {
    super(props);
    this.viewModel = new SeeAllMembersViewModel();
  }

  @autobind
  wrapConfirmation(action: (groupUser: GroupUser) => void, confirmation: ConfirmationType, groupUser: GroupUser) {
    const {header, message, ok, cancel} = confirmation;
    const {user} = groupUser;
    const formattedMessage = formatStringTemplate(message, user);
    appModel.dialogViewModel.showConfirm(
      formattedMessage,
      header,
      ok,
      cancel,
      () => {
        if (action) {
          action(groupUser);
        }
      },
      () => {}
    );
  }

  @autobind
  makeOwner(groupUser: GroupUser) {
    const {groupId} = this.props;
    this.viewModel.makeTeamOwner(groupId, groupUser.user.id);
  }

  @autobind
  makeLead(groupUser: GroupUser) {
    const {groupId} = this.props;
    this.viewModel.makeTeamLead(groupId, groupUser.user.id);
  }

  @autobind
  removeLead(groupUser: GroupUser) {
    const {groupId} = this.props;
    this.viewModel.removeAsLead(groupId, groupUser.user.id);
  }

  @autobind
  removeFromTeam(groupUser: GroupUser) {
    const {groupId} = this.props;
    this.viewModel.removeFromTeam(groupId, groupUser.user.id);
  }

  @autobind
  handleClose() {
    const {canCloseDialog, onClose} = this.props;
    if (canCloseDialog === true && onClose) {
      onClose();
    }
  }

  @autobind
  getRoleName(groupUser: GroupUser): ?string {
    if (groupUser.isLeader()) {
      return 'Lead';
    } else if (groupUser.isOwner()) {
      return 'Owner';
    }
  }

  @autobind
  renderActionsMenu(groupUser: GroupUser): Node {
    const isOwner = groupUser.isOwner();
    return (
      !isOwner && (
        <Dropdown>
          <Dropdown.Toggle className="dropdown-toggle" as={MoreActionToggle}>
            <Icon iconName="more" color="#777b7d" size={24} />
          </Dropdown.Toggle>
          <Dropdown.Menu alignRight>{this.renderRestrictedActionsMenu(groupUser)}</Dropdown.Menu>
        </Dropdown>
      )
    );
  }

  @autobind
  renderRestrictedActionsMenu(groupUser: GroupUser): ?Node {
    const {isLead, isOwner} = this.props;
    if (isOwner) {
      return this.renderOwnerActionsMenu(groupUser);
    } else if (isLead) {
      return this.renderLeaderActionsMenu(groupUser);
    }
  }

  @autobind
  renderOwnerActionsMenu(groupUser: GroupUser): Node {
    const {makeOwner, makeLead, removeLead, removeFromTeam} = this.actionList;
    const leadActions = [makeOwner, removeLead, removeFromTeam];

    const memberActions = [makeOwner, makeLead, removeFromTeam];
    const actions = groupUser.isLeader() ? leadActions : memberActions;

    return this.renderActions(actions, groupUser);
  }

  @autobind
  renderActions(actions: Array<ActionType>, groupUser: GroupUser): Node {
    return (
      <Fragment>
        {actions.map(
          ({action, name, confirmation, highlight}: ActionType, index: number): Node => {
            return (
              <Dropdown.Item
                key={index}
                className={highlight ? 'highlight-item' : ''}
                onClick={() => {
                  if (confirmation) {
                    this.wrapConfirmation(action, confirmation, groupUser);
                  } else {
                    action(groupUser);
                  }
                }}
              >
                {name}
              </Dropdown.Item>
            );
          }
        )}
      </Fragment>
    );
  }

  @autobind
  renderLeaderActionsMenu(groupUser: GroupUser): Node {
    const {removeLead, leaveRole, makeLead, removeFromTeam} = this.actionList;
    const isMyself = groupUser.user.id == appModel.currentUser.id;
    const leadActions = [];
    if (isMyself) {
      leadActions.push(leaveRole);
    } else {
      leadActions.push(removeLead);
      leadActions.push(removeFromTeam);
    }

    const memberActions = [makeLead, removeFromTeam];

    const actions = groupUser.isLeader() ? leadActions : memberActions;

    return this.renderActions(actions, groupUser);
  }

  @autobind
  renderMemberList(): ?Node {
    const {isLead} = this.props;
    const {filteredMembers} = this.viewModel;
    return (
      filteredMembers && (
        <Fragment>
          {filteredMembers.map(
            (groupUser: GroupUser): Node => {
              const {user} = groupUser;
              const {avatar, defaultAvatar} = user;
              return (
                <div key={user.id} className="member-item">
                  <ProfileLink user={user}>{renderUserAvatar(avatar, defaultAvatar, 40)}</ProfileLink>
                  <div className="name">
                    <ProfileLink user={user} />
                  </div>
                  <div className="role">{this.getRoleName(groupUser)}</div>
                  {isLead && (
                    <div className="actions" role="button">
                      {this.renderActionsMenu(groupUser)}
                    </div>
                  )}
                </div>
              );
            }
          )}
        </Fragment>
      )
    );
  }

  @autobind
  onShow() {
    const {groupId} = this.props;
    // console.log(this.viewModel);
    this.viewModel.fetchGroupMembers(groupId);
  }

  render(): Node {
    const {show, isLead, showInviteTeammateDialog} = this.props;
    const {searchMemberText, onSearchMemberChange, filteredMembers, doingAction} = this.viewModel;
    const isFetchingMembers = filteredMembers === null;
    return (
      <Modal
        dialogClassName="see-all-team-members-modal"
        show={show}
        onShow={this.onShow}
        onHide={this.handleClose}
        centered
      >
        <Modal.Header>
          <Modal.Title className="title">
            <span>Members</span>
            {isLead && (
              <div className="invite-teammate" role="button" onClick={showInviteTeammateDialog}>
                <Icon iconName="invite" color="#2786e9" />
                <span className="invite-teammate-label">Invite teammates</span>
              </div>
            )}
          </Modal.Title>
        </Modal.Header>
        <Modal.Body className="body">
          <Form.Control
            placeholder="Search"
            name="search"
            className="search-input"
            value={searchMemberText}
            onChange={onSearchMemberChange}
          />
          <div className="search-icon">
            <Icon iconName="search" color="#777b7d" size={24} />
          </div>

          <div className="member-list">{this.renderMemberList()}</div>
        </Modal.Body>
        {(isFetchingMembers || doingAction) && (
          <div className="loading">
            <Spinner as="span" animation="border" className="status" aria-hidden="true" />
          </div>
        )}
      </Modal>
    );
  }
}

export default SeeAllMembers;
