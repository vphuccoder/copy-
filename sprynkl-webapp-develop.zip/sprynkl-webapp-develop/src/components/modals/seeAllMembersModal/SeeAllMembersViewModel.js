// @flow
import autobind from 'autobind-decorator';
import {action, computed, observable} from 'mobx';
import {Group, GroupUser} from 'models';
import {appModel} from 'models/app-model';
import {GroupRoles} from 'models/group-roles';
import {groupService, userService} from 'services';
import {sortUserByFullNameAsc, isContains} from '../../../utils';

class SeeAllMembersViewModel {
  @observable
  group: Group = null;

  @observable
  searchMemberText: string = '';

  @observable
  doingAction: boolean = false;

  @autobind
  @action
  onSearchMemberChange(event: SyntheticInputEvent<HTMLInputElement>) {
    const text = event.target.value;
    this.searchMemberText = text;
  }

  @autobind
  @action
  setCurrentGroup(group: Group) {
    this.group = group;
  }

  @computed
  get filteredMembers(): ?Array<GroupUser> {
    if (this.group) {
      return this.group.members
        .filter(
          (member: GroupUser): boolean => {
            const searchTerm: string = (this.searchMemberText || '').trim();
            const {fullName, email, userStatus} = member.user;
            const isEmpty = searchTerm === '';
            const isContainsSearchTerm = isContains(fullName, searchTerm) || isContains(email, searchTerm);
            const isActive = userStatus === 'active';
            return isEmpty || (isContainsSearchTerm && isActive);
          }
        )
        .slice()
        .sort(sortUserByFullNameAsc);
    }
    return null;
  }

  @autobind
  @action
  async fetchGroupMembers(id: string) {
    if (!id) {
      this.group = null;
    } else {
      try {
        const group = await groupService.getGroup(appModel.currentToken.accessToken, id);
        this.group = group;
      } catch {
        this.group = null;
      }
    }
  }

  @autobind
  @action
  async makeTeamOwner(groupId: string, userId: string) {
    this.doingAction = true;
    await groupService.assignOwner(appModel.currentToken.accessToken, groupId, userId);
    this.refreshMemberList(groupId);
  }

  @autobind
  @action
  async makeTeamLead(groupId: string, userId: string) {
    this.doingAction = true;
    await groupService.assignRole(appModel.currentToken.accessToken, groupId, userId, GroupRoles.ADMIN);
    this.refreshMemberList(groupId);
  }

  @autobind
  @action
  async removeAsLead(groupId: string, userId: string) {
    this.doingAction = true;
    await groupService.assignRole(appModel.currentToken.accessToken, groupId, userId, GroupRoles.MEMBER);
    this.refreshMemberList(groupId);
  }

  @autobind
  @action
  async removeFromTeam(groupId: string, userId: string) {
    this.doingAction = true;
    await groupService.removeUser(appModel.currentToken.accessToken, groupId, userId);
    this.refreshMemberList(groupId);
  }

  @autobind
  @action
  async refreshMemberList(groupId: string) {
    try {
      const group = await groupService.getGroup(appModel.currentToken.accessToken, groupId);
      const updatedUser = await userService.getUser(appModel.currentToken.accessToken);
      appModel.setCurrentGroup(group);
      appModel.setCurrentUser(updatedUser);
      this.group = group;
    } finally {
      this.doingAction = false;
    }
  }
}

export {SeeAllMembersViewModel};
