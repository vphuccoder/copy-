// @flow
import {CreatePostViewModel} from '../createPostModal';
import {computed, action, observable} from 'mobx';
import {appModel} from '../../../models/app-model';
import {fileService, postService} from '../../../services';
import {PostModel} from '../../../models';

const MIN_CONTENT = 3;

export default class CreateThanksViewModel extends CreatePostViewModel {
  constructor() {
    super({type: 'thanks'});
  }

  @observable
  isLoading: boolean = false;

  @observable
  karma: number = 1;

  @computed
  get showAlert(): boolean {
    const {recevierViewModel, content, photos} = this;

    return content.trim().length > 0 || recevierViewModel.selectedMembers.length > 0 || photos.length > 0;
  }

  @computed
  get isValid(): boolean {
    const {
      recevierViewModel: {selectedGroup, members}
    } = this;
    return (
      this.content.trim() !== '' &&
      this.content.trim().length >= MIN_CONTENT &&
      selectedGroup &&
      selectedGroup.id &&
      members.filter((member: MemberItemViewModel): boolean => member.selected).length > 0
    );
  }

  @action
  setKarma(value: number) {
    this.karma = value;
  }

  buildDataForSave(): {} {
    const {members, selectedGroup, activeMembers} = this.recevierViewModel;

    const selectedMember = members.filter((member: MemberItemViewModel): boolean => member.selected);
    const isPrivate = false;
    const karma = this.karma;
    return {
      type: this.type,
      sendTo: selectedMember.length !== activeMembers.length ? selectedMember : [],
      group: selectedGroup.id,
      anonymous: this.anonymous,
      content: this.content.trim(),
      textContent: this.content.trim(),
      hashTags: [],
      images: this.images,
      karma,
      isPrivate
    };
  }

  @action
  async save(): PostModel {
    const {accessToken} = appModel.currentToken;
    const data = this.buildDataForSave();
    this.isLoading = true;
    try {
      this.setLoading(true);

      const imageObject = this.photos && this.photos[0];

      if (imageObject) {
        const {name: fileName, type: fileType} = imageObject;
        const file = await fileService.uploadFile(accessToken, imageObject, fileName, fileType);
        if (file && file.id) {
          data.images = [file.id];
        }
      }

      const result = await postService.createPost(appModel.currentToken.accessToken, data);
      this.isLoading = false;
      return result;
    } catch (ex) {
      this.handleError(ex, true);
      this.isLoading = false;
    }
  }
}
