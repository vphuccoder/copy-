import CreateThanks from './CreateThanks';
export {CreateThanks};
