// @flow
import autobind from 'autobind-decorator';
import {icons} from 'components/themes/Icons';
import {observer} from 'mobx-react';
import React from 'react';
import {Button, Form, Spinner} from 'react-bootstrap';
import Icon from '../../baseComponents/Icon';
import InputRecevicer from '../../inputReceiver/InputReceiver';
import KarmaSelection from '../../karma/KarmaSelection';
import {CreatePostConfig} from '../createPostModal';
import './CreateThanks.scss';
import CreateThanksViewModel from './CreateThanksViewModel';
import {Prompt} from 'react-router-dom';

type PropsType = {
  showAlert: void,
  alertMessage: string
};
@observer
class CreateThanks extends React.Component {
  constructor(props: PropsType) {
    super(props);
    this.viewModel = new CreateThanksViewModel();
    this.state = {image: undefined};
  }

  @autobind
  setAnonymous() {
    const {viewModel} = this;
    viewModel.setAnonymous();
  }

  @autobind
  changeContent(e: SyntheticInputEvent<HTMLInputElement>) {
    const {viewModel} = this;
    viewModel.changeContent(e.target.value);
    this.props.showAlert(viewModel.showAlert);
  }

  @autobind
  selectImage(image: {}, imageUrl: string) {
    const {viewModel} = this;
    viewModel.addImage(image);
    this.props.showAlert(viewModel.showAlert);
    this.setState({image: imageUrl});
  }

  @autobind
  deleteImage() {
    const {viewModel} = this;
    viewModel.deleteImage();
    this.setState({image: undefined});
  }

  renderImage(): React.Node {
    if (this.state.image) {
      return (
        <div className="image-section">
          <div className="delete-image">
            <a className="delete-icon" onClick={this.deleteImage}>
              <Icon color={'#dbddde'} size={24} iconName={icons.close} />
            </a>
          </div>
          <img className="post-image" src={this.state.image} />
        </div>
      );
    }
  }

  @autobind
  selectKarma(value: SyntheticInputEvent<HTMLDivElement>) {
    const {viewModel} = this;
    viewModel.setKarma(value);
  }

  renderPostContent(): React.Node {
    const {
      viewModel: {recevierViewModel, content, anonymous, karma}
    } = this;

    if (recevierViewModel.enableSearch) {
      return null;
    }
    return (
      <div className="post-content">
        <div className="body">
          <Form.Group>
            <Form.Control
              className="text-body padding-0 paddingTopBottom-8"
              as="textarea"
              rows={5}
              name="description"
              placeholder="Make their day..."
              value={content}
              onChange={this.changeContent}
            />
          </Form.Group>
        </div>
        {this.renderImage()}
        <div className="karma-container">
          <span className="karma-text">Karma</span>
          <div className="karma-selection-item">
            <KarmaSelection value={karma} onChange={this.selectKarma} maxValue={5} />
          </div>
        </div>
        <CreatePostConfig anonymous={anonymous} selectImage={this.selectImage} setAnonymous={this.setAnonymous} />
      </div>
    );
  }

  @autobind
  closeSearch() {
    const {viewModel} = this;
    this.props.showAlert(viewModel.showAlert);
    viewModel.recevierViewModel.turnOffSearch();
  }

  renderSearch(): React.Node {
    const {recevierViewModel} = this.viewModel;

    return (
      <div className="search">
        <InputRecevicer viewModel={recevierViewModel} />
      </div>
    );
  }

  @autobind
  async savePost() {
    const {viewModel} = this;
    const {hideModal, addPostToFeeds, showAlert} = this.props;
    const result = await viewModel.save();
    showAlert(false);

    if (result && addPostToFeeds) {
      addPostToFeeds(result);
    }
    hideModal();
  }

  renderFooter(): React.Node {
    const {viewModel} = this;
    const {isLoading} = viewModel;
    if (viewModel.recevierViewModel.enableSearch) {
      return (
        <div className="create-post-footer float-right paddingTop-4">
          <Button className="send-button" onClick={this.closeSearch}>
            Done
          </Button>
        </div>
      );
    }
    return (
      <div className="create-post-footer float-right paddingTop-4">
        <Button className="send-button" disabled={!viewModel.isValid || isLoading} onClick={this.savePost}>
          {isLoading && (
            <Spinner
              className="marginLeftRight-4"
              as="span"
              animation="border"
              size="sm"
              role="status"
              aria-hidden="true"
            />
          )}
          Send
        </Button>
      </div>
    );
  }

  render(): React.Node {
    return (
      <div className="create-thanks">
        <Prompt message={this.props.alertMessage} when={this.viewModel.showAlert} />
        {this.renderSearch()}
        {this.renderPostContent()}
        {this.renderFooter()}
      </div>
    );
  }
}

export default CreateThanks;
