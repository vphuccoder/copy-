// @flow

import React, {Component} from 'react';
import type {Node} from 'react';
import {observer} from 'mobx-react';
import {Modal, Form, Spinner, Button} from 'react-bootstrap';
import autobind from 'autobind-decorator';
import Icon from '../../baseComponents/Icon';
import {appModel} from '../../../models/app-model';
import {InviteTeammatesViewModel} from './InviteTeammatesViewModel';
import './InviteTeammates.scss';

type PropsType = {
  show: boolean,
  groupId: string,
  canCloseDialog: boolean,
  onClose: () => mixed
};

@observer
class InviteTeammates extends Component<PropsType> {
  viewModel: InviteTeammatesViewModel;

  constructor(props: PropsType) {
    super(props);
    this.viewModel = new InviteTeammatesViewModel();
  }

  @autobind
  onHide() {
    const {onClose, canCloseDialog} = this.props;

    if (canCloseDialog && onClose) {
      onClose();
    }
  }

  @autobind
  renderEmailAddresses(): Node {
    const {emails, onDelete, onEmailChange, focusIndex, onEmailFocus, onEmailBlur, getEmailError} = this.viewModel;
    const isOneLeft = emails.length === 1;
    return emails.map(
      (email: string, index: number): Node => {
        const isFocused = focusIndex === index;
        const {isValid: isValidEmail, message} = getEmailError(email);
        const showError = !isFocused && !isValidEmail;
        return (
          <Form.Group key={index} className="email-item">
            <div className="email-input">
              <div className="input">
                <Form.Control
                  placeholder="Email address"
                  value={email}
                  onChange={(event: SyntheticInputEvent<HTMLInputElement>): void => onEmailChange(index, event)}
                  isInvalid={showError}
                  onFocus={(): void => onEmailFocus(index)}
                  onBlur={onEmailBlur}
                  autoComplete="nope"
                />
                <Form.Control.Feedback type="invalid">{message}</Form.Control.Feedback>
              </div>
              {!isOneLeft && (
                <div className="close-icon" onClick={(): void => onDelete(email)}>
                  <Icon iconName="close" color="#282c2e" size={24} />
                </div>
              )}
            </div>
          </Form.Group>
        );
      }
    );
  }

  @autobind
  onShow() {
    this.viewModel.onShow(this.props.groupId);
  }

  @autobind
  async onInviteTeammates() {
    const result = await this.viewModel.inviteTeammates();
    if (result) {
      appModel.alertMessageViewModel.showAlert('Invitation sent successfully!');
      this.onHide();
    }
  }

  render(): Node {
    const {show} = this.props;
    const {isInvitingTeammates, isValidEmailList} = this.viewModel;
    const disabledSendButton = isInvitingTeammates || !isValidEmailList;
    return (
      <Modal show={show} onHide={this.onHide} onShow={this.onShow} centered className="invite-team-mate">
        <Modal.Header className="header">
          <Modal.Title className="title">Invite teammates</Modal.Title>
        </Modal.Header>
        <Modal.Body className="body">
          <Form>{this.renderEmailAddresses()}</Form>
        </Modal.Body>
        <Modal.Footer className="footer">
          <Button variant="danger" disabled={disabledSendButton} onClick={this.onInviteTeammates}>
            {isInvitingTeammates && <Spinner as="span" animation="border" size="sm" role="status" aria-hidden="true" />}
            <span> Send</span>
          </Button>
        </Modal.Footer>
      </Modal>
    );
  }
}

export default InviteTeammates;
