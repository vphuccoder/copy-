// @flow
import {observable, action, computed} from 'mobx';
import autobind from 'autobind-decorator';
import {appModel} from '../../../models/app-model';
import {groupService} from '../../../services';
import {isEmail} from '../../../utils/regex';
import {STRING_CONSTANT} from '../../../models/constants';
import {formatStringTemplate} from '../../../utils/string';

class InviteTeammatesViewModel {
  @observable
  groupId: ?string = null;

  @observable
  emails: Array<string> = [];

  @observable
  isInvitingTeammates: boolean = false;

  @observable
  focusIndex: number = -1;

  domainList: Array<string> = [];

  @observable
  isFetchingData: boolean = false;

  @computed
  get isValidEmailList(): boolean {
    const emails = this.emails.filter((email: string): boolean => !!email);
    return (
      emails.length > 0 &&
      emails.every(
        (email: string): boolean => {
          return isEmail(email) && this.isValidDomainName(email);
        }
      )
    );
  }

  @autobind
  isValidDomainName(email: string): boolean {
    const emailDomain = this.getEmailDomain(email).toLowerCase();

    const noRestrictedDomain = !this.domainList || this.domainList.length <= 0;

    const isValidDomain = this.domainList.indexOf(emailDomain) >= 0;

    return noRestrictedDomain || isValidDomain;
  }

  @autobind
  getEmailDomain(email: string): string {
    return email.substring(email.lastIndexOf('@') + 1);
  }

  @autobind
  @action
  async onShow(groupId: string) {
    try {
      this.isFetchingData = true;
      this.groupId = groupId;
      this.emails.clear();
      this.emails.push(...['', '', '']);
      await this.fetchDomainList(groupId);
    } finally {
      this.isFetchingData = false;
    }
  }

  @autobind
  async fetchDomainList(groupId: string) {
    const emailDomains = await groupService.getEmailDomain(appModel.currentToken.accessToken, groupId);
    this.domainList = emailDomains.list;
  }

  @autobind
  @action
  onDelete(email: string) {
    this.emails.remove(email);
    this.autoAppendNewLineForEmail();
  }

  @autobind
  @action
  autoAppendNewLineForEmail() {
    const isValidEmails = this.validateAllEmails();
    if (isValidEmails) {
      this.emails.push('');
    }
  }

  @autobind
  async inviteTeammates(): Promise<boolean> {
    if (this.groupId) {
      this.isInvitingTeammates = true;
      try {
        const emails = this.emails.filter((email: string): boolean => !!email);
        const distinctEmails = [...new Set(emails)];
        if (distinctEmails.length > 0) {
          await groupService.invite(appModel.currentToken.accessToken, this.groupId, distinctEmails);
          return true;
        }
      } finally {
        this.isInvitingTeammates = false;
      }
    }
    return false;
  }

  @autobind
  @action
  onEmailChange(index: number, event: SyntheticInputEvent<HTMLInputElement>) {
    const email = event.target.value;
    this.emails[index] = email;
    this.autoAppendNewLineForEmail();
  }

  @autobind
  isInvalidEmail(email: string): boolean {
    return !isEmail(email);
  }

  @autobind
  validateAllEmails(): boolean {
    return !this.emails.some(this.isInvalidEmail);
  }

  @autobind
  @action
  onEmailFocus(index: number) {
    this.focusIndex = index;
  }

  @autobind
  @action
  onEmailBlur() {
    this.focusIndex = -1;
  }

  @autobind
  getEmailError(
    email: string
  ): {
    isValid: boolean,
    message?: string
  } {
    const {INVALID_EMAIL_FORMAT, INVALID_EMAIL_DOMAIN_NAME} = STRING_CONSTANT;
    let message = '';
    let isValid = true;
    if (email) {
      if (!isEmail(email)) {
        message = INVALID_EMAIL_FORMAT;
        isValid = false;
      } else if (!this.isValidDomainName(email)) {
        const domain = this.getEmailDomain(email);
        message = formatStringTemplate(INVALID_EMAIL_DOMAIN_NAME, {domain});
        isValid = false;
      }
    }
    return {
      isValid,
      message
    };
  }
}

export {InviteTeammatesViewModel};
