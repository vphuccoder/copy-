import * as React from 'react';
import AnswerItem from './AnswerItem';
import {Collapse} from 'react-bootstrap';
import autobind from 'autobind-decorator';
class AnswerGroup extends React.Component {
  constructor() {
    super();
    this.state = {open: true};
  }
  renderAnserItem() {
    const {answerGroup, anonymousAnswer} = this.props;
    return answerGroup.map((answer) => {
      return <AnswerItem answer={answer} key={answer.id} anonymousAnswer={anonymousAnswer} />;
    });
  }

  @autobind
  colapse() {
    const {open} = this.state;
    this.setState({open: !open});
  }

  render() {
    const {value, totalAnwser} = this.props;
    const {open} = this.state;
    const totalVoteText = totalAnwser > 1 ? `${totalAnwser} votes` : `${totalAnwser} vote`;
    return (
      <div className="answer-group">
        <a className="collapse-answer-group" onClick={this.colapse}>
          <span className="answer-value">
            {value} • {totalVoteText}
          </span>
        </a>
        <Collapse in={open}>
          <div>{this.renderAnserItem()}</div>
        </Collapse>
      </div>
    );
  }
}

export default AnswerGroup;
