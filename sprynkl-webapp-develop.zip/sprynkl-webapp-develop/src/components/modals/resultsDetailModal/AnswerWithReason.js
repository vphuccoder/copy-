import React from 'react';

import {renderUserAvatar} from '../../baseComponents/svg/Avatar';
import TextOverFlow from '../../baseComponents/textOverFlow/TextOverFlow';
export default class AnswerWithReason extends React.PureComponent {
  render() {
    const {
      user: {avatar, defaultAvatar = 1, fullName},
      reason,
      anonymousAnswer
    } = this.props;

    if (anonymousAnswer) {
      return (
        <div className="answer-reason">
          <div className="reason">{reason}</div>
        </div>
      );
    }

    return (
      <div className="answer-reason">
        <div className="member-item">
          <div className="member-avatar">{renderUserAvatar(avatar, defaultAvatar, 40)}</div>
          <TextOverFlow className="member-name" tooltip={fullName}>
            <span className="member-name" title={fullName}>
              {fullName}
            </span>
          </TextOverFlow>
        </div>
        <div className="reason">{reason}</div>
      </div>
    );
  }
}
