// @flow
import * as React from 'react';
import {groupBy} from '../../../utils/utils';
import './ResultsDetailModal.scss';
import OpenAnswerItem from './OpenAnswerItem';
import AnswerGroup from './AnswerGroup';
import {AskType} from '../../../models';
type PropsType = {
  answers: Array<{}>
};
class ResultsDetailModal extends React.Component<PropsType> {
  constructor(props: PropsType) {
    super(props);
    const {answers} = this.props;
    this.initData(answers);
  }

  initData(answers: Array<>): Array {
    this.groupOptions = groupBy(answers, 'value');
  }

  renderOpenResult(): React.ReactNode {
    const {answers, anonymousAnswer} = this.props;
    return answers.map(
      (answer: {}): React.ReactNode => {
        return <OpenAnswerItem answer={answer} key={answer.id} anonymousAnswer={anonymousAnswer} />;
      }
    );
  }

  getValue(key: string): string {
    const {type, options = []} = this.props;
    if (type === AskType.POLL) {
      const option = options.find((option: {}): {} => option.value === key);
      return option.label;
    }
    return key;
  }

  renderAnwserGroups(): React.ReactNode {
    const {type, anonymousAnswer} = this.props;
    if (type === AskType.OPEN) {
      return this.renderOpenResult();
    }
    const {groupOptions = {}} = this;
    const options = [];
    for (var key in groupOptions) {
      if (groupOptions.hasOwnProperty(key)) {
        const totalAnwser = groupOptions[key].length;
        const value = this.getValue(key);
        options.push(
          <div key={key} className="answer-group-value">
            <AnswerGroup
              answerGroup={groupOptions[key]}
              totalAnwser={totalAnwser}
              value={value}
              anonymousAnswer={anonymousAnswer}
            />
          </div>
        );
      }
    }
    return options;
  }
  render(): React.ReactNode {
    return <div className="result-detail">{this.renderAnwserGroups()}</div>;
  }
}

export default ResultsDetailModal;
