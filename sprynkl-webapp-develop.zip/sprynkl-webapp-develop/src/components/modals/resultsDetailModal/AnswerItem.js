import * as React from 'react';
import {AnswerWithReason, AnswerWithoutReason} from './';

class AnswerItem extends React.Component {
  renderMember() {
    const {
      answer: {user = {}},
      anonymousAnswer
    } = this.props;

    return <AnswerWithoutReason user={user} anonymousAnswer={anonymousAnswer} />;
  }

  renderAnswerWithReason() {
    const {
      answer: {reason, user = {}},
      anonymousAnswer
    } = this.props;

    return <AnswerWithReason user={user} reason={reason} anonymousAnswer={anonymousAnswer} />;
  }

  renderAnserItem() {
    const {
      answer: {reason}
    } = this.props;
    if (reason) {
      return this.renderAnswerWithReason();
    }

    return this.renderMember();
  }
  render() {
    return <div className="answer-group-item">{this.renderAnserItem()}</div>;
  }
}

export default AnswerItem;
