import * as React from 'react';
import {AnswerWithoutReason, AnswerWithReason} from './';
class OpenAnswerItem extends React.Component {
  renderMember() {
    const {
      answer: {user = {}},
      anonymousAnswer
    } = this.props;

    return <AnswerWithoutReason user={user} anonymousAnswer={anonymousAnswer} />;
  }

  renderAnswerWithReason() {
    const {
      answer: {value, user = {}},
      anonymousAnswer
    } = this.props;

    return <AnswerWithReason user={user} reason={value} anonymousAnswer={anonymousAnswer} />;
  }

  renderAnserItem() {
    const {
      answer: {value}
    } = this.props;
    if (value) {
      return this.renderAnswerWithReason();
    }

    return this.renderMember();
  }
  render() {
    return <div className="answer-group-item">{this.renderAnserItem()}</div>;
  }
}

export default OpenAnswerItem;
