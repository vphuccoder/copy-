import React from 'react';
import {renderUserAvatar} from '../../baseComponents/svg/Avatar';
import TextOverFlow from '../../baseComponents/textOverFlow/TextOverFlow';
export default class AnswerWithoutReason extends React.PureComponent {
  render() {
    const {
      user: {avatar, defaultAvatar = 1, fullName},
      anonymousAnswer
    } = this.props;
    if (anonymousAnswer) {
      return null;
    }
    return (
      <div className="member-item paddingLeftRight-16">
        <div className="member-avatar">{renderUserAvatar(avatar, defaultAvatar, 40)}</div>
        <TextOverFlow className="member-name" tooltip={fullName} placement="bottom">
          <span className="member-name" title={fullName}>
            {fullName}
          </span>
        </TextOverFlow>
      </div>
    );
  }
}
