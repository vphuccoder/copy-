// @flow
import * as React from 'react';
import {ModalConsumer} from '../../context/ModalContext';
import {PostDetailContent} from './';
import './PostDetailModal.scss';

type PropsType = {postId: string, children: React.Node};

type StateType = {};

class PostDetailModal extends React.Component<PropsType, StateType> {
  render() {
    const {postId} = this.props;

    return (
      <ModalConsumer>
        {({showModal, hideModal}: {showModal: () => void, hideModal: () => mixed}) => (
          <span
            onClick={(): {} =>
              showModal(PostDetailContent, {
                hideModal,
                header: 'Post Detail',
                dialogClassName: 'post-detail-dialog',
                postId: postId
              })
            }
          >
            {this.props.children}
          </span>
        )}
      </ModalConsumer>
    );
  }
}

export default PostDetailModal;
