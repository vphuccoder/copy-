// @flow
import React from 'react';
import {observer} from 'mobx-react';
import autobind from 'autobind-decorator';
import {withRouter} from 'react-router';
import {Header, Body, Footer, CommentList, PostViewModel} from '../../feeds';
import {PostDetailContentViewModel} from './';
import {Comment} from '../../../models';
import './PostDetailContent.scss';

type PropsType = {
  postId: string,
  deletePost: (post: PostViewModel) => void
};

type StateType = {};

@withRouter
@observer
class PostDetailContent extends React.Component<PropsType, StateType> {
  viewModel: PostDetailContentViewModel;
  constructor(props: PropsType) {
    super(props);
    this.viewModel = new PostDetailContentViewModel(props.postId);
  }

  componentDidMount() {
    this.viewModel.getPostData(this.props.history);
  }

  @autobind
  deletePost() {
    const {postViewModel = {}} = this.viewModel;
    this.props.deletePost(postViewModel);
  }

  @autobind
  deleteComment(comment: Comment) {
    const {postViewModel = {}} = this.viewModel;
    const post = postViewModel.post || {};
    const commentIndex = post.comments.indexOf(comment);
    if (commentIndex >= 0) {
      post.comments.splice(commentIndex, 1);
    }
  }

  @autobind
  renderCommentList(): React.Node {
    const {postViewModel = {}, activeUserList} = this.viewModel;
    const post = postViewModel.post || {};
    return (
      <CommentList
        comments={post.comments}
        activeUserList={activeUserList}
        postGroup={post.group}
        onDeleteComment={this.deleteComment}
      />
    );
  }

  render(): React.Node {
    const {postViewModel = {}, isLoading} = this.viewModel;
    const post = postViewModel.post || {};

    if (isLoading) {
      return null;
    }
    return (
      <div className="post-detail">
        <Header post={post} deletePost={this.deletePost} />
        <Body post={post} postVM={postViewModel} showFullContent />
        <Footer disabled postVM={postViewModel} showLastComment={false} renderComments={this.renderCommentList} />
      </div>
    );
  }
}

export default PostDetailContent;
