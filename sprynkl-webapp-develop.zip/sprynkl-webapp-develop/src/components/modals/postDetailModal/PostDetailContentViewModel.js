// @flow
import {observable, computed} from 'mobx';
import {action} from 'popmotion';
import {appModel} from '../../../models/app-model';
import {BasePageViewModel} from '../../../pages/BasePageViewModel';
import {postService} from '../../../services';
import {PostViewModel} from '../../feeds';
import {HTTP_STATUS} from '../../../models/constants';
import {User, UserGroup, THANKS, UserStatus} from '../../../models';
import {GroupRoles} from '../../../models/group-roles';
import {USER_STATUS} from '../../../models/user-status';

class PostDetailContentViewModel extends BasePageViewModel {
  id: string = '';

  @observable
  isLoading: boolean = true;

  postViewModel: PostViewModel;

  get activeUserList(): Array<User> {
    const {
      post,
      post: {author, anonymous}
    } = this.postViewModel;

    if (!anonymous) {
      const activeUserList = [];
      const userInGroups = appModel.currentGroup.members || [];

      userInGroups.forEach((userGroup: UserGroup) => {
        if (userGroup.role === GroupRoles.INVITED || userGroup.user.userStatus !== UserStatus.ACTIVE) {
          return;
        }
        activeUserList.push(userGroup.user);
      });
      return activeUserList;
    } else {
      if (!anonymous && author && author.userStatus === UserStatus.ACTIVE) {
        return [...post.sendTo, author];
      }
      return post.sendTo;
    }
  }

  constructor(postId: string) {
    super();
    this.id = postId;
  }

  setPostId(postId: string) {
    this.id = postId;
  }

  async getPostData(history: History) {
    this.isLoading = true;
    try {
      const post = await postService.getPost(appModel.currentToken.accessToken, this.id);
      this.populateData(post);
      this.isLoading = false;
      return post;
    } catch (ex) {
      this.isLoading = false;
      if (ex.code === HTTP_STATUS.notFound.code) {
        history.push('/not-found');
      }
    }
  }

  @action
  populateData(post: {}) {
    this.postViewModel = PostViewModel.toViewModel(post);
  }
}
export default PostDetailContentViewModel;
