/**
 * @flow
 */

import React from 'react';
import autobind from 'autobind-decorator';
import MemberReceiverListViewModel from './MemberReceiverListViewModel';
import {User} from '../../../../models';
import MemberReceiverListItem from '../MemberReceiverListItem';
import './MemberReceiverList.scss';

type PropsType = {};

type StateType = {};

class MemberReceiverList extends React.Component<PropsType, StateType> {
  constructor(props: PropsType) {
    super(props);
    this.viewModel = new MemberReceiverListViewModel();
    this.viewModel.setReceiverList(this.props.receiverList);
  }

  @autobind
  onViewProfile(user: User) {}

  @autobind
  renderList(): React.Node {
    const receiverList = this.viewModel.users || [];

    return receiverList.map(
      (user: User, index: number): React.Node => {
        const isLastIndex = index === receiverList.length - 1;
        return (
          <MemberReceiverListItem
            user={user}
            isLastIndex={isLastIndex}
            key={user.id}
            onViewProfile={this.onViewProfile}
            hideModal={this.props.hideModal}
          />
        );
      }
    );
  }

  render(): React.Node {
    return <div className="member-receiver-list">{this.renderList()}</div>;
  }
}

export default MemberReceiverList;
