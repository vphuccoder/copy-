// @flow

import {BasePageViewModel} from '../../../../pages/BasePageViewModel';
import {Group} from '../../../../models';
import {action} from 'mobx';

class MemberReceiverListViewModel extends BasePageViewModel {
  users: Array = [];

  group: Group;

  @action
  setReceiverList(receiverList: Array = []) {
    this.users = receiverList;
  }
}

export default MemberReceiverListViewModel;
