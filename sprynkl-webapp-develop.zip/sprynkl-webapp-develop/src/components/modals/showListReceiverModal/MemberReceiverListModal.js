// @flow
import React from 'react';
import {ModalConsumer} from '../../context/ModalContext';
import MemberReceiverList from './memberReceiverList/MemberReceiverList';
import './MemberReceiverListModal.scss';

type PropsType = {};

type StateType = {};

class MemberReceiverListModal extends React.Component<PropsType, StateType> {
  render(): React.Node {
    const {receiverList} = this.props;

    return (
      receiverList &&
      receiverList.length > 0 && (
        <ModalConsumer>
          {({showModal, hideModal}: {}): React.Node => (
            <span
              className="show-receiver-list"
              onClick={(): {} =>
                showModal(MemberReceiverList, {
                  hideModal,
                  header: 'Others',
                  dialogClassName: 'show-receiver-list-dialog',
                  receiverList: receiverList
                })
              }
            >
              {this.props.children}
            </span>
          )}
        </ModalConsumer>
      )
    );
  }
}

export default MemberReceiverListModal;
