// @flow
import React from 'react';
import {renderUserAvatar} from '../../baseComponents/svg/Avatar';
import {User} from '../../../models';
import autobind from 'autobind-decorator';
import ProfileLink from '../../baseComponents/profileLink';
import TextOverFlow from '../../baseComponents/textOverFlow/TextOverFlow';

type PropsType = {
  user: User,
  isLastIndex: boolean
};

type StateType = {};

class MemberReceiverListItem extends React.Component<PropsType, StateType> {
  @autobind
  beforeSelectUser() {
    const {hideModal} = this.props;
    hideModal();
  }

  render(): React.Node {
    const {user, isLastIndex} = this.props;
    const {avatar, defaultAvatar, fullName} = user;
    return (
      <div className="member-receiver-list-item">
        <div className="member-receiver-list-item-container">
          <div className="member-receiver-list-item-avatar">
            <ProfileLink user={user} beforeSelectUser={this.beforeSelectUser}>
              {renderUserAvatar(avatar, defaultAvatar, 40)}
            </ProfileLink>
          </div>
          <div className="member-receiver-list-item-name">
            <ProfileLink user={user} beforeSelectUser={this.beforeSelectUser}>
              <TextOverFlow className="member-receiver-list-item-name-text" textOverflow={fullName} />
            </ProfileLink>
          </div>
        </div>
        {!isLastIndex && <div className="member-receiver-list-item-indicator" />}
      </div>
    );
  }
}

export default MemberReceiverListItem;
