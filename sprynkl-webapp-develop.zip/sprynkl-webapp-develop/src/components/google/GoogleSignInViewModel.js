import autobind from 'autobind-decorator';
import {getRandomAvatarIndex} from '../baseComponents/svg/Avatar';
import {appModel} from '../../models/app-model';
import * as LoginType from '../../models/login-type';
import * as UserStatus from '../../models/user-status';
import {googleService, userService} from '../../services/index';

export default class GoogleSignInViewModel {
  @autobind
  async loginSuccess(response) {
    const googleUser = await googleService.onSuccess(response);
    // check google emails
    const emailInfo = await userService.checkEmail(googleUser.email, false);

    if (emailInfo) {
      switch (emailInfo.userStatus) {
        case UserStatus.NEW:
          return await this.createNewGoogleAccount(googleUser);

        case UserStatus.ACTIVE:
          return await this.loginWithGoogle(googleUser);
      }
    } else {
      // handle error
    }
  }

  async loginWithGoogle(userInfo) {
    const {tokenId, email} = userInfo;
    const {deviceId, fcmToken} = appModel;
    const token = await userService.googelOauth(email, tokenId, deviceId, fcmToken);
    const user = await userService.getUser(token.accessToken);

    if (token && user) {
      appModel.setCurrentUser(user);
      appModel.setCurrentToken(token);
      appModel.loginType = LoginType.GOOGLE;
      return true;
    }

    return false;
  }

  @autobind
  async createNewGoogleAccount(userInfo) {
    const {tokenId, email} = userInfo;
    const {deviceId, fcmToken} = appModel;

    try {
      const meta = {
        // device: deviceService.getDeviceMeta(),
        // app: deviceService.getAppMeta()
      };

      const user = await userService.createGoogleUser(email, tokenId, getRandomAvatarIndex(), meta);
      const token = await userService.googelOauth(email, tokenId, deviceId, fcmToken);
      appModel.setCurrentToken(token);
      appModel.setCurrentUser(user);
      appModel.loginType = LoginType.GOOGLE;
      return true;
    } catch (ex) {
      // handle error
    }
  }
}
