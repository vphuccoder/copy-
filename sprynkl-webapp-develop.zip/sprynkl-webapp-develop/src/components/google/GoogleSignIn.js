import React from 'react';
import GoogleLogin from 'react-google-login';
import {withRouter} from 'react-router';
import {googleService} from '../../services';
import GoogleSignInViewModel from './GoogleSignInViewModel';
import {Button} from 'react-bootstrap';
import {Google} from '../baseComponents/svg/Svg';
import autobind from 'autobind-decorator';
import './GoogleSignIn.scss';
import {WEB_CLIENT_ID} from '../../configs';

@withRouter
class GoogleSignIn extends React.Component {
  constructor(props) {
    super(props);
    this.viewModel = new GoogleSignInViewModel();
  }

  renderButton(props) {
    return (
      <div className="google-sign-in">
        <Button className="button-sign-in" variant="outline-secondary" onClick={props.onClick}>
          <Google className="google-icon" width={20} height={20} />
          <span className="google-text">Continue with Google</span>
        </Button>
      </div>
    );
  }

  @autobind
  async onSuccess(reponse) {
    const {viewModel} = this;
    const result = await viewModel.loginSuccess(reponse);
    if (result) {
      const {history} = this.props;
      history.push('/');
    }
  }

  render() {
    return (
      <GoogleLogin
        clientId={WEB_CLIENT_ID}
        buttonText="Continue with Google"
        onSuccess={this.onSuccess}
        onFailure={googleService.onFailure}
        render={this.renderButton}
        cookiePolicy={'single_host_origin'}
      />
    );
  }
}

export default GoogleSignIn;
