// @flow
import React, {Component} from 'react';
import {Form, Navbar} from 'react-bootstrap';
import {withRouter} from 'react-router';
import autobind from 'autobind-decorator';
import {Group} from '../../models';
import {SprynklIcon} from '../baseComponents/svg/Svg';
import {CreatePost} from '../baseComponents/svg/Icons';
import {ModalConsumer} from '../context/ModalContext';
import CreatePostModal from '../modals/createPostModal/CreatePostModal';
import {NotificationPopover} from '../notification';
import {LeaderBoardModal} from '../leaderBoard';
import AccountPopover from './account/AccountPopover';
import TeamSelection from './teamSelection/TeamSelection';
import {observer} from 'mobx-react';
import {SearchBar} from './searchBar';
import './Header.scss';

type PropsType = {
  clickCreateTeam: void,
  showJoinTeamDialog: () => void,
  showInviteTeammateDialog: (canClose: boolean) => void,
  title?: Node,
  addPostToFeeds?: () => void,
  selectTeam?: (id: string) => void,
  groups: Array<Group>,
  selectedGroup: Group,
  disabledTeamSelection: boolean,
  isLead: boolean,
  editTeamProfile?: () => void
};

type StateType = {
  showAlert: boolean
};

@withRouter
@observer
class Header extends Component<PropsType, StateType> {
  constructor(props: PropsType) {
    super(props);
    this.state = {
      showAlert: false
    };
  }

  @autobind
  showAlert(value: boolean) {
    if (this.state.showAlert !== value) {
      this.setState({showAlert: value});
    }
  }

  @autobind
  onHide(hideModal: function, alertMessage: string ) {
    if (this.state.showAlert) {
      if (!confirm(alertMessage)) {
        return;
      }
    }
    hideModal();
    this.setState({showAlert: false});
  }

  @autobind
  clickCreateTeam() {
    const {clickCreateTeam} = this.props;
    if (clickCreateTeam) {
      clickCreateTeam();
    }
  }

  @autobind
  showJoinTeamDialog() {
    const {showJoinTeamDialog} = this.props;
    if (showJoinTeamDialog) {
      showJoinTeamDialog();
    }
  }

  @autobind
  showInviteTeammateDialog() {
    const {showInviteTeammateDialog} = this.props;
    if (showInviteTeammateDialog) {
      showInviteTeammateDialog(true);
    }
  }

  @autobind
  selectTeam(id: string) {
    const {selectTeam} = this.props;
    if (selectTeam) {
      selectTeam(id);
    }
  }

  @autobind
  renderTitleOrTeams(): React.Node {
    const {groups, selectedGroup, isLead, editTeamProfile, title, disabledTeamSelection} = this.props;
    return title ? (
      <div className="header-title">{title}</div>
    ) : (
      <TeamSelection
        disabled={disabledTeamSelection}
        clickCreateTeam={this.clickCreateTeam}
        showJoinTeamDialog={this.showJoinTeamDialog}
        showInviteTeammateDialog={this.showInviteTeammateDialog}
        selectTeam={this.selectTeam}
        selectedGroup={selectedGroup}
        groups={groups}
        isLead={isLead}
        editTeamProfile={editTeamProfile}
      />
    );
  }


  render(): React.Node {
    const {addPostToFeeds, searchValue} = this.props;
    const {showAlert} = this;

    return (
      <Navbar className="light-bottom-line" fixed="top">
        <div className="header">
          <div className="left-container">
            <div>
              <a href="/">
                <SprynklIcon width="36" height="32" />
              </a>
            </div>
            <div className="vertical-separator margin-left-right-16" />
            <div className="left-item">{this.renderTitleOrTeams()}</div>
          </div>
          <div className="right-container">
            <div className="search">
              <Form.Group>
                <SearchBar searchValue={searchValue} />
              </Form.Group>
            </div>
            <div className="right-action">
              <LeaderBoardModal />
            </div>
            <div className="right-action">
              <NotificationPopover onPressInviteNotification={this.showJoinTeamDialog}/>
            </div>
            <div className="right-action">
              <AccountPopover />
            </div>
            <ModalConsumer>
              {({showModal, hideModal}: {}): React.Node => (
                <a
                  className="right-action create-post"
                  onClick={(): {} =>
                    showModal(CreatePostModal, {
                      hideModal: (alertMessage: string) => {
                        this.onHide(hideModal, alertMessage);
                      },
                      showAlert,
                      dialogClassName: 'create-post-dialog',
                      addPostToFeeds: addPostToFeeds
                    })
                  }
                >
                  <CreatePost />
                </a>
              )}
            </ModalConsumer>
          </div>
        </div>
      </Navbar>
    );
  }
}

export default Header;
