// @flow
import autobind from 'autobind-decorator';
import {observer} from 'mobx-react';
import React, {Component} from 'react';
import type {Element} from 'react';
import {withRouter} from 'react-router';
import type {History} from 'react-router';
import {uriDecoder} from '../../../utils/utils';
import {SelectBox} from '../../baseComponents';
import {DropdownIndicator, Menu, NoOptionsMessage, Option, SearchBarViewModel} from './';
import './SearchBar.scss';
const BLUR_INPUT_ACTION = 'input-blur';
const CLOSE_MENU_ACTION = 'menu-close';

type PropsType = {
  history: History,
  searchValue: ?string
};
@withRouter
@observer
class SearchBar extends Component<PropsType> {
  viewModel: SearchBarViewModel;

  constructor(props: PropsType) {
    super(props);
    this.viewModel = new SearchBarViewModel(props.searchValue);
  }

  componentDidMount() {
    this.viewModel.getRecentSearchs();
  }

  goToSearchPage(value: string) {
    if (value) {
      this.props.history.push({
        pathname: uriDecoder(value)
      });
    }
  }

  @autobind
  onChange(searchValue: string) {
    this.goToSearchPage(searchValue);
  }

  @autobind
  changeSearchTerm(searchValue: string = '', changeAction: {action: string} = {}) {
    if (changeAction.action !== BLUR_INPUT_ACTION && changeAction.action !== CLOSE_MENU_ACTION) {
      this.viewModel.changeSearchTerm(searchValue);
    }
  }

  @autobind
  onSearch() {
    const {searchValue} = this.viewModel;
    if (searchValue) {
      this.goToSearchPage(searchValue);
    }
  }

  handleSpace() {
    this.viewModel.changeSearchTerm(`${this.viewModel.searchValue} `);
  }

  @autobind
  onKeyDown(event: SyntheticKeyboardEvent<HTMLInputElement>) {
    const {searchValue} = this.viewModel;
    if (event && event.key === 'Enter') {
      this.goToSearchPage(searchValue);
      event.preventDefault();
      event.stopPropagation();
    } else if (event.key === ' ' && searchValue === '') {
      this.handleSpace();
      event.preventDefault();
    }
  }

  @autobind
  onRemoveRecentSearch(searchTerm: string) {
    this.viewModel.onRemoveRecentSearch(searchTerm);
  }

  @autobind
  handleOpenMenu() {
    if (!this.viewModel.isMenuOpen) {
      this.viewModel.openMenu();
    }
  }

  @autobind
  handleCloseMenu() {
    this.viewModel.closeMenu();
  }

  render(): Element<'div'> {
    const {displayRecentSearches = [], isMenuOpen, searchValue = ''} = this.viewModel;

    return (
      <div className="search-bar">
        <SelectBox
          components={{DropdownIndicator, NoOptionsMessage, Option, Menu}}
          inputValue={searchValue}
          isSearchable
          menuIsOpen={isMenuOpen}
          onBlur={this.handleCloseMenu}
          onChange={this.onChange}
          onFocus={this.handleOpenMenu}
          onInputChange={this.changeSearchTerm}
          onKeyDown={this.onKeyDown}
          onRemoveRecentSearch={this.onRemoveRecentSearch}
          onSearch={this.onSearch}
          options={displayRecentSearches}
          placeholder="Search"
        />
      </div>
    );
  }
}

export default SearchBar;
