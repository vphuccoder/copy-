// @flow
import * as React from 'react';
import autobind from 'autobind-decorator';
import {TextOverFlow} from '../../baseComponents';
type PropsType = {
  setValue: (value: string) => void,
  data: {
    value: string,
    label: string
  },
  selectProps: {
    onRemoveRecentSearch: (value: string) => void
  }
};
export default class Option extends React.Component<PropsType> {
  @autobind
  onSelectOptions() {
    this.props.setValue(this.props.data.value);
  }

  @autobind
  onClear() {
    const {
      selectProps: {onRemoveRecentSearch},
      data
    } = this.props;
    if (onRemoveRecentSearch) {
      onRemoveRecentSearch(data.value);
    }
  }

  render(): React.Element<'div'> {
    const {props} = this;
    return (
      <div className="recent-search-item">
        <a className="paddingLeftRight-16 options-label" onClick={this.onSelectOptions}>
          <TextOverFlow className="option-text" textOverflow={props.data.label} placement="right" />
        </a>
        <span onClick={this.onClear}>
          <span className="close thick" />
        </span>
      </div>
    );
  }
}
