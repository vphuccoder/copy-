// @flow
import {action, computed, observable} from 'mobx';
import {appModel} from '../../../models/app-model';
import {BasePageViewModel} from '../../../pages/BasePageViewModel';
import {userService} from '../../../services';

class SearchBarViewModel extends BasePageViewModel {
  @observable
  recentSearches: Array<{label: string, value: string}> = [];

  @observable
  searchValue: string = '';

  @observable
  isMenuOpen: boolean = false;

  constructor(defaultValue: string = '') {
    super();
    this.searchValue = defaultValue;
  }

  @computed
  get displayRecentSearches(): Array<{label: string, value: string}> {
    return this.recentSearches.map(
      (recentSearch: string): {value: string, label: string} => ({
        label: recentSearch,
        value: recentSearch
      })
    );
  }

  @action
  changeSearchTerm(value: string) {
    this.searchValue = value;
  }

  @action
  onRemoveRecentSearch(searchTerm: string) {
    this.recentSearches = this.recentSearches.filter((recentSearch: string) => recentSearch !== searchTerm);
    try {
      const {currentToken} = appModel;
      userService.removeRecentSearch(currentToken.accessToken, searchTerm);
    } catch (error) {
      this.handleError(error);
    }
  }

  @action
  async getRecentSearchs(): void {
    try {
      const results = await userService.getUserSetting(appModel.currentToken.accessToken);
      this.recentSearches = results && results.searchTerms ? results.searchTerms : [];
    } catch (e) {
      this.recentSearches = [];
    }
  }

  @action
  openMenu() {
    this.isMenuOpen = true;
  }

  @action
  closeMenu() {
    this.isMenuOpen = false;
  }
}
export default SearchBarViewModel;
