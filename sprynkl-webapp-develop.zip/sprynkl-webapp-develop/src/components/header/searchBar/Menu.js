// @flow
import * as React from 'react';
import {Fragment} from 'react';
import autobind from 'autobind-decorator';
import {components} from 'react-select';
const {Menu} = components;
type PropsType = {
  setValue: (value: string) => void,
  data: {
    value: string,
    label: string
  },
  selectProps: {
    onRemoveRecentSearch: (value: string) => void
  }
};
export default class Option extends React.Component<PropsType> {
  @autobind
  onSelectOptions() {
    this.props.setValue(this.props.data.value);
  }

  @autobind
  onClear() {
    const {
      selectProps: {onRemoveRecentSearch},
      data
    } = this.props;
    if (onRemoveRecentSearch) {
      onRemoveRecentSearch(data.value);
    }
  }

  render(): React.Node {
    const {props} = this;
    return (
      <Fragment>
        <Menu {...props}>
          <div className="menu">Recent Searches</div>
          {this.props.children}
        </Menu>
      </Fragment>
    );
  }
}
