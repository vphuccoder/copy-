// @flow
import autobind from 'autobind-decorator';
import * as React from 'react';
import Icon from '../../baseComponents/Icon';

type PropsType = {
  selectProps: {
    onSearch: () => void
  }
};
export default class DropdownIndicator extends React.PureComponent<PropsType> {
  @autobind
  onSearch() {
    this.props.selectProps.onSearch();
  }
  render(): React.Element<'div'> {
    return (
      <div className="paddingLeftRight-8 search-icon" onClick={this.onSearch}>
        <Icon color="#777b7d" iconName="search" size={24} />
      </div>
    );
  }
}
