import * as React from 'react';

export default class NoOptionsMessage extends React.PureComponent {
  render() {
    return <div className="no-options-message" />;
  }
}
