// @flow
import React, {Component} from 'react';
import {OverlayTrigger, Popover, Button, ListGroup} from 'react-bootstrap';
import {withRouter} from 'react-router';
import autobind from 'autobind-decorator';
import {appModel} from '../../../models/app-model';
import {renderUserAvatar} from '../../baseComponents/svg/Avatar';
import ProfileLink from '../../baseComponents/profileLink';
import {FocusedProfile, Profile} from '../../baseComponents/svg/Icons';
import {storageService} from '../../../services';
import './AccountPopover.scss';

type PropsType = {};

type StateType = {
  isFocused: boolean
};

@withRouter
class AccountPopover extends Component<PropsType, StateType> {
  constructor(props: PropsType) {
    super(props);
    this.state = {
      isFocused: false
    };
  }

  @autobind
  logout() {
    storageService.clearRefreshToken();
    this.props.history.push('/login');
  }

  @autobind
  openSettings() {
    this.props.history.push('/settings');
  }

  @autobind
  onClickProfileItem() {
    this.setState({isFocused: true});
  }

  @autobind
  onExitOverlay() {
    this.setState({isFocused: false});
  }

  render(): React.Node {
    const {fullName, avatar, defaultAvatar} = appModel.currentUser;
    return (
      <OverlayTrigger
        trigger="click"
        placement="bottom"
        rootClose
        onExit={(): void => this.onExitOverlay()}
        overlay={
          <Popover className="account-popover">
            <ListGroup variant="flush">
              <ListGroup.Item className="my-profile-link">
                <ProfileLink user={appModel.currentUser}>
                  <span className="caption">Account</span>
                  <div className="info">
                    {renderUserAvatar(avatar, defaultAvatar, 32)}
                    <span className="name">{fullName}</span>
                  </div>
                </ProfileLink>
              </ListGroup.Item>
              <ListGroup.Item action className="no-border-link" onClick={this.openSettings}>
                Settings
              </ListGroup.Item>
              <ListGroup.Item action className="logout-link" onClick={this.logout}>
                Sign out
              </ListGroup.Item>
            </ListGroup>
          </Popover>
        }
      >
        <div className="profile-icon">
          <Button variant="link" onClick={(): void => this.onClickProfileItem()}>
            {this.state.isFocused ? <FocusedProfile /> : <Profile />}
          </Button>
        </div>
      </OverlayTrigger>
    );
  }
}

export default AccountPopover;
