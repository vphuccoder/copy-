// @flow
import React, {PureComponent} from 'react';
import {Dropdown} from 'react-bootstrap';
import autobind from 'autobind-decorator';
import TextOverFlow from '../../baseComponents/textOverFlow/TextOverFlow';
import './TeamSelection.scss';

class TeamItem extends PureComponent {
  @autobind
  selectTeam() {
    const {selectTeam, item} = this.props;
    if (selectTeam && item) {
      selectTeam(item.group.id);
    }
  }

  render(): React.Node {
    const {item} = this.props;
    return (
      <Dropdown.Item className="dropdown-item" key={item.group.id} onClick={this.selectTeam}>
        <div className="dropdown-text">
          <TextOverFlow className="group-name" tooltip={item.group.name} textOverflow={`Switch to ${item.group.name}`}>
            <div className="group-name-text" title={item.group.name}>
              <span className="group-text">{'Switch to'}</span>
              <span className="group-name">{` ${item.group.name}`}</span>
            </div>
          </TextOverFlow>
        </div>
      </Dropdown.Item>
    );
  }
}

export default TeamItem;
