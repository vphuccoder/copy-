// @flow
import autobind from 'autobind-decorator';
import {observer} from 'mobx-react';
import React, {Component, Fragment} from 'react';
import {Dropdown} from 'react-bootstrap';
import {icons} from '../../themes/Icons';
import Icon from '../../baseComponents/Icon';
import TeamItem from './TeamItem';
import TeamSelectionToggle from '../../baseComponents/CustomSelectToggle';
import TextOverFlow from '../../baseComponents/textOverFlow/TextOverFlow';
import './TeamSelection.scss';

type PropsType = {};

@observer
class TeamSelection extends Component {
  constructor(props: PropsType) {
    super(props);
  }

  @autobind
  showJoinTeamDialog() {
    const {showJoinTeamDialog} = this.props;
    if (showJoinTeamDialog) {
      showJoinTeamDialog();
    }
  }

  @autobind
  showInviteTeammateDialog() {
    const {showInviteTeammateDialog} = this.props;
    if (showInviteTeammateDialog) {
      showInviteTeammateDialog();
    }
  }

  @autobind
  createTeam() {
    const {clickCreateTeam} = this.props;
    if (clickCreateTeam) {
      clickCreateTeam();
    }
  }
  @autobind
  selectTeam(id: string) {
    const {selectTeam} = this.props;
    if (selectTeam) {
      selectTeam(id);
    }
  }

  renderGroups(): React.Node {
    const {groups, selectedGroup} = this.props;
    if (groups && groups.length) {
      return groups.map(
        (item: {}): React.Node => {
          if (selectedGroup && selectedGroup.id === item.group.id) {
            return null;
          }
          return <TeamItem item={item} key={item.group.id} selectTeam={this.selectTeam} />;
        }
      );
    }
  }

  renderSelectGroup(): React.Node {
    const {selectedGroup} = this.props;
    if (selectedGroup) {
      return <TextOverFlow className="group-name" textOverflow={selectedGroup.name} />;
    }

    return <span>{'All Team'}</span>;
  }

  @autobind
  editTeamProfile() {
    const {editTeamProfile} = this.props;
    if (editTeamProfile) {
      editTeamProfile();
    }
  }

  renderTeamEdit(): React.Node {
    const {selectedGroup, isLead} = this.props;
    if (selectedGroup) {
      return (
        <Fragment>
          <Dropdown.Divider className="sperate-line" />
          {isLead && (
            <Dropdown.Item className="dropdown-item" onClick={this.showInviteTeammateDialog}>
              Invite teammates
            </Dropdown.Item>
          )}
          <Dropdown.Item className="dropdown-item">Directory</Dropdown.Item>
          {isLead && (
            <Dropdown.Item onClick={this.editTeamProfile} className="dropdown-item">
              Edit team profile
            </Dropdown.Item>
          )}
          <Dropdown.Item className="dropdown-item leave-team">
            <TextOverFlow
              className="group-name"
              tooltip={selectedGroup.name}
              textOverflow={`Leave ${selectedGroup.name} Team`}
            />
          </Dropdown.Item>
        </Fragment>
      );
    }
  }

  @autobind
  selectAllTeam() {
    this.selectTeam();
  }

  renderSelectAll(): React.Node {
    const {selectedGroup, groups} = this.props;
    if (selectedGroup && groups.length > 1) {
      return (
        <Dropdown.Item className="dropdown-item" key={'all_team'} onClick={this.selectAllTeam}>
          {'All Team'}
        </Dropdown.Item>
      );
    }
  }

  render(): React.Node {
    const {disabled} = this.props;
    return (
      <div className="selection-team">
        <Dropdown>
          <Dropdown.Toggle className="dropdown-toggle" as={TeamSelectionToggle} disabled={disabled}>
            {this.renderSelectGroup()}
            <div className="dropdown-icon">
              <Icon color={'#777b7d'} size={32} iconName={icons.angleDown} />
            </div>
          </Dropdown.Toggle>
          <Dropdown.Menu className="dropdown-menu">
            {this.renderSelectAll()}
            {this.renderGroups()}
            <Dropdown.Item className="dropdown-item" onClick={this.showJoinTeamDialog}>
              Your invites
            </Dropdown.Item>
            <Dropdown.Item className="dropdown-item" onClick={this.createTeam}>
              Create a new team
            </Dropdown.Item>
            {this.renderTeamEdit()}
          </Dropdown.Menu>
        </Dropdown>
      </div>
    );
  }
}

export default TeamSelection;
