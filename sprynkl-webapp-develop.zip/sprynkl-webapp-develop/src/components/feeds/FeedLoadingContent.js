// @flow
import React, {Component} from 'react';
import {FeedItemLoadingContent} from '../baseComponents/svg/Svg';
import './FeedLoadingContent.scss';

type PropsType = {};

type StateType = {};

class FeedLoadingContent extends Component<PropsType, StateType> {
  render(): React.Node {
    return (
      <div className="feed-loading-container">
        <div className="feed-loading-content">
          <FeedItemLoadingContent />
        </div>
        <div className="feed-loading-content">
          <FeedItemLoadingContent />
        </div>
        <div className="feed-loading-content">
          <FeedItemLoadingContent />
        </div>
      </div>
    );
  }
}

export default FeedLoadingContent;
