// @flow

import React from 'react';
import {
  FEED_EMPTY_STATE_DESCRIPTION,
  FEED_EMPTY_STATE_TITLE,
  USER_FEED_EMPTY_STATE_TITLE,
  USER_FEED_EMPTY_STATE_DESCRIPTION
} from '../../../models/constants/string-constant';
import {FeedEmptyStateBackground} from '../../baseComponents/svg/Svg';
import './FeedEmptyState.scss';

type PropsType = {
  isProfileScreen: boolean
};

class FeedEmptyState extends React.Component<PropsType> {
  render(): React.Node {
    const {isProfileScreen} = this.props;
    const titleEmpty =
      isProfileScreen && isProfileScreen === true ? USER_FEED_EMPTY_STATE_TITLE : FEED_EMPTY_STATE_TITLE;
    const descriptionEmpty =
      isProfileScreen && isProfileScreen === true ? USER_FEED_EMPTY_STATE_DESCRIPTION : FEED_EMPTY_STATE_DESCRIPTION;

    return (
      <div className="feed-empty-state">
        <FeedEmptyStateBackground />
        <div className="feed-empty-state-title">{titleEmpty}</div>
        <div className="feed-empty-state-description">{descriptionEmpty}</div>
      </div>
    );
  }
}

export default FeedEmptyState;
