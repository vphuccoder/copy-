/**
 * @format
 * @flow
 */
import React, {Component, Fragment} from 'react';
import type {Node} from 'react';
import autobind from 'autobind-decorator';
import {withRouter} from 'react-router';
import type {RouterHistory} from 'react-router';
import {observer} from 'mobx-react';
import {appModel} from '../../../models/app-model';
import {Comment, User} from '../../../models';
import Icon from '../../baseComponents/Icon';
import {icons} from '../../themes/Icons';
import ClapAnimation from '../clapAnimation/ClapAnimation';
import {RichTextInput} from '../../richTextInput';
import {renderUserAvatar} from '../../baseComponents/svg/Avatar';
import {uriDecoder} from '../../../utils/utils';
import {PostViewModel} from '../';
import {PostComment} from '../../postComment';
import FooterViewModel from './FooterViewModel';

const lightIconColor = '#dbddde';
const primaryColor = '#fc4167';

type PropsType = {
  postVM: PostViewModel,
  history: RouterHistory,
  showLastComment: boolean,
  clapAPost: () => mixed,
  renderComments: (activeUserList: Array<User>) => Array<Node<>>,
  disabled: boolean
};

type StateType = {
  showClap: boolean
};

@withRouter
@observer
class Footer extends Component<PropsType, StateType> {
  viewModel: FooterViewModel;

  constructor(props: PropsType) {
    super(props);
    this.viewModel = new FooterViewModel();
    const {postVM} = this.props;
    this.viewModel.postVM = postVM;
    this.state = {showClap: false};

    const {post} = postVM;
    this.viewModel.setActiveMembers(post);
  }

  @autobind
  clapAPost() {
    const {clapAPost, postVM} = this.props;
    this.setState({
      showClap: true
    });

    postVM.clapDone();

    if (clapAPost) {
      clapAPost();
    }
  }

  @autobind
  renderClapAnimation(): Node {
    const {showClap} = this.state;
    const {postVM} = this.props;

    if (showClap) {
      return <ClapAnimation clapCount={postVM.userClap} onComplete={(): void => this.setState({showClap: false})} />;
    }
    return null;
  }

  @autobind
  onClickHashTag(value: string) {
    this.props.history.push({
      pathname: uriDecoder(value)
    });
  }

  @autobind
  onClickTag(user: User) {
    if (user) {
      this.props.history.push(`./profile/${user.id}`);
    }
  }

  @autobind
  onDeleteComment(comment: Comment) {
    const {
      postVM: {post}
    } = this.viewModel;
    const commentIndex = post.comments.indexOf(comment);
    if (commentIndex >= 0) {
      post.comments.splice(commentIndex, 1);
    }
  }

  @autobind
  renderLatestComment(): Node {
    if (!this.props.showLastComment) {
      return null;
    }

    const {postVM, activeUserList} = this.viewModel;
    const {post} = postVM;
    const {comments, group} = post;
    const {length} = comments;

    if (length === 0) {
      return;
    }

    const latestComment = comments[length - 1];

    return (
      <div className="feed-latest-comment">
        <PostComment
          comment={latestComment}
          postGroup={group}
          activeUserList={activeUserList}
          onClickTag={this.onClickTag}
          onClickHashTag={this.onClickHashTag}
          onDelete={this.onDeleteComment}
        />
      </div>
    );
  }

  @autobind
  onPostComment(comment: string, extraData: {}) {
    const {viewModel} = this;
    const {postVM} = viewModel;
    const {post} = postVM;
    viewModel.postComment(post.id, comment, extraData);
  }

  @autobind
  renderComments(): Node {
    const {renderComments} = this.props;
    if (renderComments) {
      return renderComments();
    }
  }

  @autobind
  onChangeText() {
    // TODO: implement later
  }

  @autobind
  goToPostDetail() {
    const {
      props: {history, disabled},
      viewModel: {
        postVM: {post}
      }
    } = this;
    if (post && !disabled) {
      history.push(`/post/${post.id}`);
    }
  }

  render(): Node {
    const currentUser = appModel.currentUser || {};
    const {viewModel} = this;
    const {postVM, tagUserList} = viewModel;
    const {post, clapCount, userClap} = postVM;
    const commentIcon = icons.comment;

    const clapIcon = userClap > 0 ? icons.clapsActive : icons.claps;
    const clapColor = userClap > 0 ? primaryColor : lightIconColor;

    return (
      <Fragment>
        <div className="feed-footer">
          {this.renderClapAnimation()}
          <button className="feed-footer-item" onClick={this.clapAPost}>
            <div className="footer-container-left">
              <Icon color={clapColor} size={32} iconName={clapIcon} />
              <span>{clapCount}</span>
            </div>
          </button>
          <button className="feed-footer-item" onClick={this.goToPostDetail}>
            <div className="footer-container-right">
              <Icon color={lightIconColor} size={32} iconName={commentIcon} />
              <span>{post.comments.length}</span>
            </div>
          </button>
        </div>
        {this.renderLatestComment()}
        {this.renderComments()}
        <div className="feed-comment">
          {renderUserAvatar(currentUser.avatar, currentUser.defaultAvatar, 32)}
          <RichTextInput
            allowTag
            onChangeText={this.onChangeText}
            onSubmit={this.onPostComment}
            tagUserList={tagUserList}
          />
        </div>
      </Fragment>
    );
  }
}

export default Footer;
