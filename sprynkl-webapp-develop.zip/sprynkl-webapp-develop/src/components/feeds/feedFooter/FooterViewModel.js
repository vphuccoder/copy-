/**
 * @flow
 * @format
 */
import {postService} from '../../../services';
import {appModel} from '../../../models/app-model';
import {BasePageViewModel} from '../../../pages/BasePageViewModel';
import {GroupRoles} from '../../../models/group-roles';
import {action} from 'mobx';
import {TagVM} from '../../tagSuggestion';
import {PostModel, UserStatus, THANKS, User, UserGroup} from '../../../models';
import {PostViewModel} from '../index';

class FooterViewModel extends BasePageViewModel {
  activeUserList: User[] = [];

  tagUserList: TagVM[] = [];

  postVM: PostViewModel = null;

  @action
  setActiveMembers(post: PostModel) {
    let activeMembers: User[] = [];
    try {
      const members = post.group.members;
      const userGroups = members.filter((u: UserGroup): boolean => u.role !== GroupRoles.INVITED);
      activeMembers = userGroups.map((u: UserGroup): User => u.user);
      this.activeUserList = activeMembers;
      this.setTagUserList(activeMembers, post);
    } catch (ex) {
      this.handleError(ex, false);
    }
  }

  @action
  setTagUserList(activeMembers: User[], post: PostModel) {
    // calculate tag list
    let tagUserList: User[] = [];
    if (post.type === THANKS) {
      tagUserList = [...activeMembers];
    } else {
      const {sendTo, anonymous, author} = post;
      if (sendTo.length > 0) {
        const activeSentTo = sendTo.filter((user: User): boolean => user.userStatus === UserStatus.ACTIVE);
        if (!anonymous && author && author.userStatus === UserStatus.ACTIVE) {
          activeSentTo.push(author);
        }
        tagUserList = [...activeSentTo];
      } else {
        tagUserList = [...activeMembers];
      }
    }
    const tagUserListWithoutMe = tagUserList.filter((user: User): boolean => user.id !== appModel.currentUser.id);
    this.tagUserList = tagUserListWithoutMe.map((user: User): TagVM => TagVM.map(user));
  }

  @action
  async postComment(postId: string, content: string, extraData: {}): Promise {
    const {accessToken} = appModel.currentToken;
    try {
      this.showLoading();
      const postModel = await postService.commentAPost(accessToken, postId, content.trim(), extraData);
      this.postVM.setPost(postModel);
      this.hideLoading();
    } catch (ex) {
      this.hideLoading();
      this.handleError(ex, true);
    }
  }
}

export default FooterViewModel;
