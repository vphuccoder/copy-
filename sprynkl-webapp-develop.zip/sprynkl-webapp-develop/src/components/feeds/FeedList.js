// @flow
import React, {Component} from 'react';
import autobind from 'autobind-decorator';
import {debounce} from '../../utils/utils';
import {observer} from 'mobx-react';
import {appModel} from '../../models/app-model';
import {postService} from '../../services';
import FeedEmptyState from './feedEmptyState/FeedEmptyState';
import FeedLoadingContent from './FeedLoadingContent';
import {PostViewModel, FeedItem} from './';

@observer
class FeedList extends Component {
  constructor(props: {}) {
    super(props);
    this.onClapDelayed = debounce(this.clapPost, 500);
  }

  scrollableParenElement: HTMLElement;

  elementContainer: HTMLElement;

  loadMoreThreshold: number = 250;

  componentDidMount() {
    window.addEventListener('scroll', this.handleScroll);
  }

  componentWillUnmount() {
    window.removeEventListener('scroll', this.handleScroll);
  }

  @autobind
  handleScroll() {
    const rect = this.elementContainer.getBoundingClientRect();
    const top = -rect.top;
    if (window.innerHeight + top < this.elementContainer.offsetHeight - this.loadMoreThreshold) {
      return;
    }
    const {loadMore} = this.props;

    if (loadMore) {
      loadMore();
    }
  }

  @autobind
  deletePost(postVm: PostViewModel) {
    const {deletePost} = this.props;
    if (deletePost) {
      deletePost(postVm);
    }
  }

  @autobind
  async clapPost(item: PostViewModel): Promise {
    try {
      const clapUser = item.post.claps.find(
        (userClap: Clap): boolean => appModel.currentUser && userClap.user.id === appModel.currentUser.id
      );
      if ((clapUser && clapUser.total < 10) || !clapUser) {
        const newPost = await postService.clapAPost(appModel.currentToken.accessToken, item.post.id, item.userClap);
        item.setPost(newPost);
      }
    } catch (e) {
      // errorSe.handleErrors(e);
    }
  }

  onPostComment(postId: string, comment: string, extraData: {}) {
    const {onPostComment} = this.props;
    if (onPostComment) {
      onPostComment(postId, comment, extraData);
    }
  }

  @autobind
  renderItem(feed: PostViewModel): React.Node {
    return (
      <div key={`feed-item-${feed.post.id}`}>
        <FeedItem
          item={feed}
          deletePost={(): void => this.deletePost(feed)}
          onPostComment={this.onPostComment}
          clapAPost={this.onClapDelayed}
        />
      </div>
    );
  }

  @autobind
  renderList(): React.Node[] {
    const {feeds, isProfileScreen, showLoadingContent, renderEmptyState} = this.props;

    if (showLoadingContent) {
      return <FeedLoadingContent />;
    }

    const feedList = feeds || [];
    const list = [];

    if (feedList.length <= 0) {
      if (renderEmptyState) {
        return renderEmptyState();
      }
      return <FeedEmptyState isProfileScreen={isProfileScreen} />;
    }

    feedList.forEach((feed: PostViewModel) => {
      list.push(this.renderItem(feed));
    }, this);
    return list;
  }

  @autobind
  onContainerRef(ref: HTMLDivElement) {
    this.elementContainer = ref;
  }

  render(): React.Node {
    return <div ref={this.onContainerRef}>{this.renderList()}</div>;
  }
}

export default FeedList;
