// @flow
import {observable, action} from 'mobx';
import autobind from 'autobind-decorator';
import {PostModel, Clap} from '../../models';
import {appModel} from '../../models/app-model';
import {AskContentViewModel} from '../askContent';
import {ASK} from '../../models/post-model';

export class PostViewModel {
  @observable
  post: PostModel;

  @observable
  clapCount: number = 0;

  @observable
  userClap: number = 0;

  askContentVM: AskContentViewModel;

  @action
  setPost(post: PostModel) {
    this.post = post;
    let clapCount = 0;
    const clap = post.claps.find(
      (userClap: Clap): boolean => appModel.currentUser && userClap.user.id === appModel.currentUser.id
    );
    this.userClap = clap ? Math.max(clap.total, this.userClap) : 0;
    post.claps.forEach((clap: Clap) => {
      clapCount += clap.total;
    });
    this.clapCount = Math.max(this.clapCount, clapCount);
  }

  isUserInteracted(post: PostModel): boolean {
    const clapIndex = post.claps.findIndex(
      (userClap: Clap): boolean => appModel.currentUser && userClap.user.id === appModel.currentUser.id
    );
    return clapIndex > -1;
  }

  @action
  clapDone() {
    if (this.userClap < 10) {
      this.clapCount++;
    }
    this.userClap++;
  }

  static toViewModel(post: PostModel): PostViewModel {
    const vm = new PostViewModel();
    vm.setPost(post);

    if (post.type === ASK) {
      const {askContent, author, content: question, id: postId, sendTo = []} = post;

      vm.askContentVM = new AskContentViewModel({
        askContent,
        author,
        question,
        postId,
        totalReceiver: sendTo.length
      });
    }

    return vm;
  }

  @autobind
  isCreator(): boolean {
    const {post} = this;
    const {author} = post;
    return author && appModel.currentUser && author.id === appModel.currentUser.id;
  }
}
