// @flow
import * as React from 'react';
import {observer} from 'mobx-react';
import autobind from 'autobind-decorator';
import {withRouter} from 'react-router';
import {uriDecoder} from '../../../utils/utils';
import {PostComment} from '../../postComment';
import {Comment, User, Group} from '../../../models';
import './CommentList.scss';

type PropsType = {
  comments: Array<Comment>,
  activeUserList: Array<User>,
  onDeleteComment: (comment: Comment) => void,
  postGroup: Group,
  history: History
};

@withRouter
@observer
class CommentList extends React.PureComponent<PropsType> {
  @autobind
  onClickTag() {}

  @autobind
  onClickHashTag(value: string) {
    this.props.history.push({
      pathname: uriDecoder(value)
    });
  }

  @autobind
  onDeleteComment(comment: Comment) {
    const {onDeleteComment} = this.props;
    if (onDeleteComment) {
      onDeleteComment(comment);
    }
  }

  @autobind
  renderCommentList(): ?Array<React.Node> {
    const {activeUserList = [], postGroup, comments} = this.props;
    if (comments && comments.length > 0) {
      return comments.map(
        (comment: Comment): React.Node => {
          return (
            <div className="paddingLeftRight-24 paddingTopBottom-8" key={comment.id}>
              <PostComment
                comment={comment}
                postGroup={postGroup}
                activeUserList={activeUserList}
                onClickTag={this.onClickTag}
                onClickHashTag={this.onClickHashTag}
                onDelete={this.onDeleteComment}
              />
            </div>
          );
        }
      );
    }
    return null;
  }

  render(): React.Element<'div'> {
    const {comments} = this.props;
    if (comments && comments.length === 0) {
      return null;
    }

    return <div className="comment-lists">{this.renderCommentList()}</div>;
  }
}

export default CommentList;
