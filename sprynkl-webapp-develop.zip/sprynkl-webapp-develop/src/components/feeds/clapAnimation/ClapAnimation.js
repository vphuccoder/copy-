import React, {Component} from 'react';
import posed from 'react-pose';
import {clapOval, clapBackground} from '../../baseComponents/svg/Svg';
import './ClapAnimation.scss';

const BoxContainer = posed.div({
  init: {
    scale: 0,
    transition: {duration: 0},
    opacity: 0.5,
    y: 50
  },
  normal: {
    scale: 1,
    transition: {duration: 200},
    opacity: 1,
    y: 0
  },
  big: {
    scale: 1,
    transition: {duration: 50},
    opacity: 1,
    y: 0
  },
  exit: {
    scale: 1,
    transition: {duration: 150},
    opacity: 0,
    y: -50
  }
});

const ClapOvalContainer = posed.div({
  init: {
    scale: 0,
    transition: {duration: 0}
  },
  normal: {
    scale: 1.2,
    transition: {stiffness: 180, type: 'spring', damping: 10}
  },
  big: {
    scale: 1.5,
    transition: {duration: 50}
  },
  exit: {
    scale: 1,
    transition: {duration: 200}
  }
});

const BackgroundClap = posed.div({
  init: {
    scale: 0,
    transition: {duration: 0},
    opacity: 1
  },
  normal: {
    scale: 1.6,
    transition: {duration: 100, delay: 40},
    opacity: 1
  },
  big: {
    scale: 1,
    opacity: 0,
    transition: {duration: 0}
  },
  exit: {
    scale: 2,
    transition: {duration: 200},
    opacity: 0
  }
});

export default class ClapAnimation extends Component {
  state = {
    status: 'init',
    backgroundStatus: 'init',
    rotate: `45deg`
  };
  componentDidMount() {
    this.setState({
      status: 'normal',
      backgroundStatus: 'normal',
      rotate: `${Math.round(Math.random() * 90)}deg`
    });
  }
  componentDidUpdate(prevProps) {
    const {clapCount} = this.props;
    const {status} = this.state;
    if (clapCount !== prevProps.clapCount) {
      this.setState({
        status: status === 'normal' ? 'big' : 'init',
        backgroundStatus: 'big',
        rotate: `${Math.round(Math.random() * 90)}deg`
      });
    }
  }

  changeAnimatedStatus = (type) => {
    const {onComplete} = this.props;
    switch (this.state[type]) {
      case 'init':
        if (type === 'status') {
          setTimeout(() => {
            this.setState({[type]: 'normal'});
          }, 20);
        }
        return;
      case 'normal':
        this.setState({[type]: 'exit'});
        return;
      case 'big':
        this.setState({[type]: 'normal'});
        return;
      case 'exit':
        this.setState({[type]: 'init'});
        if (onComplete && type === 'status') {
          onComplete();
        }
        return;
      default:
        return;
    }
  };

  render() {
    const {clapCount} = this.props;
    return (
      <div className="clap-animation">
        <BoxContainer
          className="clap-animation-box"
          pose={this.state.status}
          onPoseComplete={() => this.changeAnimatedStatus('status')}
        >
          <ClapOvalContainer pose={this.state.status} className="clap-oval-box">
            {clapOval()}
            <span className="clap-text-number">+{Math.min(10, clapCount)}</span>
          </ClapOvalContainer>
        </BoxContainer>
        <div className="clap-animation-background">
          <div style={{transform: `rotate(${this.state.rotate})`}}>
            <BackgroundClap
              pose={this.state.backgroundStatus}
              onPoseComplete={() => this.changeAnimatedStatus('backgroundStatus')}
            >
              {clapBackground()}
            </BackgroundClap>
          </div>
        </div>
      </div>
    );
  }
}
