/**
 * @flow
 * @format
 */
import React, {Component} from 'react';
import autobind from 'autobind-decorator';
import {Body, Footer, Header} from '../index';
import './FeedItem.scss';

class FeedItem extends Component {
  @autobind
  deletePost() {
    const {deletePost} = this.props;
    if (deletePost) {
      deletePost();
    }
  }

  @autobind
  onPostComment(postId: string, comment: string, extraData: {}) {
    const {onPostComment} = this.props;
    if (onPostComment) {
      onPostComment(postId, comment, extraData);
    }
  }

  render(): React.Node {
    const item = this.props.item || {};
    const {clapAPost} = this.props;
    const post = item.post;
    if (!post) {
      return null;
    }
    return (
      <div className="feedItem">
        <Header post={post} deletePost={this.deletePost} />
        <Body post={post} postVM={item} />
        <Footer
          postVM={item}
          onPostComment={this.onPostComment}
          clapAPost={(): void => clapAPost(item)}
          showLastComment
        />
      </div>
    );
  }
}

export default FeedItem;
