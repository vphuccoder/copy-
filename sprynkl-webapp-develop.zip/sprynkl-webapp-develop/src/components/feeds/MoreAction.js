// @flow

import React, {Component} from 'react';
import {Dropdown} from 'react-bootstrap';
import autobind from 'autobind-decorator';
import {observer} from 'mobx-react';
import {icons} from '../themes/Icons';
import Icon from '../baseComponents/Icon';
import MoreActionToggle from '../baseComponents/CustomSelectToggle';
import {SYSTEM_VARIABLE} from '../../models/constants/index';

type PropsType = {
  canDelete: boolean,
  canReport: boolean,
  iconSize: number
};

type StateType = {
  dropdownOpen: boolean
};

@observer
class MoreAction extends Component<PropsType, StateType> {
  constructor(props: PropsType) {
    super(props);
    this.state = {
      dropdownOpen: false
    };
  }

  @autobind
  toggle() {
    this.setState(
      (prevState: StateType): {} => ({
        dropdownOpen: !prevState.dropdownOpen
      })
    );
  }

  @autobind
  onMouseEnter() {
    this.setState({dropdownOpen: true});
  }

  @autobind
  onMouseLeave() {
    this.setState({dropdownOpen: false});
  }

  @autobind
  onDelete() {
    const {onDelete} = this.props;
    if (onDelete) {
      onDelete();
    }
  }
  @autobind
  onReport() {
    const {onReport} = this.props;
    if (onReport) {
      onReport();
    }
  }

  @autobind
  renderDelete(canDelete: boolean): React.Node {
    return canDelete === true ? (
      <Dropdown.Item onClick={this.onDelete}>
        Delete
        <p>Remove this from your team feed.</p>
      </Dropdown.Item>
    ) : null;
  }

  @autobind
  renderReport(canDelete: boolean): React.Node {
    return canDelete === true ? (
      <Dropdown.Item onClick={this.onReport}>
        Report
        <p>Let your Team Lead know this doesn’t belong here.</p>
      </Dropdown.Item>
    ) : null;
  }

  @autobind
  renderSeparator(canDelete: boolean, canReport: boolean): React.Node {
    return canDelete === true && canReport === true ? <Dropdown.Divider /> : null;
  }

  render(): React.Node {
    const {canDelete, canReport, iconSize} = this.props;
    const iconSizeValue = iconSize ? iconSize : SYSTEM_VARIABLE.ICON_SIZE;

    return (
      <div className="more-action">
        <Dropdown
          onMouseOver={this.onMouseEnter}
          onMouseLeave={this.onMouseLeave}
          show={this.state.dropdownOpen}
          onToggle={this.toggle}
        >
          <Dropdown.Toggle className="dropdown-toggle" as={MoreActionToggle}>
            <Icon color="#777b7d" iconName={icons.more} size={iconSizeValue} />
          </Dropdown.Toggle>
          <Dropdown.Menu alignRight>
            {this.renderReport(canReport)}
            {this.renderSeparator(canDelete, canReport)}
            {this.renderDelete(canDelete)}
          </Dropdown.Menu>
        </Dropdown>
      </div>
    );
  }
}

export default MoreAction;
