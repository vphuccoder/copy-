// @flow

import autobind from 'autobind-decorator';
import React, {Component} from 'react';
import {ASK, PostModel, THANKS, User, VOICE} from '../../../models';
import {appModel} from '../../../models/app-model';
import {postService} from '../../../services';
import {TextOverFlow, ProfileLink} from '../../baseComponents';
import {AskIcon, ThanksIcon, VoiceIcon} from '../../baseComponents/svg/Svg';
import {MemberReceiverListModal, ReportPostModal} from '../../modals';
import MoreAction from '../MoreAction';
import './Header.scss';

const MAXIMUM_RECEIVERS = 2;

type PropsType = {
  deletePost: void,
  post: PostModel
};

type StateType = {
  showReportModal: boolean
};

class Header extends Component<PropsType, StateType> {
  constructor(props: PropsType) {
    super(props);
    this.state = {showReportModal: false};
  }

  @autobind
  onDeletePost() {
    const {deletePost, post} = this.props;
    if (this.canDeleteSelectedPost()) {
      appModel.dialogViewModel.showConfirm(
        `Are you sure you want to permanently remove this post from ${post.group.name}?`,
        'Delete Post',
        'Delete',
        'Cancel',
        () => {
          if (deletePost) {
            deletePost();
          }
        },
        () => {}
      );
    }
  }

  @autobind
  onReportPost() {
    this.setState({showReportModal: true});
  }

  @autobind
  oncloseReport() {
    this.setState({showReportModal: false});
  }

  @autobind
  async onSubmitReport(description: string) {
    const {post} = this.props;
    if (description && description !== '' && description.length >= 3) {
      this.setState({showReportModal: false});
      try {
        appModel.dialogViewModel.showProgressIndicator();
        const {accessToken} = appModel.currentToken;
        await postService.reportPost(accessToken, post.id, description);
        appModel.dialogViewModel.hideProgressIndicator();
        appModel.alertMessageViewModel.showAlert(
          'Thanks for looking out for your team. Your team lead has your report.'
        );
      } catch (ex) {
        appModel.dialogViewModel.hideProgressIndicator();
      }
    }
  }

  @autobind
  renderMoreActions(): React.Node {
    const canDelete = this.canDeleteSelectedPost();
    return (
      <MoreAction
        canDelete={canDelete}
        canReport={!canDelete}
        onDelete={this.onDeletePost}
        onReport={this.onReportPost}
      />
    );
  }

  @autobind
  canDeleteSelectedPost(): boolean {
    const {post} = this.props;
    const {currentUser} = appModel;
    if (!currentUser) {
      return false;
    }

    if (post.author && post.author.id === currentUser.id) {
      return true;
    }

    if (!post.group) {
      return false;
    }

    return currentUser.isLeadGroup(post.group.id);
  }

  @autobind
  renderIcon(): React.Node {
    const {post} = this.props;
    const type = post.type;
    switch (type) {
      case ASK:
        return <AskIcon />;
      case THANKS:
        return <ThanksIcon />;
      case VOICE:
        return <VoiceIcon />;
      default:
        return null;
    }
  }

  @autobind
  renderAuthor(): React.Node {
    const {post} = this.props;
    const author = post.author;
    if (author) {
      return (
        <div className="author-profile">
          <ProfileLink user={author} />
        </div>
      );
    } else {
      return <div className="author-profile"> Someone</div>;
    }
  }

  @autobind
  renderTime(): React.Node {
    const {post} = this.props;
    let timeRow = `${post.createdDate} • ${post.group.name}`;
    if (!post.group) {
      timeRow = `${post.createdDate}`;
    }
    return (
      <div className="feed-header-time">
        <TextOverFlow>
          <span title={post.group.name}>{timeRow}</span>
        </TextOverFlow>
      </div>
    );
  }

  @autobind
  renderOtherReceiver(otherReceivers: []): React.Node {
    return (
      otherReceivers &&
      otherReceivers.length > 0 && (
        <span>
          <span className="feed-header-normal-text"> and </span>
          <MemberReceiverListModal receiverList={otherReceivers}>
            {`${otherReceivers.length} others`}
          </MemberReceiverListModal>
        </span>
      )
    );
  }

  @autobind
  renderReceiver(receivers: []): React.Node {
    if (receivers && receivers.length > 0) {
      return receivers.map(
        (item: User, index: number): React.Node => {
          return (
            <span key={item.id}>
              <ProfileLink user={item} />
              {index < receivers.length - 2 && <span className="feed-header-normal-text">{', '}</span>}
              {index === receivers.length - 2 && <span className="feed-header-normal-text"> and </span>}
            </span>
          );
        }
      );
    }
  }

  render(): React.Node {
    const {showReportModal} = this.state;
    const {post} = this.props;
    let receivers = [];
    let otherReceivers = [];

    if (post.sendTo.length > MAXIMUM_RECEIVERS) {
      receivers = post.sendTo.slice(0, MAXIMUM_RECEIVERS - 1);
      otherReceivers = post.sendTo.slice(MAXIMUM_RECEIVERS - 1, post.sendTo.length);
    } else {
      receivers = post.sendTo;
    }

    return (
      <div className="feed-header">
        <ReportPostModal
          show={showReportModal}
          title="Report Post"
          onClose={this.oncloseReport}
          onSubmit={this.onSubmitReport}
        />
        {this.renderMoreActions()}
        <div>{this.renderIcon()}</div>
        <div className="feed-header-info">
          <div className="feed-header-title">
            <div className="feed-header-sender">
              {this.renderAuthor()}
              {receivers && receivers.length > 0 && <span className="feed-header-normal-text"> to </span>}
              {this.renderReceiver(receivers)}
              {this.renderOtherReceiver(otherReceivers)}
            </div>
            {this.renderTime()}
          </div>
        </div>
      </div>
    );
  }
}

export default Header;
