// @flow
import autobind from 'autobind-decorator';
import * as React from 'react';
import {observer} from 'mobx-react';
import {withRouter} from 'react-router';
import {uriDecoder} from '../../../utils/utils';
import {ASK, PostModel} from '../../../models';
import {AskContent} from '../../askContent';
import {PostContentText} from '../../postContentText/index';
import {PostViewModel} from '..';

import './Body.scss';

type PropsType = {
  post: PostModel,
  postVM: PostViewModel,
  showFullContent: boolean,
  history: History
};
@withRouter
@observer
class Body extends React.Component<PropsType> {
  renderImage(): React.Element<'img'> {
    const {post} = this.props;
    const {images} = post;
    if (images && images.length > 0) {
      const image = images[0];
      return <img src={image.url} />;
    }
    return null;
  }

  renderAskContent(): React.Node {
    const {post, postVM} = this.props;
    if (post.type === ASK) {
      const {askContentVM} = postVM;
      return <AskContent viewModel={askContentVM} />;
    }
  }

  @autobind
  onClickHashTag(value: string) {
    this.props.history.push({
      pathname: uriDecoder(value)
    });
  }

  render(): React.Node {
    const {post, postVM, showFullContent} = this.props;
    const {askContentVM = {}} = postVM;
    return (
      <div className="feed-body-container">
        <div className="feed-body">
          <span className="feed-body-content">
            <PostContentText
              postContent={post.content}
              responsedAsk={askContentVM.hasAnswered}
              showFullContent={showFullContent}
              onClickHashTag={this.onClickHashTag}
            />
          </span>
        </div>
        {this.renderImage()}
        {this.renderAskContent()}
      </div>
    );
  }
}

export default Body;
