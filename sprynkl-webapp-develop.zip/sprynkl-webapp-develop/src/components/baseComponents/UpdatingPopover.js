/**
 * @format
 * @flow
 */
import React, {Component} from 'react';
import {Popover} from 'react-bootstrap';

class UpdatingPopover extends Component {
  componentDidUpdate(prevProps: {}) {
    if (prevProps.children !== this.props.children) {
      this.props.scheduleUpdate();
    }
  }

  render(): React.Node {
    return <Popover {...this.props} />;
  }
}

export default UpdatingPopover;
