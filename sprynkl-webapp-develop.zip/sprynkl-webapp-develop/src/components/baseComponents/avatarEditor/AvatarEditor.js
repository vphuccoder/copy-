// @flow
import React, {PureComponent, Fragment} from 'react';
import type {Node} from 'react';
import ReactAvatarEditor from 'react-avatar-editor';
import autobind from 'autobind-decorator';
import {Modal, Button} from 'react-bootstrap';
import './AvatarEditor.scss';

type PropsType = {
  open: boolean,
  onComplete: (file: File) => void,
  onClose: () => void,
  file: ?File
};

type StateType = {
  tempAvatarUrl: string,
  scale: number
};

export default class AvatarEditor extends PureComponent<PropsType, StateType> {
  state = {
    scale: 1,
    tempAvatarUrl: ''
  };

  editor: ReactAvatarEditor;

  fileInput: ?HTMLInputElement;

  tempAvatar: ?File;

  @autobind
  resetEditor(): StateType {
    return {
      scale: 1,
      tempAvatarUrl: ''
    };
  }

  @autobind
  onComplete() {
    const {onComplete, file: selectedFile} = this.props;
    if (this.editor) {
      const canvasScaled = this.editor.getImageScaledToCanvas().toDataURL();
      fetch(canvasScaled)
        .then((res: Response): Promise<Blob> => res.blob())
        .then((blob: Blob) => {
          if (selectedFile) {
            const file = new File([blob], selectedFile.name, {type: selectedFile.type});
            const defaultState = this.resetEditor();
            this.setState(defaultState, () => {
              onComplete(file);
            });
          }
        });
    }
  }

  @autobind
  setEditorRef(editor: ReactAvatarEditor) {
    this.editor = editor;
  }

  @autobind
  generateTempAvatar(): string {
    const {file} = this.props;
    const {tempAvatarUrl} = this.state;
    let newTempAvatarUrl = '';
    if (file) {
      URL.revokeObjectURL(tempAvatarUrl);
      newTempAvatarUrl = URL.createObjectURL(file);
    }

    return newTempAvatarUrl;
  }

  componentDidUpdate(prevProps: PropsType) {
    const {file} = this.props;
    const {file: prevFile} = prevProps;
    if (file) {
      const fileChanged = prevFile && prevFile.name !== file.name;
      const isFirstFile = !prevFile;
      if (fileChanged || isFirstFile) {
        const tempAvatarUrl = this.generateTempAvatar();
        if (tempAvatarUrl) {
          this.setState({
            tempAvatarUrl,
            scale: 1
          });
        }
      }
    }
  }

  @autobind
  handleScale(e: SyntheticInputEvent<HTMLInputElement>) {
    const scale = parseFloat(e.target.value);
    this.setState({scale});
  }

  render(): Node {
    const {scale, tempAvatarUrl} = this.state;
    const {onClose, open} = this.props;
    const width = 250;
    return (
      <Modal dialogClassName="avatar-editor-modal" show={open} onHide={onClose} centered>
        <div className="editor-container">
          <ReactAvatarEditor
            ref={this.setEditorRef}
            image={tempAvatarUrl}
            className="editor"
            width={width}
            height={width}
            border={50}
            color={[127, 127, 127, 0.5]}
            scale={scale}
            borderRadius={width / 2}
          />
        </div>

        <div className="actions">
          <div className="zoom">
            <label>Zoom:</label>
            <input name="scale" type="range" onChange={this.handleScale} min="1" max="2" step="0.01" defaultValue="1" />
          </div>
          <Button onClick={this.onComplete}>OK</Button>
        </div>
      </Modal>
    );
  }
}
