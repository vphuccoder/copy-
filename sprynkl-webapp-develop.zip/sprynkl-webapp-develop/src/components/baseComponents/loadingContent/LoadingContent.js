import React, {PureComponent} from 'react';
import './LoadingContent.scss';

export default class LoadingContent extends PureComponent {
  render() {
    const {firstLineWidth, secondLineWidth} = this.props;
    return (
      <div className="animation-loading">
        <div className="loading-container">
          <div className="avatar" />
          <div className="line-one" style={{width: firstLineWidth}} />
          <div className="line-two" style={{width: secondLineWidth}} />
        </div>
      </div>
    );
  }
}
