// @flow

import React, {Component} from 'react';
import type {Node} from 'react';
import autobind from 'autobind-decorator';
import {withRouter} from 'react-router';
import type {RouterHistory} from 'react-router';
import {User} from '../../../models';
import './ProfileLink.scss';

type PropsType = {
  user: User,
  history: RouterHistory,
  children: ?Node
};

@withRouter
export default class ProfileLink extends Component<PropsType> {
  @autobind
  getProfileLink(id: string): string {
    return `/profile/${id}`;
  }

  @autobind
  onClick(event: SyntheticInputEvent<HTMLInputElement>, id: string) {
    event.preventDefault();
    event.stopPropagation();
    const {history, beforeSelectUser} = this.props;
    history.push(this.getProfileLink(id));
    if (beforeSelectUser) {
      beforeSelectUser();
    }
  }

  renderChild(): Node {
    const {user, children} = this.props;
    const {fullName} = user || {};
    if (children) {
      return children;
    } else {
      return <span className="name"> {fullName} </span>;
    }
  }

  render(): Node {
    const {user} = this.props;
    const {id} = user || {};
    return (
      <a
        className="profile-link"
        href={this.getProfileLink(id)}
        onClick={(event: SyntheticInputEvent<HTMLInputElement>) => {
          this.onClick(event, id);
        }}
      >
        {this.renderChild()}
      </a>
    );
  }
}
