// @flow

import ProfileLink from './ProfileLink';

export default ProfileLink;
