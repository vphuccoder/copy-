import React, {PureComponent} from 'react';
import './RoundCheckBox.scss';

export default class RoundCheckBox extends PureComponent {
  render() {
    const {checked, onChange, id} = this.props;
    return (
      <div className="round">
        <input type="checkbox" id={`checkbox-${id}`} checked={checked} onChange={onChange} />
        <label htmlFor={`checkbox-${id}`} />
      </div>
    );
  }
}
