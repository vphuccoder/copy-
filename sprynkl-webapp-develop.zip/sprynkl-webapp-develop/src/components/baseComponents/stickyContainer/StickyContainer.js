// @flow

import React, {Component} from 'react';
import ReactDOM from 'react-dom';
import autobind from 'autobind-decorator';
import './StickyContainer.scss';

type PropsType = {};

type StateType = {
  topPosition: number
};

const MARGIN_BOTTOM = 75;

class StickyContainer extends Component<PropsType, StateType> {
  containerRef: React.Ref = null;

  constructor(props: PropsType) {
    super(props);
    this.state = {
      topPosition: 0
    };
    this.containerRef = React.createRef();

    window.addEventListener('resize', this.onWindowResize);
  }

  componentDidMount() {
    this.updateTopPosition();
  }

  componentWillUnmount() {
    window.removeEventListener('resize', this.onWindowResize);
  }

  @autobind
  onWindowResize() {
    this.updateTopPosition();
  }

  updateTopPosition() {
    if (this.containerRef && this.containerRef.current) {
      const containerHeight = this.mesureHeightElement(this.containerRef.current);
      const windowHeight = window.innerHeight;
      let topPosition = MARGIN_BOTTOM;
      if (containerHeight >= windowHeight) {
        topPosition = windowHeight - containerHeight - MARGIN_BOTTOM;
      }
      this.setState({topPosition});
    }
  }

  mesureHeightElement(element: React.Ref): number {
    const DOMNode = ReactDOM.findDOMNode(element);
    return DOMNode.offsetHeight;
  }

  render(): Node {
    const {topPosition} = this.state;
    return (
      <div className="sticky-div-container" ref={this.containerRef} style={{top: topPosition}}>
        {this.props.children}
      </div>
    );
  }
}

export default StickyContainer;
