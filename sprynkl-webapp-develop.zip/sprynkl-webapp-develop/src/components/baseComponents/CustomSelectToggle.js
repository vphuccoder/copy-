// @flow
import React from 'react';
import autobind from 'autobind-decorator';

type PropType = {};

class CustomSelectToggle extends React.PureComponent {
  constructor(props: PropType) {
    super(props);
  }

  @autobind
  handleClick(e: React.EventHandler) {
    e.preventDefault();
    const {onClick, disabled} = this.props;
    if (onClick && !disabled) {
      onClick(e);
    }
  }

  render(): React.Node {
    return (
      <a className="toogle-link" onClick={this.handleClick}>
        <div className="dropdown-toggle">{this.props.children}</div>
      </a>
    );
  }
}

export default CustomSelectToggle;
