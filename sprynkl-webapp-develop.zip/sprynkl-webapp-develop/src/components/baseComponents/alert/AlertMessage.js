import React, {Component} from 'react';
import {Alert} from 'react-bootstrap';
import {observer} from 'mobx-react';
import {Transition} from 'react-transition-group';

@observer
class AlertMessage extends Component {
  render() {
    const {viewModel} = this.props;
    const {alert} = viewModel;
    const duration = 300;

    const defaultStyle = {
      transition: `opacity ${duration}ms ease-in-out, transform ${duration}ms`,
      opacity: 0,
      transform: 'translate(0, -50px)'
    };

    const enteredStyle = {
      opacity: 1,
      transform: 'translate(0, 0)',
      transition: `opacity ${duration}ms ease-in-out, transform ${duration}ms`
    };

    const transitionStyles = {
      entering: enteredStyle,
      entered: enteredStyle,
      exiting: defaultStyle,
      exited: defaultStyle
    };

    if (!alert.show) {
      return null;
    }
    return (
      <Transition in={alert.show} timeout={duration}>
        {(state) => (
          <Alert variant="success" style={{...defaultStyle, ...transitionStyles[state]}}>
            {alert.message}
          </Alert>
        )}
      </Transition>
    );
  }
}

export default AlertMessage;
