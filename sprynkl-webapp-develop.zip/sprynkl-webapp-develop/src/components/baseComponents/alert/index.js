import AlertMessage from './AlertMessage';
import {AlertMessageViewModel} from './AlertMessageViewModel';

export {AlertMessage, AlertMessageViewModel};
