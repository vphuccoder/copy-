// @flow

import {observable, action} from 'mobx';

class AlertMessageViewModel {
  @observable
  alert = {
    message: '',
    show: false
  };

  @action
  showProgressIndicator() {
    this.alert.showProgressIndicator = true;
  }

  @action
  hideProgressIndicator() {
    this.hideDialog();
  }

  @action
  showAlert(message: string, timeOut: number = 3000) {
    this.alert.message = message;
    this.alert.show = true;
    setTimeout(() => {
      this.hideAlert();
    }, timeOut);
  }

  @action
  hideAlert() {
    this.alert.show = false;
  }
}

export {AlertMessageViewModel};
