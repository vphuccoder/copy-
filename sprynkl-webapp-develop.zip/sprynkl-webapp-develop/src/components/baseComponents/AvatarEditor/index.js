import AvatarEditor from './AvatarEditor';

export default AvatarEditor;
