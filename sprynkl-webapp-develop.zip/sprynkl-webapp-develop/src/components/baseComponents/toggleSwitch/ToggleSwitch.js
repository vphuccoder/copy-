import React from 'react';
import autobind from 'autobind-decorator';
import './ToogleSwitch.scss';

class ToggleSwitch extends React.Component {
  @autobind
  onChange(e) {
    const {onChange} = this.props;
    if (onChange) {
      onChange(e.target.checked);
    }
  }

  render() {
    const {value = false} = this.props;
    return (
      <div className="toggle-switch">
        <label className="switch">
          <input type="checkbox" checked={value} onChange={this.onChange} />
          <span className="slider round" />
        </label>
      </div>
    );
  }
}

export default ToggleSwitch;
