import * as React from 'react';
import './BarChart.scss';
import {generateColorByIndex} from '../../../utils/color-generator';
import BarChartItem from './BarChartItem';
class BarChart extends React.Component {
  renderItem() {
    const {data = [], labelFormat, valueFormat} = this.props;
    return data.map((item, index) => {
      const color = generateColorByIndex(index);
      return (
        <BarChartItem
          key={index}
          item={item}
          color={color}
          labelFormat={labelFormat}
          valueFormat={valueFormat}
        />
      );
    });
  }
  render() {
    return (
      <div className="bar-chart">
        <div className="bar-chart-container">{this.renderItem()}</div>
      </div>
    );
  }
}

export default BarChart;
