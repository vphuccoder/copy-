import React from 'react';

class BarCharItem extends React.Component {
  renderLabel() {
    const {labelFormat, item} = this.props;
    if (labelFormat) {
      return labelFormat(item.label);
    }
    return item.label;
  }

  renderItem() {
    const {valueFormat, item} = this.props;
    if (valueFormat) {
      return valueFormat(item.value);
    }
    return item.value;
  }

  render() {
    const {item, color} = this.props;
    return (
      <div className="chart-item ">
        <div className="bar-container">
          <div className="bar" style={{backgroundColor: color, width: `${item.value}%`}} />
        </div>
        <div className="info">
          <span className="label">{this.renderLabel()} </span>
          <span className="value">{this.renderItem()} </span>
        </div>
      </div>
    );
  }
}

export default BarCharItem;
