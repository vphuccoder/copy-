import React from 'react';
import {Spinner} from 'react-bootstrap';

class Loading extends React.PureComponent {
  render() {
    return (
      <div className="loading loading-container">
        <div className="text-center">
          <Spinner animation="border" role="status" />
        </div>
      </div>
    );
  }
}

export default Loading;
