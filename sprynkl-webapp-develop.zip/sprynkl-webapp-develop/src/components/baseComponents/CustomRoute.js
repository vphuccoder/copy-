import React from 'react';
import {Route} from 'react-router-dom';
import GetStart from '../../pages/getStart/GetStart';
import {storageService} from '../../services';

function PrivateRoute({component: Component, ...rest}) {
  const refeshTokten = storageService.getRefreshToken();

  return <Route {...rest} render={(props) => (refeshTokten ? <Component {...props} /> : <GetStart />)} />;
}

function RemountingRoute({component: Component, ...rest}) {
  return (
    <Route
      {...rest}
      render={(p) => (
        <Component
          key={p.location.pathname + p.location.search}
          history={p.history}
          location={p.location}
          match={p.match}
        />
      )}
    />
  );
}

export {PrivateRoute, RemountingRoute};
