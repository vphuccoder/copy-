/**
 * @format
 * @flow
 */
import React, {Component} from 'react';

type PropsType = {
  offsetLeft: number,
  offsetTop: number,
  className: string
};

class DynamicPopover extends Component<PropsType> {
  render(): React.Node {
    const {offsetLeft, offsetTop, className, props} = this.props;
    const classNames = `popover ${className}`;
    return (
      <div
        {...props}
        className={classNames}
        style={{
          left: `${offsetLeft}px`,
          top: `${offsetTop}px`,
          ...this.props.style
        }}
      >
        <div className="popover-body">{this.props.children}</div>
      </div>
    );
  }
}

export default DynamicPopover;
