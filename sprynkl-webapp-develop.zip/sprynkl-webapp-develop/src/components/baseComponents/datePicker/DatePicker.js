import React, {Component} from 'react';
import DatePicker from 'react-datepicker';
import './DatePicker.scss';

export default class DateTimePicker extends Component {
  render() {
    const {props} = this;
    return (
      <div className="date-picker">
        <DatePicker {...props} />
      </div>
    );
  }
}
