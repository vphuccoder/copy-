import React from 'react';
import iconSet from '../../selection.json';
import IcomoonReact from 'icomoon-react';

export default class Icon extends React.PureComponent {
  render() {
    const {iconName, color, size} = this.props;

    return <IcomoonReact iconSet={iconSet} color={color} size={size || 32} icon={iconName} />;
  }
}
