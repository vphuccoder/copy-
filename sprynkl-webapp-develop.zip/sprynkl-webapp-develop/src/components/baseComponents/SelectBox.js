import * as React from 'react';
import Select from 'react-select';
export default class SelectBox extends React.Component {
  render() {
    return <Select {...this.props} />;
  }
}
