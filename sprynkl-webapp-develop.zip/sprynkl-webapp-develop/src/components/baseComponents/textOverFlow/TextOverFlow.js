import React from 'react';
import './TextOverFlow.scss';

class TextOverFlow extends React.PureComponent {
  renderText() {
    const {textOverflow, children, className, placement} = this.props;
    if (children) {
      return children;
    } else {
      return (
        <div className={`${className} text text-over-flow`} title={textOverflow}>
          {textOverflow}
        </div>
      );
    }
  }

  render() {
    const {className} = this.props;
    return <div className={`${className} text-over-flow`}>{this.renderText()}</div>;
  }
}

export default TextOverFlow;
