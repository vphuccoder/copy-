// @flow

import React from 'react';
import autobind from 'autobind-decorator';
import './SliderBar.scss';

type PropsType = {
  minValue: number,
  maxValue: number,
  currentValue: number,
  onValueChange: void,
  disabled: boolean
};

type StateType = {
  onReload: boolean,
  onSliding: boolean,
  slidePosition: number,
  slideValue: number
};

class SliderBar extends React.Component<PropsType, StateType> {
  constructor(props: PropsType) {
    super(props);
    this.state = {onReload: false, onSliding: false, slidePosition: 0, slideValue: 0};
  }

  containerElement: HTMLDivElement;

  dragableElement: HTMLDivElement;

  valueElementWidth: number = 32;

  bubleWidth: number = 60;

  componentWillUnmount() {
    this.dragableElement.removeEventListener('mousedown', this.onMouseDown);
    document.removeEventListener('mouseup', this.onMouseUp, true);
    document.removeEventListener('mousemove', this.onMouseMove, true);
  }

  getMargin(min: number, max: number, width: number): number {
    return width / (max - min);
  }

  calculateValue(position: number, width: number, min: number, max: number): number {
    const space = this.getMargin(min, max, width - this.valueElementWidth);
    const pos = position - this.valueElementWidth / 2;
    const floorNumber = Math.floor(pos / space);
    const restValue = pos - space * floorNumber;

    const shouldRoundTheValue = restValue > space / 2;

    let value = (shouldRoundTheValue === true ? floorNumber + 1 : floorNumber) + 1;
    value = value > max ? max : value;
    value = value < min ? min : value;
    return value;
  }

  @autobind
  onContainerRender(containerElement: HTMLDivElement) {
    if (!containerElement) {
      return;
    }

    this.containerElement = containerElement;
    this.setState({onReload: !this.state.onReload});
  }

  @autobind
  onDragableRender(dragableElement: HTMLDivElement) {
    if (!dragableElement) {
      return;
    }

    this.dragableElement = dragableElement;
    this.dragableElement.addEventListener('mousedown', this.onMouseDown);
  }

  @autobind
  renderCurrentValue(): React.Node {
    if (!this.containerElement) {
      return [];
    }
    const {offsetWidth: width} = this.containerElement;
    const {minValue, maxValue, currentValue} = this.props;
    const {onSliding} = this.state;

    const margin = this.getMargin(minValue, maxValue, width - this.valueElementWidth);
    let marginStyle = {left: margin * (currentValue - minValue)};
    if (onSliding === false) {
      return (
        <div className="current-value" style={marginStyle}>
          {currentValue}
        </div>
      );
    }
    const {slidePosition, slideValue} = this.state;
    const border = this.valueElementWidth / 2;
    let left = slidePosition ? slidePosition - this.bubleWidth / 2 : border;
    left = left < border ? border : left;
    const right = width - this.bubleWidth - border;
    left = left > right ? right : left;
    marginStyle = {left};
    return (
      <div className="current-value-sliding-container" style={marginStyle}>
        {this.renderBubble()}
        <div className="current-value-sliding">{slideValue || 1}</div>
      </div>
    );
  }

  @autobind
  renderValueBar(): React.Node {
    if (this.props.disabled === true || !this.containerElement) {
      return null;
    }
    const {offsetWidth: width} = this.containerElement;
    const {minValue, maxValue, currentValue} = this.props;

    const margin = this.getMargin(minValue, maxValue, width - this.valueElementWidth);
    const {onSliding, slidePosition} = this.state;

    const widthStyle = {
      width: onSliding === true ? slidePosition : margin * (currentValue - minValue) + this.valueElementWidth / 2
    };

    return (
      <div className="value-bar-container">
        <div className="value-bar" style={widthStyle} />
      </div>
    );
  }

  @autobind
  renderNumber(): React.Node[] {
    if (!this.containerElement) {
      return [];
    }
    const {minValue, maxValue, currentValue} = this.props;
    const {onSliding, slideValue} = this.state;

    const {offsetWidth: width} = this.containerElement;
    const result: React.Node[] = [];

    const value = onSliding === true ? slideValue : currentValue;

    const margin = this.getMargin(minValue, maxValue, width - this.valueElementWidth);
    for (let i = minValue; i <= maxValue; i += 1) {
      if (i !== value) {
        const valueStyle = {left: margin * (i - minValue)};
        if (i <= value) {
          valueStyle.color = 'white';
        }
        result.push(
          <div className="slider-number" style={valueStyle} key={`number${i}`}>
            {i}
          </div>
        );
      }
    }
    return result;
  }

  @autobind
  renderBubble(): React.Node {
    return (
      <div className="value-bubble">
        <svg xmlns="http://www.w3.org/2000/Svg" width="60" height="56" viewBox="0 0 60 56">
          <path
            fill="#FFFFFF"
            d="M0,56c5.6-0.6,9.2-1.6,10.7-3c1.7-1.5,3-4.2,0.5-8.2c-0.2-0.3-0.4-0.6-0.7-1C7.1,39.4,5,33.9,5,28C5,14.2,16.2,3,30,3s25,11.2,25,25c0,5.8-1.9,11.1-5.2,15.3l-0.2,0.3c-0.3,0.4-0.6,0.8-0.8,1.1c-2.5,4-1.1,6.7,0.5,8.2c1.5,1.4,5.1,2.4,10.6,3"
          />
          <path
            fill="#EAECED"
            d="M0,56.3L0,55.8c5.5-0.6,9.1-1.6,10.6-3c1.6-1.5,2.9-4,0.5-7.9c-0.2-0.3-0.4-0.6-0.7-1C6.7,39.4,4.8,33.8,4.8,28C4.8,14.1,16.1,2.8,30,2.8S55.2,14.1,55.2,28c0,5.6-1.8,11-5.3,15.4l-0.2,0.3c-0.4,0.5-0.6,0.8-0.8,1.1c-2.5,3.9-1.1,6.5,0.5,7.9c1.5,1.4,5,2.4,10.5,3l-0.1,0.5c-5.6-0.6-9.1-1.6-10.7-3.1c-1.4-1.3-3.3-4.1-0.6-8.6c0.2-0.3,0.5-0.7,0.8-1.1l0.2-0.3c3.4-4.4,5.2-9.6,5.2-15.1C54.8,14.4,43.6,3.2,30,3.2C16.4,3.2,5.2,14.4,5.2,28c0,5.6,1.9,11.2,5.5,15.5c0.3,0.4,0.6,0.8,0.8,1.1c2.8,4.4,0.8,7.3-0.6,8.6C9.3,54.7,5.7,55.7,0,56.3z"
          />
        </svg>
      </div>
    );
  }

  @autobind
  onMouseDown(evt: MouseEvent) {
    if (this.props.disabled === true) {
      return;
    }

    const {offsetX} = evt;
    const {offsetWidth: width} = this.containerElement;
    const {minValue, maxValue} = this.props;

    const slideValue = this.calculateValue(offsetX, width - this.valueElementWidth, minValue, maxValue);
    this.setState({slidePosition: offsetX, onSliding: true, slideValue});
    document.addEventListener('mouseup', this.onMouseUp, true);
    document.addEventListener('mousemove', this.onMouseMove, true);
    evt.preventDefault();
    evt.stopPropagation();
  }

  @autobind
  onMouseMove(evt: MouseEvent) {
    const leftButtonNumber = 0;
    if (this.props.disabled === true || !this.state.onSliding || evt.button !== leftButtonNumber) {
      return;
    }

    const rect = this.dragableElement.getBoundingClientRect();
    const offsetX = evt.clientX - rect.left;

    const {offsetWidth: width} = this.containerElement;
    let postition = offsetX > width ? width : offsetX;
    postition = postition < 0 ? 0 : postition;
    const {minValue, maxValue} = this.props;

    const slideValue = this.calculateValue(offsetX, width, minValue, maxValue);
    this.setState({slidePosition: postition, slideValue});
    evt.preventDefault();
    evt.stopPropagation();
  }

  @autobind
  onMouseUp(evt: MouseEvent) {
    if (this.props.disabled === true || !this.state.onSliding) {
      return;
    }

    document.removeEventListener('mouseup', this.onMouseUp, true);
    document.removeEventListener('mousemove', this.onMouseMove, true);
    evt.preventDefault();
    evt.stopPropagation();

    this.setState({onSliding: false});
    const {onValueChange} = this.props;
    const {slideValue} = this.state;

    if (onValueChange) {
      onValueChange(slideValue);
    }

    // notify value change
    this.setState({slidePosition: 0, onSliding: false, slideValue: 0});
    this.lastPoint = null;
  }

  render() {
    const {minValue, maxValue, currentValue} = this.props;
    return (
      <div className="slider-bar">
        <div className="slider-bar-container" ref={this.onContainerRender}>
          <div className="slider-bar-border" />
          {this.renderValueBar()}
          {this.renderCurrentValue()}
          <div className="number-container">{this.renderNumber()}</div>
          <div className="dragable-container" ref={this.onDragableRender} />
        </div>
      </div>
    );
  }
}

export default SliderBar;
