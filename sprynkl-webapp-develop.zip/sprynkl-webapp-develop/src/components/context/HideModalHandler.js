// @flow
import * as React from 'react';
import {withRouter} from 'react-router';

type PropsType = {
  hideModal: void
};

class HideModalHandler extends React.PureComponent<PropsType> {
  componentDidMount() {
    this.unlisten = this.props.history.listen((location, action) => {
      if (action === 'POP') {
        const {hideModal} = this.props;
        if (hideModal) {
          hideModal();
        }
      }
    });
  }

  componentWillUnmount() {
    this.unlisten();
  }

  render() {
    return null;
  }
}

export default withRouter(HideModalHandler);
