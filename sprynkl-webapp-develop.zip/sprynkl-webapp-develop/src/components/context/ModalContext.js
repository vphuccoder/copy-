// @flow
import React, {Component, createContext} from 'react';
import autobind from 'autobind-decorator';

export const ModalContext = createContext({
  component: null,
  props: {},
  showModal: () => {},
  hideModal: () => {}
});

export class ModalProvider extends Component {
  state = {
    component: null,
    props: {},
    showModal: this.showModal,
    hideModal: this.hideModal
  };

  @autobind
  showModal(component: React.Node, props: {} = {}) {
    this.setState({
      component,
      props: {...props, baseHideModal: this.hideModal}
    });
  }

  @autobind
  hideModal() {
    this.setState({
      component: null,
      props: {}
    });
  }

  render(): React.Node {
    return <ModalContext.Provider value={this.state}>{this.props.children}</ModalContext.Provider>;
  }
}

export const ModalConsumer = ModalContext.Consumer;
