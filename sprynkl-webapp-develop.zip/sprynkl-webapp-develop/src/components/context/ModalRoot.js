// @flow
import React from 'react';
import {Modal} from 'react-bootstrap';
import autobind from 'autobind-decorator';
import {ModalConsumer} from './ModalContext';
import HideModalHandler from './HideModalHandler';

type PropsType = {
  Component: React.Node,
  props: {},
  hideModal: () => mixed
};

class ModalRoot extends React.PureComponent<PropsType> {
  @autobind
  renderModal({component: Component, props}: PropsType): React.Node {
    if (Component) {
      return (
        <Modal dialogClassName={props.dialogClassName} show animation onHide={props.hideModal}>
          <HideModalHandler hideModal={props.baseHideModal} />
          <Modal.Header>
            <Modal.Title>{props.header}</Modal.Title>
          </Modal.Header>
          <Modal.Body>
            <Component {...props} />
          </Modal.Body>
        </Modal>
      );
    }
    return null;
  }
  render(): React.Node {
    return <ModalConsumer>{this.renderModal}</ModalConsumer>;
  }
}

export default ModalRoot;
