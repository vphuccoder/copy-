// @flow

export type CodeType = {
  num1: string,
  num2: string,
  num3: string,
  num4: string,
  num5: string,
  num6: string
};
