export class ApplicationInfos {
  serverTimestamp;

  maximumClap;

  appVersions = [];

  static map(data) {
    const appInfos = new ApplicationInfos();
    appInfos.serverTimestamp = data.serverTimestamp;
    appInfos.maximumClap = data.maximumClap;
    appInfos.appVersions = data.appVersions;
    return appInfos;
  }
}
