// @flow
import {PostModel} from './post-model';

export class FeedModel {
  posts: PostModel[];

  static map(data: {}): FeedModel {
    const post = new FeedModel();
    post.posts = [];
    if (data && data.length > 0) {
      post.posts = data.map((content: {}): PostModel => PostModel.map(content));
    }
    return post;
  }
}
