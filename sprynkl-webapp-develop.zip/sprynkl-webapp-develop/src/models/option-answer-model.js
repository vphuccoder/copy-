// @flow
export class OptionAnswer {
  label: string;

  value: string;

  static map(data: {label: string, value: string}): OptionAnswer {
    const option = new OptionAnswer();
    option.label = data.label;
    option.value = data.value;
    return option;
  }
}
