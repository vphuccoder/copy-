// @flow

export class InstantMessage {
  skype: string;

  static map(data: {}): InstantMessage {
    const instantMessage = new InstantMessage();
    if (data) {
      instantMessage.skype = data.skype;
    }
    return instantMessage;
  }
}
