// @flow

export class Office {
  name: string;

  static map(data: {}): Office {
    const office = new Office();
    if (data) {
      office.name = data.name;
    }
    return office;
  }
}
