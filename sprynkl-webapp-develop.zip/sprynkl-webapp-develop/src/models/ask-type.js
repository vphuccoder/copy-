export const AskType = {
  OPEN: 'open',
  POLL: 'poll',
  SCALE: 'scale'
};
