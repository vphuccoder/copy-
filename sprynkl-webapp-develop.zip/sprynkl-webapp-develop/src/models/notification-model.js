/**
 * @flow
 */

import {timeStampToDateString} from '../utils/string';
import {User} from './user-model';
import {Group, PostModel, Comment} from './index';

export const NOTIFICATION_TYPE = {
  reportPost: 'reportPost',
  postClap: 'postClap',
  postComment: 'postComment',
  newPost: 'newPost',
  tagInPost: 'tagInPost',
  sendPostTo: 'sendPostTo',
  reportComment: 'reportComment',
  responseAsk: 'responseAsk',
  tagInComment: 'tagInComment',
  assignLead: 'assignLead',
  unassignLead: 'unassignLead',
  removeUser: 'removeUser',
  inviteUser: 'inviteUser',
  assignOwner: 'assignOwner',
  deletePost: 'deletePost'
};

export class Notification {
  id: string;

  type: string;

  user: User;

  fromUser: User;

  post: PostModel;

  group: Group;

  groupMembers: [];

  description: string;

  seen: boolean;

  createdDate: string;

  modifiedDate: string;

  read: boolean;

  reportComment: Comment;

  setSeen() {
    this.seen = true;
  }

  static map(data: {}): Notification {
    const notification = new Notification();
    notification.id = data.id;
    notification.type = data.type;
    if (data.user) {
      notification.user = User.map(data.user);
    }
    if (data.meta) {
      notification.fromUser = User.map(data.meta.fromUser);
      notification.post = PostModel.map(data.meta.post);
      notification.group = Group.map(data.meta.group);
      notification.description = data.meta.description;
      notification.groupMembers = data.meta.group.members.slice();

      if (data.meta.reportComment) {
        notification.reportComment = Comment.map(data.meta.reportComment);
      }
    }
    notification.seen = data.seen;
    notification.read = data.read;
    notification.createdDate = timeStampToDateString(data.createdDate);
    notification.modifiedDate = timeStampToDateString(data.modifiedDate);
    return notification;
  }
}
