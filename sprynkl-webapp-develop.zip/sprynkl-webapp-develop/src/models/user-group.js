// @flow
import {Group} from './group-model';
import {User} from './user-model';
import {LeadRoles, GroupRoles} from './group-roles';

export class UserGroup {
  group: Group;

  invitedBy: User;

  role: string;

  static map(data: {}): UserGroup {
    const result = new UserGroup();
    result.group = Group.map(data);
    result.role = data.role;
    if (data.invitedBy) {
      result.invitedBy = User.map(data.invitedBy);
    }

    return result;
  }

  isLeader(): boolean {
    return LeadRoles.indexOf(this.role) >= 0;
  }

  isOwner(): boolean {
    return this.role === GroupRoles.OWNER;
  }
}
