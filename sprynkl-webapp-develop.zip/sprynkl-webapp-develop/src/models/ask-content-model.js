// @flow

import {AskType, ScaleRank, OptionAnswer, Answer} from '.';

export class AskContent {
  rank: ScaleRank;

  type: AskType;

  anonymousAnswer: boolean;

  privateResults: boolean;

  options: OptionAnswer;

  answers: Array<Answer>;

  expiredDate: number;

  totalAnswers: number;

  static map(data: {}): AskContent {
    const askContent = new AskContent();
    if (data.rank) {
      askContent.rank = ScaleRank.map(data.rank);
    }
    askContent.type = data.type;
    askContent.anonymousAnswer = data.anonymousAnswer;
    askContent.privateResults = data.privateResults;
    askContent.options = [];
    if (data.options) {
      askContent.options = data.options.map((option: {}): OptionAnswer => OptionAnswer.map(option));
    }

    askContent.answers = [];
    if (data.answers) {
      askContent.answers = data.answers.map((answer: {}): Answer => Answer.map(answer));
      askContent.totalAnswers = askContent.answers.length;
    }

    if (data.expiredDate) {
      askContent.expiredDate = data.expiredDate;
    }

    if (data.totalAnswers) {
      askContent.totalAnswers = data.totalAnswers;
    }
    return askContent;
  }
}
