// @flow

import {GroupUser} from './group-user';
import {GroupRoles} from './group-roles';

export class Group {
  id: string = '';

  name: string = '';

  description: string = '';

  avatar: string = '';

  defaultAvatar: string = '';

  members: GroupUser[] = [];

  role: string = '';

  totalMembers: number = 0;

  getLeaders(): GroupUser[] {
    return this.members.filter(
      (member: GroupUser): boolean => member.role === GroupRoles.OWNER || member.role === GroupRoles.ADMIN
    );
  }

  getMembers(): GroupUser[] {
    return this.members.filter(
      (member: GroupUser): boolean => member.role !== GroupRoles.OWNER && member.role !== GroupRoles.ADMIN
    );
  }

  isLeader(userId: string): boolean {
    return (
      this.members.filter(
        (member: GroupUser): boolean => {
          const result =
            member.user.id === userId && (member.role === GroupRoles.OWNER || member.role === GroupRoles.ADMIN);
          return result;
        }
      ).length > 0
    );
  }

  isOwner(userId: string): boolean {
    return (
      this.members.filter(
        (member: GroupUser): boolean => {
          const result = member.user.id === userId && member.role === GroupRoles.OWNER;
          return result;
        }
      ).length > 0
    );
  }

  getTotalMembers(): number {
    if (this.members && this.members.length > 0) {
      const activeMembers = this.members.filter(
        (member: GroupUser): boolean => {
          const result =
            member.role === GroupRoles.ADMIN || member.role === GroupRoles.MEMBER || member.role === GroupRoles.OWNER;
          return result;
        }
      );
      return activeMembers.length;
    }

    return 0;
  }

  static map(data: {}): Group {
    const group = new Group();
    group.id = data.id;
    group.name = data.name;
    group.avatar = data.avatar;
    group.defaultAvatar = data.defaultAvatar;
    group.description = data.description;

    group.members = [];
    if (data.members && data.members.length > 0) {
      data.members.forEach((groupUserData: {}) => {
        group.members.push(GroupUser.map(groupUserData));
      }, this);
    }
    group.totalMembers = group.members && group.members.length > 0 ? group.getTotalMembers() : data.totalMembers || 0;
    return group;
  }

  removeUser(userId: string) {
    let index = -1;
    const member = this.members.filter(
      (m: GroupUser, i: number): boolean => {
        index = i;
        return m.user.id === userId;
      }
    );

    if (member.length > 0) {
      this.members.splice(index, 1);
    }
  }
}
