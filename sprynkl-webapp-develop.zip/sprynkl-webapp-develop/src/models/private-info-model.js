// @flow

import {upperFirstChar} from '../utils/string';

export class PrivateInfo {
  gender: string;

  birthday: number;

  isEmptyInfo: boolean;

  static map(data: {}): PrivateInfo {
    const privateInfo = new PrivateInfo();
    let {gender} = data;
    if (gender && gender.toLowerCase() === 'other') {
      gender = '';
    }
    privateInfo.gender = upperFirstChar(gender);
    privateInfo.birthday = data.birthday || null;

    privateInfo.isEmptyInfo = privateInfo.isEmpty();
    return privateInfo;
  }

  isEmpty(): boolean {
    if (!this.gender && !this.birthday) {
      return true;
    }
    return false;
  }
}
