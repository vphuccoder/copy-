export const CREATE_VOICE = 'createVoice';
export const CREATE_THANKS = 'createThanks';
export const UPDATE_PROFILE = 'updateProfile';
export const INVITE = 'invite';
