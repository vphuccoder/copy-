export const PRODUCTION = 'production';
export const DEVELOPMENT = 'development';
export const TEST = 'test';
