// @flow
import {observable} from 'mobx';
import {Group, Clap, Comment, User, AskContent} from '.';
import {timeStampToDateString} from '../utils/string';

export const VOICE = 'voice';
export const THANKS = 'thanks';
export const ASK = 'ask';

export class PostModel {
  id: string;

  author: User;

  type: string;

  sendTo: User[];

  tags: User[];

  claps: Clap[];

  anonymous: boolean;

  content: string;

  textContent: string;

  textColor: string;

  backgroundColor: string;

  images: [];

  createdDate: number;

  modifiedDate: number;

  group: Group;

  @observable
  comments: Comment[];

  askContent: AskContent;

  getAuthorName(): string {
    let author = 'Someone';
    if (this.author !== undefined) {
      author = this.author.fullName;
    }

    return author;
  }

  setGroup(group: Group) {
    this.group = group;
  }

  static map(data: {}): PostModel {
    const post = new PostModel();
    post.id = data.id;
    post.type = data.type;
    post.anonymous = data.anonymous;
    post.content = data.content;
    post.textContent = data.textContent ? data.textContent : data.content;
    post.textColor = data.textColor;
    post.backgoundColor = data.backgoundColor;
    post.images = data.images;
    post.createdDate = timeStampToDateString(data.createdDate);
    post.modifiedDate = timeStampToDateString(data.modifiedDate);
    post.sendTo = [];
    post.tags = [];
    post.claps = [];
    post.comments = [];

    if (data.askContent) {
      post.askContent = AskContent.map(data.askContent);
    }
    if (data.author) {
      post.author = User.map(data.author);
    }
    if (data.sendTo && data.sendTo.length > 0) {
      post.sendTo = data.sendTo.map((user: {}): User => User.map(user));
    }
    if (data.tags && data.tags.length > 0) {
      post.tags = data.tags.map((user: {}): User => User.map(user));
    }
    if (data.claps && data.claps.length > 0) {
      post.claps = data.claps.map((clap: {}): Clap => Clap.map(clap));
    }
    if (data.group !== undefined) {
      post.group = Group.map(data.group);
    }
    if (data.comments && data.comments.length > 0) {
      post.comments = data.comments.map((comment: {}): Comment => Comment.map(comment));
    }

    return post;
  }
}
