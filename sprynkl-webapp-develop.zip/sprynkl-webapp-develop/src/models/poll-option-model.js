// @flow

export class PollOptionModel {
  value: string = '';

  label: string = '';

  static map(data: {}): PollOptionModel {
    if (!data) {
      return null;
    }
    const option = new PollOptionModel();
    option.value = data.value;
    option.label = data.label;

    return option;
  }
}
