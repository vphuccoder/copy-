// @flow

class AppConfig {
  API_URL: string = '';

  populateData(data) {
    this.API_URL = data.api;
  }

  static map(data: {}): AppConfig {
    const config = new AppConfig();
    config.API_URL = data.api;
    return config;
  }
}

const appConfig = new AppConfig();
export {appConfig};
