export const ALLOW_GO_TO_POST_DETAIL_NOTIFICATION = [
  'tagInComment',
  'responseAsk',
  'reportComment',
  'sendPostTo',
  'tagInPost',
  'newPost',
  'reportPost',
  'postClap',
  'postComment'
];
