export const USER_API_URL = {
  oauth: '/api/oauth',
  base: '/api/user',
  google: '/api/user/google',
  resendPin: '/api/user/resend',
  checkEmail: '/api/user/email',
  generatePin: '/api/user/generate-pin',
  checkPin: '/api/user/check-pin',
  skipAction: '/api/user/skip-action',
  leaveGroup: '/api/user/leave-group',
  confirmGroup: '/api/user/confirm-group',
  changePassword: '/api/user/change-password',
  forgetPassword: '/api/user/forget-password',
  resetPassword: '/api/user/reset-password',
  getAllTeam: '/api/user/team',
  logOut: '/api/user/log-out',
  sendFeedback: '/api/user/send-feedback',
  getUserSetting: '/api/user/user-setting',
  signUp: '/api/user/signup',
  resendVerifyEmail: '/api/user/resendEmail',
  verifyAccount: '/api/user/validateUser',
  removeSearchTerm: '/api/user/remove-user-search-term'
};

export const GROUP_API_URL = {
  base: '/api/group',
  block: '/api/group/block-user',
  remove: '/api/group/remove-user',
  invite: '/api/group/invite',
  leaderBoard: '/api/group/leader-board/',
  assignRole: '/api/group/assign-role',
  assignOwner: '/api/group/assign-owner',
  emailDomain: '/api/group/email-domain'
};

export const APP_API_URL = {
  base: '/app'
};

export const POST_API_URL = {
  base: '/api/post',
  comment: '/api/post/comment',
  reportPost: '/api/post/report',
  clap: '/api/post/clap',
  reportComment: '/api/post/comment/report',
  getUserFeed: '/api/user/feed',
  getAllFeed: '/api/post/feed',
  getGroupFeed: '/api/group/feed/',
  responseAsk: '/api/post/response-ask',
  filterFeed: '/api/post/filter'
};

export const NOTIFICATION_API_URL = {
  base: '/api/notification',
  seen: '/api/notification/seen',
  read: '/api/notification/read',
  deletePatch: '/api/notification/deletePatch',
  checkNotSeen: '/api/notification/check-not-seen'
};

export const FILE_API_URL = {
  base: '/api/file'
};
