// @flow
export const user_existing = 'user_existing';
export const similar_currentpassword = 'similar_currentpassword';
export const password_incorrect = 'incorrect_currentpassword';
