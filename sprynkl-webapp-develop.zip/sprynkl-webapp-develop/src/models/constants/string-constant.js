export const INVALID_EMAIL_FORMAT = 'The email you entered is wrong format.';
export const INVALID_FULL_NAME_FORMAT = "'Full name' field is 1-256 characters, no icon, no special characters.";
export const EMAIL_DOES_NOT_EXIST = 'No account found for this email.';
export const PASSWORD_INVALID = 'The password you entered is incorrect.';
export const HOME_TEXT = 'We’re dedicated to building better teams';
export const DONT_HAVE_ACCOUNT = "Don't have an account?";
export const LOGIN_DESCRIPTION = 'Read our original team culture resources';
export const CREATE_NEW_ACCOUNT = 'Create an account';
export const EMAIL_EXISTED = 'Account email already existed.';

export const NO_MEMBER_MESSAGE = "No one's in the team yet. Invite your teammates before you send your message.";

export const OPEN_QUESTION_PLACEHOLDER =
  'Tip: Start your question with What, How or Why to elicit detailed responses from your team.';
export const POLL_QUESTION_PLACEHOLDER =
  'Tip: Ask 1 question and make sure there’s an answer option for every situation.';
export const POLL_OPTIONS_PLACEHOLDER = 'Option';
export const SCALE_QUESTION_PLACEHOLDER = 'Tip: Pose an agree/disagree statement to get specific feedback.';

export const INVALID_EMAIL_DOMAIN_NAME = 'Sorry, you are not allowed to invite people from "${domain}"';

export const OPEN_ANSWER_PLACEHOLDER = 'Answer here...';

//  NOTIFICATION
export const NOTIFICATION_EMPTY_STATE = 'You don’t have any notifications, yet!';

export const CLOSE_QUESTION_IN_DAY = 'Closes soon';
export const CLOSE_QUESTION_IN_FOOTER = 'Closes in';
export const CLOSE_QUESTION_IN_EXPIRED = 'Already expired';
export const ANSWER_REASON_PLACEHOLDER = 'Tell your team why you picked this answer';

// TOOLTIP FEED
export const ANONYMOUS_TRUE_TOOLTIP = 'Just the poster sees the answers';
export const ANONYMOUS_FALSE_TOOLTIP = 'Everybody sees each others’ answers';
export const PRIVATE_RESULT_TOOLTIP = 'Answers are anonymous';
export const PUBLISH_RESULT_TOOLTIP = 'Names appear above answers';

// LEADER BOARD
export const LEADER_BOARD_ALL_TEAM_TITLE = 'Select team';
export const LEADER_BOARD_ALL_TEAM_DESCRIPTION = 'Select a team to see their Karma leaders';
export const KARMA_LEADERBOARD = 'KARMA LEADERBOARD';
export const order1st = '#fc4167';
export const order2nd = '#f0a106';
export const order3rd = '#06dba1';
export const orderMore = '#b2b4b5';
export const LEADER_BOARD_EMPTY_STATE_TITLE = 'Lead Your Team';
export const LEADER_BOARD_EMPTY_STATE_DESCRIPTION =
  'Ask for or give feedback to claim the top spot, before someone else does.';

// Setting
export const UPDATE_PROFILE_SUCCESSFULLY = 'Your profile has been update successfully.';
export const UPDATE_PASSWORD_SUCCESSFULLY = 'Your password has been update successfully.';

export const INVALID_PASSWORD_FORMAT = 'Your password must be at least 6 characters, 1 letter, 1 number required.';
export const PASSWORD_NOT_MATCH = "The new password you entered didn't match. Please enter again.";
export const INCORRECT_PASSWORD = 'The password you entered is incorrect. Please try again.';
export const CAN_NOT_USE_OLD_PASSWORD = 'You cannot use the old password. Please try again.';

// FEED
export const FEED_EMPTY_STATE_TITLE = 'This is your team feed';
export const FEED_EMPTY_STATE_DESCRIPTION = 'Your team will engage with each other here.';
export const USER_FEED_EMPTY_STATE_TITLE = 'Oops, no post yet!';
export const USER_FEED_EMPTY_STATE_DESCRIPTION = 'Your own posts will show up here';

// INPUT TEAM NAME
export const INPUT_TEAM_NAME_TITLE = 'Create a team';
export const INPUT_TEAM_NAME_TITLE_DESCRIPTION =
  'This should be fun. Speak openly, thank often. We think you’ll like what happens.';
export const INPUT_TEAM_NAME_FOOTER_TITLE = 'Were you expecting to find a team here?';
export const INPUT_TEAM_NAME_FOOTER_MESSAGE =
  "We couldn't find any teams for your email address, so ask your team leader for an invite.";
export const INPUT_TEAM_NAME_SIGN_IN_ANOTHER_EMAIL = 'Sign in with another email address';
export const INPUT_TEAM_NAME_ERROR_MESS = 'Your team name should be at least 3 characters. Please try again';

export const FULLNAME_INVALID =
  'Your full name can’t be empty or include icons and special characters. Please try again';
export const PHONE_NUMBER_INVALID = 'Your phone number is invalid. Please try again.';

// PAGE NOT FOUND
export const PAGE_NOT_FOUND = "We can't find the page that you're looking for.";

// PAGE FORBIDDEN
export const PAGE_FORBIDDEN = "Sorry, but you don't have permission to access this page";

// Create Post
export const DISCARD_ALERT_MESSAGE = 'Are you sure to discard';

// Post Comment
export const POST_COMMENT_WARNING = 'Are you sure you want to permanently remove this comment from';

export const INVALID_SEARCH_URL = "Sorry, we couldn't understand this search. Please try saying this another way.";
export const NO_RESULT_FOUND = 'No results found for ';
