export const SENT = 'sent';
export const RECEIVED = 'received';
