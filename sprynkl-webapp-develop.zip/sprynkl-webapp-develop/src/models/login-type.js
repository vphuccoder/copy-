export const BUILD_IN = 'build-in';
export const GOOGLE = 'google';

export const USER_TYPES = [BUILD_IN, GOOGLE];
