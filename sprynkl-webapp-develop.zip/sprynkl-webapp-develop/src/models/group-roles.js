export const GroupRoles = {
  MEMBER: 'member',
  OWNER: 'owner',
  INVITED: 'invited',
  ADMIN: 'admin'
};

export const LeadRoles = [GroupRoles.ADMIN, GroupRoles.OWNER];
