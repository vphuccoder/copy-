// @flow
import {User} from './user-model';
import {GroupRoles} from './group-roles';

export class GroupUser {
  user: User;

  invitedBy: User;

  role: string;

  isLeader(): boolean {
    return this.role === GroupRoles.ADMIN;
  }

  isOwner(): boolean {
    return this.role === GroupRoles.OWNER;
  }

  static map(data: {}): GroupUser {
    const result = new GroupUser();
    result.user = User.map(data);
    if (data.invitedBy) {
      result.invitedBy = User.map(data.invitedBy);
    }

    result.role = data.role;

    return result;
  }
}
