/**
 * @flow
 * @format
 */

export class ScaleRank {
  from: number;

  fromLabel: string;

  to: number;

  toLabel: string;

  static map(data: {}): ScaleRank {
    if (!data) {
      return null;
    }
    const rank = new ScaleRank();
    rank.from = data.from;
    rank.to = data.to;
    rank.fromLabel = data.fromLabel;
    rank.toLabel = data.toLabel;
    return rank;
  }
}
