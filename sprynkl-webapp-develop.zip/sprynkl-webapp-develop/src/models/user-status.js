export const NEW = 'new';
export const INVITED = 'invited';
export const RE_PIN = 're-pin';
export const ACTIVE = 'active';
export const BLOCK = 'block';

export const USER_STATUS = [NEW, INVITED, RE_PIN, ACTIVE, BLOCK];
