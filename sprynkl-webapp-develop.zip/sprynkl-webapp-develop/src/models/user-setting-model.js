// @flow

export class UserSettingModel {
  userId: string;

  searchTerms: Array<string>;

  static map(data: {} = {}): UserSettingModel {
    const userSetting = new UserSettingModel();
    userSetting.userId = data.userId;
    userSetting.searchTerms = data.searchTerms || [];

    return userSetting;
  }
}
