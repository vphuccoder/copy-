// @flow

import {User} from './user-model';
import {timeStampToDateString} from '../utils/string';

export class Comment {
  id: string;

  author: User;

  content: string;

  textContent: string;

  createdDate: number;

  modifiedDate: number;

  createdDateString: string;

  getCreatedDateString(): string {
    if (!this.createdDateString) {
      this.createdDateString = timeStampToDateString(this.createdDate);
    }

    return this.createdDateString;
  }

  static map(data: {}): Comment {
    const comment = new Comment();
    comment.id = data.id;
    comment.content = data.content;
    comment.textContent = data.textContent || data.content;
    comment.createdDate = data.createdDate;
    comment.modifiedDate = data.modifiedDate;

    if (data.author) {
      comment.author = User.map(data.author);
    }
    return comment;
  }
}
