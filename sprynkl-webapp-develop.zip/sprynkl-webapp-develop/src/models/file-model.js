export class File {
  id = '';

  fileName = '';

  url = '';

  static map(data) {
    const file = new File();
    file.id = data.id;
    file.fileName = data.fileName;
    file.url = data.url;

    return file;
  }
}
