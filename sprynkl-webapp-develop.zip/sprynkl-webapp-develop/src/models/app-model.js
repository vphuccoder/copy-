// @flow

import {observable, action} from 'mobx';
import {User, Token, Group} from '.';
import {storageService, uuidService} from '../services';
import {DialogViewModel} from '../components/modals';
import {AlertMessageViewModel} from '../components/baseComponents/alert';

class AppModel {
  constructor() {
    const deviceId = storageService.getUUID();
    if (!deviceId) {
      const newDeviceId = uuidService.getUUID();
      this.deviceId = newDeviceId;
      storageService.setUUID(newDeviceId);
    } else {
      this.deviceId = deviceId;
    }
  }

  @observable
  currentUser: User;

  @observable
  currentToken: Token;

  @observable
  currentGroup: Group;

  @observable
  dialogViewModel: DialogViewModel;

  @observable
  alertMessageViewModel: AlertMessageViewModel;

  @observable
  hasNotSeenNotification: boolean = false;

  notificationPermission: boolean = false;

  deviceId: string = '';

  fcmToken: string = '';

  loginRedirect: string = '/';

  @action
  setCurrentUser(user: User) {
    if (user && user.id) {
      // usageTrackingService.setUserId(user.id);
    }
    this.currentUser = user;
  }

  @action
  setCurrentToken(token: Token) {
    this.currentToken = token;
    storageService.setToken(token);
  }

  @action
  setCurrentGroup(group: Group) {
    this.currentGroup = group;
  }

  async checkLogdedIn(): Promise {}
}

const appModel = new AppModel();
export {appModel};
