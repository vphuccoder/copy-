// @flow

export class CTAModel {
  id: '';

  description: '';

  textColor: '';

  backgroundColor: '';

  action: '';

  actionFor: '';

  completed: false;

  static map(data: {}): CTAModel {
    const cta = new CTAModel();
    cta.id = data.id;
    cta.description = data.description;
    cta.textColor = data.textColor;
    cta.backgroundColor = data.backgroundColor;
    cta.action = data.action;
    cta.actionFor = data.actionFor;
    cta.completed = data.completed;
    return cta;
  }
}
