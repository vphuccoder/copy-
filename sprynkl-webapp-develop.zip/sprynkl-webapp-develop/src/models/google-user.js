// @flow
export class GoogleUser {
  email: string = '';

  tokenId: string = '';

  googleId = '';

  static map(data: {profileObj: {}, googleId: string}): GoogleUser {
    const user = new GoogleUser();
    const profile = data.profileObj || {};

    user.email = profile.email;
    user.familyName = profile.familyName;
    user.givenName = profile.givenName;
    user.fullName = profile.name;
    user.avatar = profile.imageUrl;

    user.googleId = data.googleId;
    user.tokenId = data.tokenId;
    user.accessToken = data.accessToken;

    return user;
  }
}
