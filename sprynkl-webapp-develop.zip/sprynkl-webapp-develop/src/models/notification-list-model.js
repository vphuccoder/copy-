// @flow
import {Notification} from './notification-model';

export class NotificationListModel {
  notifications: Notification[];

  static map(data: []): NotificationListModel {
    const notiList = new NotificationListModel();
    notiList.notifications = [];
    if (data && data.length > 0) {
      notiList.notifications = data.map((content) => Notification.map(content));
    }
    return notiList;
  }
}
