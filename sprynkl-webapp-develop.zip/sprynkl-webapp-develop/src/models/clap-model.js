// @flow
import {User} from '.';

export class Clap {
  user: User;

  total: number;

  static map(data: {}): Clap {
    const clap = new Clap();
    clap.total = data.total;
    clap.user = User.map(data);
    return clap;
  }
}
