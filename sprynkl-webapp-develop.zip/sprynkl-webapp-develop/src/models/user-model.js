// @flow

import autobind from 'autobind-decorator';
import {GroupRoles} from './group-roles';
import {Office} from './office-model';
import {InstantMessage, PrivateInfo, CTAModel, UserGroup} from '.';

export class User {
  id: string;

  userStatus: string;

  email: string;

  fullName: string;

  avatar: string;

  defaultAvatar: string;

  hasJoinedGroup: boolean;

  hasInvitedGroup: boolean;

  groups: UserGroup[];

  cta: CTAModel[];

  karma: number;

  totalClap: number;

  nickName: string;

  bio: string;

  position: string;

  team: string;

  office: Office;

  about: string;

  skype: string;

  phone: string;

  instantMessage: InstantMessage;

  @autobind
  getJoinedUserGroup(): UserGroup[] {
    const {groups} = this;
    const res =
      groups && groups.length > 0 ? groups.filter((group: {}): void => group.role !== GroupRoles.INVITED) : [];
    return res;
  }

  @autobind
  isLeadGroup(groupId: string): boolean {
    const groupOfPost = this.groups.filter((g: UserGroup): boolean => groupId === g.group.id && g.isLeader());
    return groupOfPost.length > 0;
  }

  @autobind
  isGroupOwner(groupId: string): boolean {
    const groupOfPost = this.groups.filter((g: UserGroup): boolean => groupId === g.group.id && g.isOwner());
    return groupOfPost.length > 0;
  }

  static map(data: {}): User {
    const user = new User();
    user.id = data.id;
    user.userStatus = data.userStatus;
    user.fullName = data.fullName;
    user.email = data.email;
    user.avatar = data.avatar;
    user.defaultAvatar = data.defaultAvatar;
    user.karma = data.karma;
    user.groups = [];
    user.totalClap = data.total;
    if (data.groups && data.groups.length > 0) {
      data.groups.forEach((userGroupData: {}) => {
        user.groups.push(UserGroup.map(userGroupData));
        user.hasJoinedGroup =
          user.hasJoinedGroup ||
          (userGroupData.role === GroupRoles.MEMBER ||
            userGroupData.role === GroupRoles.ADMIN ||
            userGroupData.role === GroupRoles.OWNER);
        user.hasInvitedGroup = user.hasInvitedGroup || userGroupData.role === GroupRoles.INVITED;
      }, this);
    }
    user.cta = [];
    if (data.callToActions && data.callToActions.length > 0) {
      user.cta = data.callToActions.map((x) => CTAModel.map(x));
    }
    user.nickName = data.nickName;
    user.bio = data.bio;
    user.position = data.position;
    user.team = data.team;
    user.office = Office.map(data.office);
    user.about = data.about;
    user.skype = data.skype;
    user.phone = data.phone;
    user.instantMessage = InstantMessage.map(data.instantMessage);
    if (data.privateInfo) {
      user.privateInfo = PrivateInfo.map(data.privateInfo);
    }
    return user;
  }
}
