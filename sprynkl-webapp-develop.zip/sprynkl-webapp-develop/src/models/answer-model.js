// @flow
import {Comment, User} from '.';

export class Answer {
  id: string;

  comments: Array<Comment>;

  date: number;

  reason: string;

  user: User;

  value: string;

  hasActive: boolean;

  static map(data: {}): Answer {
    const answerModel = new Answer();

    answerModel.id = data.id;
    answerModel.comments = [];
    if (data.comments && data.comments.length > 0) {
      answerModel.comments = data.comments.map((comment: {}): Comment => Comment.map(comment));
    }
    answerModel.date = data.date;
    answerModel.reason = data.reason;
    answerModel.value = data.value;

    answerModel.hasActive = data.hasActive;

    if (data.user) {
      answerModel.user = User.map(data.user);
    }
    return answerModel;
  }
}
