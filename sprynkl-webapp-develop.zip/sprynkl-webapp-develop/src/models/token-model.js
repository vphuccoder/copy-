// @flow
export class Token {
  accessToken: string;

  refreshToken: string;

  tokenType: string;

  static map(data: {}): Token {
    const token = new Token();
    token.accessToken = data.access_token;
    token.refreshToken = data.refresh_token;
    token.tokenType = data.token_type;
    return token;
  }
}
