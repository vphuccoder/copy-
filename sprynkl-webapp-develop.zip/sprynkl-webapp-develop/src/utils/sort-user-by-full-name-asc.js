// @flow
export default function(g1: GroupUser, g2: GroupUser): number {
  return g1.user.fullName.localeCompare(g2.user.fullName);
}
