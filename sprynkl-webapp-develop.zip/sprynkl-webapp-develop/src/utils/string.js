// @flow

export function timeStampToDateString(timestamp: number): string {
  const date = new Date(timestamp);
  const months = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
  const month = months[date.getMonth()];
  const day = date.getDate();
  const year = date.getFullYear();
  const today = new Date();
  let hour = date.getHours();
  const ampm = hour >= 12 ? 'PM' : 'AM';
  hour %= 12;
  hour = hour || 12;
  let min = date.getMinutes();
  min = min < 10 ? `0${min}` : min;
  if (year !== today.getFullYear()) {
    return `${month} ${day} ${year} at ${hour}:${min} ${ampm}`;
  }

  if (date.getMonth() === today.getMonth() && day === today.getDate()) {
    return `Today at ${hour}:${min} ${ampm}`;
  }

  const yesterday = new Date();
  yesterday.setDate(yesterday.getDate() - 1);

  if (date.getMonth() === yesterday.getMonth() && day === yesterday.getDate()) {
    return `Yesterday at ${hour}:${min} ${ampm}`;
  }

  return `${month} ${day} at ${hour}:${min} ${ampm}`;
}

export function getTagAttrValue(tag: string, attr: string): string {
  const attrPrefix = `${attr}="`;
  const attrPrefixIndex = tag.indexOf(attrPrefix);
  if (attrPrefixIndex === -1) {
    return '';
  }
  const prefixValue = tag.substr(attrPrefixIndex + attrPrefix.length);
  const closeQuoteIndex = prefixValue.indexOf('"');
  if (closeQuoteIndex === -1) {
    return '';
  }
  return prefixValue.substr(0, closeQuoteIndex);
}

export function isExpiredDate(timestamp: number): boolean {
  const now = new Date();
  if (now.getTime() > timestamp) {
    return true;
  }
  return false;
}

export function dateStringToTimeStamp(
  day: number,
  month: number,
  year: number,
  hour: number = 0,
  minute: number = 0,
  second: number = 0
): number {
  const dateString = `${month}/${day}/${year} ${hour}:${minute}:${second}`;
  return new Date(dateString).getTime();
}

export function formatStringTemplate(template: string, data: {}): string {
  let result = template;
  for (let key in data) {
    if (data.hasOwnProperty && data.hasOwnProperty(key)) {
      result = result.replace(new RegExp('\\$\\{' + key + '\\}', 'gi'), data[key]);
    }
  }

  return result;
}

export function upperFirstChar(str: string): string {
  if (str === '') {
    return '';
  }

  if (str) {
    if (str.trim() === '') {
      return '';
    }

    return str
      .split(' ')
      .map(
        (s: string): string =>
          s
            .charAt(0)
            .toUpperCase()
            .concat(s.substring(1))
      )
      .join(' ');
  }

  return '';
}

export function shortString(str: string, maxLength: number = 22): string {
  if (str) {
    if (str.length > maxLength) {
      return `${str.substring(0, maxLength).trim()}...`;
    }
    return str;
  }
  return null;
}

export const shortMonths = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
