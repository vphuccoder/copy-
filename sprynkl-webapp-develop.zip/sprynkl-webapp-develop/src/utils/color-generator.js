// @flow
const BASE_COLOR = [
  '#67aaef',
  '#50e5bc',
  '#81e492',
  '#ffc85c',
  '#fc7a94',
  '#6867ef',
  '#50e2e5',
  '#ace481',
  '#ffaa5c',
  '#fc7a7a',
  '#9867ef',
  '#5091e5',
  '#c3e481',
  '#ffe35c',
  '#fc7af8',
  '#b650e5',
  '#e3e462',
  '#81e481',
  '#7ed5b4',
  '#e1c466'
];

export function generateColorByIndex(index: number): string {
  if (index < 0) return '#67aaef';

  const colorIndex = index > 20 ? index - 20 : index;
  return BASE_COLOR[colorIndex];
}
