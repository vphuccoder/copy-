// @flow
export function isContains(text: string, term: string): boolean {
  return (text || '').toLowerCase().includes(term.toLowerCase());
}

export const debounce = (func, delay): (() => mixed) => {
  let inDebounce;
  return function() {
    const context = this;
    const args = arguments;
    clearTimeout(inDebounce);
    inDebounce = setTimeout(() => func.apply(context, args), delay);
  };
};

export function groupBy(source: Array<>, key: string): Array<{}> {
  if (source === null || source === undefined || source.length === 0) return [];

  return source.reduce((dest: Array, item: string): Array<> => {
    (dest[item[key]] = dest[item[key]] || []).push(item);
    return dest;
  }, {});
}

export function dateStringToTimeStamp(
  day: string,
  month: string,
  year: string,
  hour: number = 0,
  minute: number = 0,
  second: number = 0
): number {
  const dateString = `${month}/${day}/${year} ${hour}:${minute}:${second}`;
  return new Date(dateString).getTime();
}

export function uriDecoder(value: string): string {
  // Workaround for bug of react router history waiting for release.
  return `/search/${encodeURIComponent(encodeURIComponent(value))}`;
}
