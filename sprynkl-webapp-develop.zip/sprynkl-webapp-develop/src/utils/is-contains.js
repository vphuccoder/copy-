// @flow
export default function(text: string, term: string): boolean {
  return (text || '').toLowerCase().includes(term.toLowerCase());
}
