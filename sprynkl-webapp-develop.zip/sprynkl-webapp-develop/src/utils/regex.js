// @flow

// Your password must be at least 6 characters, 1 letter, 1 number required.
export const passwordRegex = /^(?=.*\d)(?=.*[a-zA-Z]).{6,}$/;
export const passwordPattern = '(?=.*d)(?=.*[a-zA-Z]).{6,}';
export const emailReg = /[A-Z0-9a-z._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,64}/;
export const passwordReg = /^(?=.*[A-Za-z])(?=.*\d)[A-Za-z\d-`~!@#$%^&*()_=+[\]{}|;:?'",<.>\\/]{6,}$/;
export const fullnameReg = /^(?=.{1,256})/;
export const teamNameReq = /^(?=.{3,256})/;
export const tagRegExp = /(<tag id="[^>]*" name="[^>]*" \/>)/;
export const hashtagRegExp = /(<hashtag name="[^>]*" \/>)/;
export const hashtagRuleRegExp = /(^|\W)(#[^`~!@#$%^&*()\-+=[\]{}|\\;:'"<>,.?/\s]+)/gim;
export const validHashtagRegExp = /(^|\W)(#[^`~!@#$%^&*()\-+=[\]{}|\\;:'"<>,.?/\s]+)/im;
export const urlReg = /(https?:\/\/(?:www\.|(?!www))[a-zA-Z0-9][a-zA-Z0-9-]+[a-zA-Z0-9]\.[^\s]{2,}|www\.[a-zA-Z0-9][a-zA-Z0-9-]+[a-zA-Z0-9]\.[^\s]{2,}|https?:\/\/(?:www\.|(?!www))[a-zA-Z0-9]+\.[^\s]{2,}|www\.[a-zA-Z0-9]+\.[^\s]{2,})/;
export const specialCharacterRegExp = /[!@#$%^&*(),.?":;{}|<>=~'`/\-_+[\]\\]/; // Not use A-Z, 0-9 ... because we support for other languages like Japanese, Chinese...
export const emojiRegExp = /(\u00a9|\u00ae|[\u2000-\u3300]|\ud83c[\ud000-\udfff]|\ud83d[\ud000-\udfff]|\ud83e[\ud000-\udfff])/;
export const phoneReg = /^(?=.*^[0-9*#+]+$)/;

export function isEmail(email: string): boolean {
  return emailReg.test(email);
}

export function isTag(comment: string): boolean {
  return tagRegExp.test(comment);
}

export function isHashTag(content: string): boolean {
  return hashtagRegExp.test(content);
}

export function escapeRegExp(str: string): string {
  return str.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
}

export function isValidHashTag(hashtag: string): boolean {
  return hashtagRuleRegExp.test(hashtag);
}

export function checkValidHashTag(hashtag: string): boolean {
  return validHashtagRegExp.test(hashtag);
}

export function isURL(content: string): boolean {
  return urlReg.test(content);
}

export function hasEmoji(content: string): boolean {
  return emojiRegExp.test(content);
}

export function hasSpecialCharacter(content: string): boolean {
  return specialCharacterRegExp.test(content);
}

export function checkFullNameLength(content: string): boolean {
  return fullnameReg.test(content);
}
