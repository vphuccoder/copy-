// @flow
import {observable, action} from 'mobx';
import {HTTP_STATUS} from '../models/constants/http-status';
import {appModel} from '../models/app-model';

export class BasePageViewModel {
  @observable
  loading: boolean = false;

  @action
  setLoading(loading: boolean) {
    this.loading = loading;
  }

  showLoading() {
    appModel.dialogViewModel.showProgressIndicator();
  }

  hideLoading() {
    appModel.dialogViewModel.hideProgressIndicator();
  }

  handleError(error: {}, shouldPromptErrorMessage: boolean = false) {
    switch (error.code) {
      case HTTP_STATUS.unauthorized.code:
        appModel.dialogViewModel.showPrompt('You are not authorized', 'Error', 'OK', () => {});
        break;
      case HTTP_STATUS.forbidden.code:
        appModel.dialogViewModel.showPrompt(error.message, 'Error', 'OK', () => {});
        break;
      default:
        if (shouldPromptErrorMessage === true) {
          appModel.dialogViewModel.showPrompt(error.message);
        }
        break;
    }
  }
}
