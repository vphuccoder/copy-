// @flow
import React, {Component, Fragment} from 'react';
import type {Node} from 'react';
import {observer} from 'mobx-react';
import {withRouter} from 'react-router';
import type {Match, RouterHistory} from 'react-router';
import autobind from 'autobind-decorator';
import {Col, Tabs, Tab} from 'react-bootstrap';
import {Header} from '../../components/header';
import {PostDetailContentViewModel, PostDetailContent} from '../../components/modals/postDetailModal';
import {PostDetailViewModel} from './PostDetailViewModel';
import './PostDetail.scss';
import {Container, Row} from 'react-bootstrap';
import LoadingContent from '../../pages/home/loadingContent/LoadingContent';
import TeamInfo from '../../pages/home/teamInfo/TeamInfo';

import {appModel} from '../../models/app-model';
import {
  CreateTeamModal,
  InviteTeammateModal,
  JoinTeamModal,
  SeeAllMembersModal,
  UpdateTeamInfoModal
} from '../../components/modals';
import {PostViewModel} from '../../components/feeds';
type PropsType = {
  match: Match,
  history: RouterHistory
};

@withRouter
@observer
class PostDetail extends Component<PropsType> {
  id: string = '';

  viewModel: PostDetailViewModel;

  constructor(props: PropsType) {
    super(props);
    this.viewModel = new PostDetailViewModel();
  }

  componentDidMount() {
    const postId = this.getPostId();
    const {viewModel} = this;
    if (postId) {
      viewModel.setPostId(postId);
      viewModel.initial(this.props.history);
    } else {
      this.props.history.push('/not-found');
    }
  }

  @autobind
  getPostId(): string {
    return this.props.match.params.id || '';
  }

  @autobind
  renderContent(): Node {
    const {showLoadingContent, id} = this.viewModel;
    const {currentGroup} = appModel;

    if (showLoadingContent === true) {
      return <LoadingContent />;
    }

    return (
      <Fragment>
        <Container className="main">
          <Row>
            <Col lg={8}>
              <PostDetailContent postId={id} deletePost={this.deletePost} />
            </Col>
            <Col lg={4}>
              <TeamInfo
                showEditTeamProfile={this.showUpdateTeamInfoDialog}
                showInviteTeammate={this.showInviteTeammateDialog}
                showSeeAllMembers={this.showSeeAllMembersDialog}
                team={currentGroup}
              />
            </Col>
          </Row>
        </Container>
      </Fragment>
    );
  }

  @autobind
  async deletePost(postVm: PostViewModel) {
    await this.viewModel.deletePost(postVm);
    this.props.history.goBack();
  }

  // TODO: implement later
  showInviteTeammateDialog() {}

  showSeeAllMembersDialog() {}

  signInClick() {}

  showCreateTeamDialog() {}

  @autobind
  selectTeam(id: string) {
    if (id) {
      this.props.history.push(`/group/${id}`);
    } else {
      this.props.history.push('/');
    }
  }

  clickCreateTeam() {}

  showUpdateTeamInfoDialog() {}

  showJoinTeamDialog() {}

  render(): Node {
    const {
      canCloseDialog,
      canCloseInviteTeammateDialog,
      canCloseJoinTeam,
      closeInviteTeammateDialog,
      isLeadCurrentGroup,
      isOwnerCurrentGroup,
      showCreateTeam,
      showInviteTeammate,
      showInviteTeammateDialog,
      showJoinTeam
    } = this.viewModel;
    const {currentGroup, currentUser} = appModel;
    const {id: groupId} = currentGroup || {};
    return (
      <Fragment>
        <CreateTeamModal
          canCloseDialog={canCloseDialog}
          onClose={this.viewModel.closeCreateTeam}
          show={showCreateTeam}
          signInClick={this.signInClick}
        />
        <JoinTeamModal
          canCloseDialog={canCloseJoinTeam}
          createClick={this.showCreateTeamDialog}
          onClose={this.viewModel.closeJoinTeam}
          show={showJoinTeam}
          signInClick={this.signInClick}
          user={currentUser}
        />
        <UpdateTeamInfoModal
          canCloseDialog={canCloseDialog}
          onClose={this.viewModel.closeUpdateTeamInfo}
          show={this.viewModel.showUpdateTeamInfo}
          team={currentGroup}
        />
        <SeeAllMembersModal
          canCloseDialog={canCloseDialog}
          groupId={groupId}
          isLead={isLeadCurrentGroup}
          isOwner={isOwnerCurrentGroup}
          onClose={this.viewModel.closeSeeAllMembers}
          show={this.viewModel.showSeeAllMembers}
          showInviteTeammateDialog={showInviteTeammateDialog}
        />
        <InviteTeammateModal
          canCloseDialog={canCloseInviteTeammateDialog}
          groupId={groupId}
          onClose={closeInviteTeammateDialog}
          show={showInviteTeammate}
        />
        <Header
          clickCreateTeam={this.clickCreateTeam}
          editTeamProfile={this.showUpdateTeamInfoDialog}
          groups={this.viewModel.joinGroups}
          isLead={this.viewModel.isLeadCurrentGroup}
          selectTeam={this.selectTeam}
          selectedGroup={currentGroup}
          showInviteTeammateDialog={showInviteTeammateDialog}
          showJoinTeamDialog={this.showJoinTeamDialog}
        />
        {this.renderContent()}
      </Fragment>
    );
  }
}

export default PostDetail;
