// @flow
import autobind from 'autobind-decorator';
import {action, computed, observable} from 'mobx';
import {PostDetailContentViewModel} from '../../components/modals/postDetailModal';
import {Group, UserGroup} from '../../models';
import {appModel} from '../../models/app-model';
import {groupService, postService} from '../../services/index';
import {BasePageViewModel} from '../BasePageViewModel';
class PostDetailViewModel extends BasePageViewModel {
  @observable
  id: string = '';

  @observable
  postViewModel: PostDetailContentViewModel;

  @observable
  showCreateTeam: boolean = false;

  @observable
  canCloseDialog: boolean = false;

  @observable
  showJoinTeam: boolean = false;

  @observable
  showLoadingContent: boolean = true;

  @observable
  showUpdateTeamInfo: boolean = false;

  @observable
  showInviteTeammate: boolean = false;

  @observable
  showSeeAllMembers: boolean = false;

  @observable
  canCloseInviteTeammateDialog: boolean = false;

  @observable
  joinGroups: Array<UserGroup> = [];

  @observable
  group: Group = null;

  constructor() {
    super();
    this.postViewModel = new PostDetailContentViewModel();
  }

  @action
  setCurrentGroup(group: Group) {
    this.group = group;
  }

  @computed
  get isLeadCurrentGroup(): boolean {
    if (this.group) {
      const {currentUser} = appModel;
      return currentUser.isLeadGroup(this.group.id);
    }
    return false;
  }

  @computed
  get isOwnerCurrentGroup(): boolean {
    if (this.group) {
      const {currentUser} = appModel;
      return currentUser.isGroupOwner(this.group.id);
    }
    return false;
  }

  @observable
  canCloseJoinTeam: boolean = false;

  @autobind
  @action
  showCreateTeamDialog(canCloseDialog: boolean = false) {
    this.showJoinTeam = false;
    this.showCreateTeam = true;
    this.canCloseDialog = canCloseDialog;
  }

  @autobind
  @action
  closeJoinTeam() {
    this.showJoinTeam = false;
  }

  @autobind
  @action
  closeCreateTeam() {
    this.showCreateTeam = false;
  }

  @autobind
  @action
  showUpdateTeamInfoDialog(canCloseDialog: boolean = false) {
    this.showUpdateTeamInfo = true;
    this.canCloseDialog = canCloseDialog;
  }

  @autobind
  @action
  closeUpdateTeamInfo() {
    this.showUpdateTeamInfo = false;
  }

  @autobind
  @action
  showInviteTeammateDialog(canCloseDialog: boolean = false) {
    this.showInviteTeammate = true;
    this.canCloseInviteTeammateDialog = canCloseDialog;
  }

  @autobind
  @action
  closeInviteTeammateDialog() {
    this.showInviteTeammate = false;
  }

  @autobind
  @action
  showSeeAllMembersDialog(canCloseDialog: boolean = false) {
    this.showSeeAllMembers = true;
    this.canCloseDialog = canCloseDialog;
  }

  @autobind
  @action
  closeSeeAllMembers() {
    this.showSeeAllMembers = false;
  }

  @action
  setJoinGroups(groups: Array<Group>) {
    this.joinGroups = groups;
  }

  @autobind
  @action
  showJoinTeamDialog(canCloseDialog: boolean = false) {
    this.showJoinTeam = true;
    this.canCloseDialog = canCloseDialog;
  }

  setPostId(postId: string) {
    this.id = postId;
  }

  @action
  async deletePost(selectedPost: {}): Promise {
    try {
      const {accessToken} = appModel.currentToken;
      await postService.deletePost(accessToken, selectedPost.post.id);
    } catch (ex) {
      this.handleError(ex, true);
    }
  }

  async initial(history: History) {
    const user = appModel.currentUser;
    try {
      if (user.hasJoinedGroup === true) {
        const groups = user.getJoinedUserGroup();
        this.setJoinGroups(groups);
        const post = await postService.getPost(appModel.currentToken.accessToken, this.id);
        const group = await groupService.getGroup(appModel.currentToken.accessToken, post.group.id);
        this.postViewModel.populateData(post);
        if (group) {
          appModel.setCurrentGroup(group);
        }
        this.canCloseJoinTeam = true;
      } else if (user.hasInvitedGroup === true) {
        this.showJoinTeamDialog();
      } else {
        this.showCreateTeamDialog();
      }
      this.showLoadingContent = false;
    } catch (ex) {
      history.push('/not-found');
    }
  }
}

export {PostDetailViewModel};
