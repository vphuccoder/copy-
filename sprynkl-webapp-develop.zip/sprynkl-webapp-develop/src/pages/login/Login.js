import autobind from 'autobind-decorator';
import {
  CREATE_NEW_ACCOUNT,
  DONT_HAVE_ACCOUNT,
  EMAIL_DOES_NOT_EXIST,
  HOME_TEXT,
  LOGIN_DESCRIPTION,
  PASSWORD_INVALID,
  INVALID_EMAIL_FORMAT
} from 'models/constants/string-constant';
import React, {Component} from 'react';
import {Button, Col, Form, Row, Spinner} from 'react-bootstrap';
import {withRouter} from 'react-router';
import {Logo} from '../../components/baseComponents/svg/Svg';
import {GoogleSignIn} from '../../components/google';
import {URL_BLOG} from '../../configs';
import {appModel} from '../../models/app-model';
import {storageService, userService} from '../../services';
import {emailReg} from '../../utils/regex';
import Footer from './Footer';
import './Login.scss';

@withRouter
class Login extends Component {
  constructor(props) {
    super(props);
    this.state = {
      email: '',
      isLoading: false,
      password: ''
    };
  }

  componentDidMount() {
    storageService.clearRefreshToken();
  }

  @autobind
  changeEmail(e) {
    this.setState({email: e.target.value, emailInvalid: false});
  }

  @autobind
  changePassword(e) {
    this.setState({password: e.target.value, passwordInvalid: false});
  }

  @autobind
  async login(e) {
    e.preventDefault();

    const {email} = this.state;
    if (!emailReg.test(email)) {
      this.setState({emailInvalid: true, emailInvalidMessage: INVALID_EMAIL_FORMAT});
      return;
    }

    this.setState({isLoading: true});

    try {
      const {deviceId, fcmToken} = appModel;
      const {email, password} = this.state;
      const token = await userService.oauth(email, password, deviceId, fcmToken);
      const user = await userService.getUser(token.accessToken);

      if (token && user) {
        appModel.setCurrentUser(user);
        appModel.setCurrentToken(token);
        const {history} = this.props;
        history.push('/');
      }
    } catch (ex) {
      const data = ex.data || {};
      switch (data.error) {
        case 'user_not_found':
          this.setState({
            emailInvalid: true,
            emailInvalidMessage: EMAIL_DOES_NOT_EXIST,
            isLoading: false
          });
          break;
        default:
          this.setState({isLoading: false, passwordInvalid: true});
      }
    }
  }

  render() {
    const {
      email,
      emailInvalid,
      emailInvalidMessage,
      isLoading,
      password,
      passwordInvalid
    } = this.state;
    return (
      <React.Fragment>
        <Row className="login-page">
          <Col className="d-none d-lg-block" lg="6">
            <div className="back-ground-container">
              <div>
                <span className="home-text">{HOME_TEXT}</span>
              </div>
              <div className="login-description">
                <span>{LOGIN_DESCRIPTION}</span>
              </div>
              <a href={URL_BLOG}>
                <Button className="learn-more-button">{'Learn more'}</Button>
              </a>
            </div>
          </Col>
          <Col lg="6">
            <div className="login-container">
              <Logo height={40} />
              <h3 className="sign-in-text"> Sign in</h3>
              <Col className="text-center" lg="6" md="6" sm="8">
                <Form className="login-form" onSubmit={this.login}>
                  <Form.Group>
                    <Form.Control
                      isInvalid={emailInvalid}
                      onChange={this.changeEmail}
                      placeholder="Email"
                      required
                      type="email"
                      value={email}
                    />
                    <Form.Control.Feedback className="text-left" type="invalid">
                      {emailInvalidMessage}
                    </Form.Control.Feedback>
                  </Form.Group>
                  <Form.Group>
                    <Form.Control
                      isInvalid={passwordInvalid}
                      onChange={this.changePassword}
                      placeholder="Password"
                      required
                      type="password"
                      value={password}
                    />
                    <Form.Control.Feedback className="text-left" type="invalid">
                      {PASSWORD_INVALID}
                    </Form.Control.Feedback>
                  </Form.Group>
                  <Form.Group className="text-left">
                    <a href="./reset-password">
                      <span className="forgot-password-text">{'Forgot password?'}</span>
                    </a>
                  </Form.Group>
                  <Button className="signin" disabled={isLoading} type="submit" variant="primary">
                    {isLoading && (
                      <Spinner
                        animation="border"
                        aria-hidden="true"
                        as="span"
                        role="status"
                        size="sm"
                      />
                    )}
                    <span className="button-text">Continue</span>
                  </Button>
                </Form>
                <Form.Group>
                  <h6 className="seperate-line">
                    <span className="seperate-text">or</span>
                  </h6>
                  <GoogleSignIn />
                </Form.Group>
                <Form.Group>
                  <span className="do-not-have-account-text">{DONT_HAVE_ACCOUNT}</span>
                </Form.Group>
                <Form.Group>
                  <a href="/signup">
                    <span className="create-account-text">{CREATE_NEW_ACCOUNT}</span>
                  </a>
                </Form.Group>
              </Col>
              <Footer currentYear={2019} />
            </div>
          </Col>
        </Row>
      </React.Fragment>
    );
  }
}

export default Login;
