import React, {Component, Fragment} from 'react';
import {URL_ABOUT_US, URL_HELP_CENTER} from '../../configs';

class Footer extends Component {
  render() {
    const {currentYear} = this.props;
    return (
      <div className="text-center login-footer">
        <Fragment>
          <div className="footer-container">
            <a href={URL_ABOUT_US}>
              <span className="footer-item">About Us</span>
            </a>
            <span className="footer-item">•</span>
            <a href={URL_HELP_CENTER}>
              <span className="footer-item">Support</span>
            </a>
            <span className="footer-item">•</span>
            <span className="footer-item">© {currentYear} Sprynkl</span>
          </div>
        </Fragment>
      </div>
    );
  }
}

export default Footer;
