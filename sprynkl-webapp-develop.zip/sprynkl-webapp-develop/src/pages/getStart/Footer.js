import React, {Component} from 'react';
import {
  URL_ABOUT_US,
  URL_ACCEPTABLE_USE_POLICY,
  URL_HELP_CENTER,
  URL_PRIVACY_POLICY,
  URL_TERM_OF_USE
} from '~/configs';

class AppFooter extends Component {
  render() {
    const {currentYear} = this.props;
    return (
      <div className="text-center home-footer">
        <div className="footer-container">
          <div className="term-of-service">
            <a href={URL_ABOUT_US}>
              <span className="footer-item">About Us</span>
            </a>
            <span className="footer-item">
              <span>•</span>
            </span>
            <a href={URL_HELP_CENTER}>
              <span className="footer-item">Support</span>
            </a>
            <span className="footer-item">•</span>
            <a href={URL_PRIVACY_POLICY}>
              <span className="footer-item">Cookie Policy</span>
            </a>
            <span className="footer-item">•</span>
            <a href={URL_ACCEPTABLE_USE_POLICY}>
              <span className="footer-item">Acceptable Use Policy</span>
            </a>
            <span className="footer-item">•</span>
            <a href={URL_TERM_OF_USE}>
              <span className="footer-item">Term of Use</span>
            </a>
          </div>
          <div>
            <span className="footer-item">© {currentYear} Sprynkl</span>
          </div>
        </div>
      </div>
    );
  }
}

export default AppFooter;
