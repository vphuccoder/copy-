// @flow
import React, { Component } from "react";
import { Container, Form, Col } from "react-bootstrap";
import { withRouter } from "react-router";
import Footer from "./Footer";
import "./GetStart.scss";
import { LogoWhiteText } from "../../components/baseComponents/svg/Svg";

type PropsType = {};

@withRouter
class GetStart extends Component<PropsType> {
  onSignIn = () => {
    const { history } = this.props;
    history.push("/login");
  };

  onStartUp = () => {
    const { history } = this.props;
    history.push("/signup");
  };

  render(): React.Node {
    return (
      <div className="get-start">
        <Col lg="4" md="6" sm="8">
          <Container className="center-container text-center">
            <Form.Group>
              <LogoWhiteText />
            </Form.Group>
            <Form.Group>
              <div>
                <span className="title-text">{"Get more team from you work"}</span>
              </div>
            </Form.Group>
            <div className="button-group">
              <Form.Group>
                <button className="get-start-button" onClick={this.onStartUp}>
                  {"Get Started"}
                </button>
              </Form.Group>
              <Form.Group>
                <button className="sign-in-button" onClick={this.onSignIn}>
                  Sign In
                </button>
              </Form.Group>
            </div>
          </Container>
        </Col>
        <Footer currentYear={2019} />
      </div>
    );
  }
}

export default GetStart;
