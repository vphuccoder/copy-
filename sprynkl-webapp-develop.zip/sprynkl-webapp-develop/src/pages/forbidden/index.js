import Forbidden from './Forbidden';

export default Forbidden;
