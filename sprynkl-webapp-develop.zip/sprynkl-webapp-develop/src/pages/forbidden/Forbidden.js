// @flow
import React, {Component} from 'react';
import {PageForbiddenIcon} from '../../components/baseComponents/svg/Svg';
import {PAGE_FORBIDDEN} from '../../models/constants/string-constant';
import './Forbidden.scss';

class Forbidden extends Component {
  render(): React.Node {
    return (
      <div className="page-forbidden">
        <PageForbiddenIcon />
        <div className="description">{PAGE_FORBIDDEN}</div>
      </div>
    );
  }
}

export default Forbidden;
