// @flow
import React, {Component} from 'react';
import type {Node} from 'react';
import autobind from 'autobind-decorator';
import {Button} from 'react-bootstrap';
import {User} from 'models';
import {renderUserAvatar} from 'components/baseComponents/svg/Avatar';
import Icon from 'components/baseComponents/Icon';

type PropsType = {
  header: string,
  data: {}[]
};

class InfoSection extends Component<PropsType> {
  @autobind
  renderValue(value: string, action: string): Node {
    return action ? (
      <a href={action} className="value">
        {value}
      </a>
    ) : (
      <div className="value">{value}</div>
    );
  }

  render(): Node {
    const {data, header} = this.props;
    return data ? (
      <div className="section">
        <div className="section-header">{header}</div>
        <div className="section-info">
          {data.map(
            ({label, value, action}: SectionItemType, index: number): ?Node => {
              if (value) {
                return (
                  <div key={index} className="item">
                    <div className="label">{label}</div>
                    {this.renderValue(value, action)}
                  </div>
                );
              }
            }
          )}
        </div>
      </div>
    ) : null;
  }
}

export default InfoSection;
