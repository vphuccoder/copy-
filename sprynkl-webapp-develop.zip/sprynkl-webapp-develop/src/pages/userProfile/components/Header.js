// @flow
import React, {Component} from 'react';
import type {Node} from 'react';
import autobind from 'autobind-decorator';
import {Button} from 'react-bootstrap';
import {User} from '../../../models';
import {renderUserAvatar} from '../../../components/baseComponents/svg/Avatar';
import Icon from '../../../components/baseComponents/Icon';
import TextOverFlow from '../../../components/baseComponents/textOverFlow/TextOverFlow';

type PropsType = {
  user: User,
  canEdit: boolean
};

class Header extends Component<PropsType> {
  @autobind
  renderEdit(): Node {
    const {canEdit} = this.props;
    return canEdit === true ? (
      <div className="settings">
        <Button className="edit-button" variant="outline-secondary">
          Edit Profile
        </Button>
        <div className="setting-icon" role="button">
          <Icon iconName="setting" color="#777b7d" size={24} />
        </div>
      </div>
    ) : null;
  }

  render(): Node {
    const {user, canEdit} = this.props;
    const {fullName, karma, avatar, defaultAvatar} = user || {};

    return (
      <div className="header">
        {renderUserAvatar(avatar, defaultAvatar, 120)}
        <div className="other-info">
          <TextOverFlow className="mw-100 name">{fullName}</TextOverFlow>
          <div className="karma">{karma} KARMA</div>
          {this.renderEdit()}
        </div>
      </div>
    );
  }
}

export default Header;
