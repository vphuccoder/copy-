// @flow
import React, {Component} from 'react';
import type {Node} from 'react';
import autobind from 'autobind-decorator';
import {Tabs, Tab} from 'react-bootstrap';
import {FeedModel, PostModel} from 'models';
import {renderUserAvatar} from 'components/baseComponents/svg/Avatar';
import Icon from 'components/baseComponents/Icon';
import FeedList from 'components/feeds/FeedList';
import {PostViewModel} from 'components/feeds';
import InfoSection from './InfoSection';

type PropsType = {
  feeds: PostViewModel[],
  deletePost: (postVm: PostViewModel) => void
};

class Body extends Component<PropsType> {
  render(): Node {
    const {feeds, deletePost} = this.props;
    return (
      <div className="body">
        <Tabs defaultActiveKey="myPosts" id="body">
          <Tab eventKey="myPosts" title="My Posts">
            <FeedList feeds={feeds} deletePost={deletePost} />
          </Tab>
          <Tab eventKey="profile" title="Profile">
            {/* <InfoSection header="About" data={}/> */}
          </Tab>
        </Tabs>
      </div>
    );
  }
}

export default Body;
