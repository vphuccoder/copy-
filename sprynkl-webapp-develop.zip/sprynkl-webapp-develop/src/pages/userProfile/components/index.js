import Header from './Header';
import Body from './Body';
import InfoSection from './InfoSection';
export {Header, Body, InfoSection};
