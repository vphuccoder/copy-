// @flow
import {observable, action, computed, runInAction} from 'mobx';
import autobind from 'autobind-decorator';
import type {RouterHistory} from 'react-router';
import {BasePageViewModel} from '../BasePageViewModel';
import {appModel} from '../../models/app-model';
import {userService, postService, groupService} from '../../services';
import {User, PostModel, Group} from '../../models';
import {SYSTEM_VARIABLE, FILTER_TYPE, HTTP_STATUS} from '../../models/constants';
import {PostViewModel} from '../../components/feeds';

type UserInfoType = {label: string, value: string, action: string};

class UserProfileViewModel extends BasePageViewModel {
  userId: string = '';

  isLoginUser: boolean = false;

  @observable
  title: string = '';

  @observable
  user: User;

  @observable
  userNotFound: boolean = false;

  @observable
  aboutInfos: UserInfoType[];

  @observable
  talkToMeInfos: UserInfoType[];

  @observable
  privateInfos: UserInfoType[];

  @observable
  fetchingData: boolean = false;

  @observable
  firstTimeLoad: boolean = true;

  @observable
  posts: PostViewModel[] = [];

  hasMore: boolean = true;

  page: number = 0;

  @observable
  isShowLoading: boolean = true;

  @computed
  get postsData(): PostViewModel[] {
    return this.posts;
  }

  @action
  setUserId(userId: string) {
    this.userId = userId;
    this.isLoginUser = userId && appModel.currentUser && userId === appModel.currentUser.id;
  }

  @autobind
  @action
  async fetchUserInfo(history: RouterHistory): User {
    try {
      this.showLoading();
      const user = await userService.getUserById(appModel.currentToken.accessToken, this.userId);
      this.user = user;
      this.title = this.isLoginUser ? 'My Profile' : user.fullName;
      this.aboutInfos = this.getAboutInfos();
      this.talkToMeInfos = this.getTalkToMeInfos();
      if (this.isLoginUser) {
        this.privateInfos = this.getPrivateInfos();
      }
    } catch (e) {
      if (e.code === HTTP_STATUS.notFound.code) {
        this.userNotFound = true;
        history.push('/notfound');
      } else if (e.code === HTTP_STATUS.forbidden.code) {
        history.push('/forbidden');
      } else {
        this.handleError(e, true);
      }
    } finally {
      this.hideLoading();
    }
  }

  @autobind
  getUniqueGroupIds(posts: PostModel[]): string[] {
    const groupIds: string[] = [];
    posts.forEach((p: PostModel) => {
      if (groupIds.indexOf(p.group.id) === -1) {
        groupIds.push(p.group.id);
      }
    });
    return groupIds;
  }

  @autobind
  async fetchUniqueGroups(uniqueGroups: string[]): Promise<Group[]> {
    const allRequests = uniqueGroups.map(
      (groupId: string): Promise<Group> => groupService.getGroup(appModel.currentToken.accessToken, groupId)
    );
    return await Promise.all(allRequests);
  }

  @autobind
  @action
  async fetchUserFeeds(page: number) {
    if (this.fetchingData || this.hasMore === false) {
      return;
    }
    try {
      this.fetchingData = true;
      const feed = await postService.getUserFeed(
        appModel.currentToken.accessToken,
        SYSTEM_VARIABLE.PAGE_SIZE,
        page,
        FILTER_TYPE.SENT,
        'All'
      );
      if (feed && feed.posts.length > 0) {
        const uniqueGroupIds = this.getUniqueGroupIds(feed.posts);
        const groups = await this.fetchUniqueGroups(uniqueGroupIds);
        feed.posts.forEach((p: PostModel) => {
          const group = groups.find((g: Group): boolean => g.id === p.group.id);
          if (group) {
            p.setGroup(group);
          }
        });
        this.posts.push(...feed.posts.map((p: PostModel): PostViewModel => PostViewModel.toViewModel(p)));

        this.page = page;
      } else {
        this.hasMore = false;
      }
      this.isShowLoading = false;
    } catch (e) {
      this.handleError(e, true);
    } finally {
      this.fetchingData = false;
      this.firstTimeLoad = false;
    }
  }

  @autobind
  @action
  async deletePost(selectedPost: PostViewModel) {
    try {
      this.showLoading();
      const {accessToken} = appModel.currentToken;
      await postService.deletePost(accessToken, selectedPost.post.id);

      const index = this.posts.indexOf(selectedPost);

      runInAction(() => {
        this.posts.splice(index, 1);
      });
    } catch (ex) {
      this.handleError(ex, true);
    } finally {
      this.hideLoading();
    }
  }

  @autobind
  getAboutInfos(): Array {
    const {user} = this;
    const {fullName, nickName, bio, position, team, office} = user || {};
    const {name: officeName} = office || {};
    return [
      {label: 'Full Name', value: fullName || ''},
      {label: 'Nickname', value: nickName || ''},
      {label: 'Bio', value: bio || ''},
      {label: 'Position', value: position || ''},
      {label: 'Team', value: team || ''},
      {label: 'Office', value: officeName || ''}
    ];
  }

  @autobind
  getTalkToMeInfos(): Array {
    const {user} = this;
    return [
      {label: 'About', value: user.about || ''},
      {label: 'Email', value: user.email || ''},
      {label: 'Skype', value: user.instantMessage ? user.instantMessage.skype : ''},
      {label: 'Phone', value: user.phone || ''}
    ];
  }

  @autobind
  getPrivateInfos(): Array {
    const {user} = this;
    const {privateInfo} = user || {};
    const {gender, birthday} = privateInfo || {};

    let birthdayString = '';

    if (birthday) {
      birthdayString = new Date(birthday).toLocaleDateString();
    }

    return [{label: 'Gender', value: gender || ''}, {label: 'Birthday', value: birthdayString}];
  }
}

export {UserProfileViewModel};
