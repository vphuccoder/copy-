// @flow
import React, {Component, Fragment} from 'react';
import type {Node} from 'react';
import {observer} from 'mobx-react';
import {withRouter} from 'react-router';
import type {Match, RouterHistory} from 'react-router';
import autobind from 'autobind-decorator';
import {Col, Tabs, Tab, Spinner} from 'react-bootstrap';
import {Header as PageHeader} from 'components/header';
import {UserProfileViewModel} from './UserProfileViewModel';
import {Header, InfoSection} from './components';
import FeedList from '../../components/feeds/FeedList';
import './UserProfile.scss';

type PropsType = {
  match: Match,
  history: RouterHistory
};

@withRouter
@observer
class UserProfile extends Component<PropsType> {
  viewModel: UserProfileViewModel;

  constructor(props: PropsType) {
    super(props);
    this.viewModel = new UserProfileViewModel();
  }

  componentDidMount() {
    const {history} = this.props;
    const userId = this.getUserId();
    const {viewModel} = this;
    if (userId) {
      viewModel.setUserId(userId);
      viewModel.fetchUserInfo(history);
      if (viewModel.isLoginUser) {
        viewModel.fetchUserFeeds(1);
      }
    }
  }

  @autobind
  getUserId(): string {
    const {
      match: {
        params: {id}
      }
    } = this.props;

    return id || '';
  }

  @autobind
  async loadMore() {
    await this.viewModel.fetchUserFeeds(this.viewModel.page + 1);
  }

  @autobind
  renderPrivateInfos(): Node {
    const {privateInfos} = this.viewModel;
    return privateInfos && privateInfos.length > 0 ? (
      <InfoSection header="Private information" data={privateInfos} />
    ) : null;
  }

  @autobind
  renderProfile(): Node {
    const {aboutInfos, talkToMeInfos} = this.viewModel;
    return (
      <div className="info-detail">
        <InfoSection header="About" data={aboutInfos} />
        <InfoSection header="Talk to me" data={talkToMeInfos} />
        {this.renderPrivateInfos()}
      </div>
    );
  }

  @autobind
  renderTab(): Node {
    const {isLoginUser, postsData, deletePost, fetchingData, firstTimeLoad} = this.viewModel;
    return isLoginUser ? (
      <Tabs defaultActiveKey="myPosts" id="body">
        <Tab eventKey="myPosts" title="My Posts">
          <FeedList
            feeds={postsData}
            deletePost={deletePost}
            isProfileScreen
            showLoadingContent={fetchingData && firstTimeLoad}
            loadMore={this.loadMore}
          />
          {this.renderLoadMore()}
        </Tab>
        <Tab eventKey="profile" title="Profile">
          {this.renderProfile()}
        </Tab>
      </Tabs>
    ) : (
      this.renderProfile()
    );
  }

  @autobind
  renderLoadMore(): Node {
    const {fetchingData, firstTimeLoad} = this.viewModel;
    return fetchingData === true && firstTimeLoad === false ? (
      <div className="load-more-spinner">
        <Spinner animation="border" variant="primary" />
      </div>
    ) : null;
  }

  @autobind
  renderContent(): Node {
    const {user} = this.viewModel;
    return user ? (
      <div className="my-profile-page">
        <Col className="container" lg="6">
          <Header user={user} />
          <div className="body">{this.renderTab()}</div>
        </Col>
      </div>
    ) : null;
  }

  render(): Node {
    return (
      <Fragment>
        <PageHeader title={this.viewModel.title} />
        {this.renderContent()}
      </Fragment>
    );
  }
}

export default UserProfile;
