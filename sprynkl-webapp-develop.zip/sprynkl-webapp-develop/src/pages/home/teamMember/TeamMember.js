// @flow
import React, {Component} from 'react';
import type {Node} from 'react';
import {Container} from 'react-bootstrap';
import autobind from 'autobind-decorator';
import {Group, GroupUser} from '../../../models';
import {icons} from '../../../components/themes/Icons';
import ProfileLink from '../../../components/baseComponents/profileLink';
import IcomoonReact from 'icomoon-react';
import iconSet from '~/selection.json';
import {renderUserAvatar} from '../../../components/baseComponents/svg/Avatar';
import './TeamMember.scss';

type PropsType = {
  team: Group,
  isLeader: boolean,
  isOwner: boolean,
  showInviteTeammate: () => void,
  showSeeAllMembers: () => void
};

type StateType = {};

class TeamMember extends Component<PropsType, StateType> {
  @autobind
  renderLeaderList(): Node {
    const {team} = this.props;
    const leaders = team.getLeaders();
    return leaders.map(
      (leader: GroupUser): Node => {
        const {user} = leader;
        const {avatar, defaultAvatar} = user;
        return (
          <div key={user.id} className="leader-item">
            <ProfileLink user={user}>{renderUserAvatar(avatar, defaultAvatar, 48)}</ProfileLink>
            <span className="name">
              <ProfileLink user={user} />
            </span>
          </div>
        );
      }
    );
  }

  @autobind
  renderMemberList(): Node {
    const {team} = this.props;
    const members = team.getMembers();
    return members.slice(0, 5).map(
      (member: GroupUser): Node => {
        const {user} = member;
        const {avatar, defaultAvatar} = user;
        return (
          <div key={user.id} className="member-item">
            <ProfileLink user={user}>{renderUserAvatar(avatar, defaultAvatar, 48)}</ProfileLink>
          </div>
        );
      }
    );
  }

  @autobind
  openInviteTeammateModal() {
    const {showInviteTeammate} = this.props;
    if (showInviteTeammate) {
      showInviteTeammate();
    }
  }

  @autobind
  showSeeAllMembers(e: SyntheticEvent<HTMLInputElement>) {
    e.preventDefault();
    const {showSeeAllMembers} = this.props;
    showSeeAllMembers();
  }

  render(): Node {
    const {
      team: {totalMembers},
      isLeader
    } = this.props;
    return (
      <div className="team-member-info">
        <Container className="right-panel team-lead">
          <div className="panel-header">
            <span>Team Leads</span>
          </div>
          <div className="leader-list">{this.renderLeaderList()}</div>
        </Container>
        <Container className="right-panel team-member">
          <div className="panel-header">
            <span>Team Members • {totalMembers || 0} </span>
            <a className="view-all-member" href="" onClick={this.showSeeAllMembers}>
              See All
            </a>
          </div>
          <div className="member-list">{this.renderMemberList()}</div>
        </Container>
        {isLeader && (
          <Container className="right-panel team-actions">
            <div role="button" className="action-button" onClick={this.openInviteTeammateModal}>
              <IcomoonReact iconSet={iconSet} color="#2786e9" size={32} icon={icons.invite} />
              <span className="action-name">Invite teammates</span>
            </div>
          </Container>
        )}
      </div>
    );
  }
}

export default TeamMember;
