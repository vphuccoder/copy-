import Home from './Home';

export {Home};
