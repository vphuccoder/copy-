// @flow
import React, {Component, Fragment} from 'react';
import {Container, Row, Col} from 'react-bootstrap';
import {CreatePostLoadingPanel, FeedItemLoadingContent} from '../../../components/baseComponents/svg/Svg';
import './LoadingContent.scss';

type PropsType = {};

type StateType = {};

class LoadingContent extends Component<PropsType, StateType> {
  render(): React.Node {
    return (
      <Fragment>
        <Container className="main loading-content">
          <Row>
            <Col lg={8}>
              <div className="content">
                <CreatePostLoadingPanel />
              </div>
              <div className="content">
                <FeedItemLoadingContent />
              </div>
              <div className="content">
                <FeedItemLoadingContent />
              </div>
            </Col>
            <Col lg={4}>
              <div className="content">
                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 350 272">
                  <g fill="none" fillRule="evenodd">
                    <rect width="350" height="272" fill="#FFF" rx="4" />
                    <path
                      fill="#000"
                      fillOpacity="0.15"
                      fillRule="nonzero"
                      d="M5.128 1c-1.475 0-2.034.108-2.61.416a2.635 2.635 0 0 0-1.102 1.102C1.108 3.094 1 3.653 1 5.128v261.744c0 1.475.108 2.034.416 2.61.255.478.624.847 1.102 1.102.576.308 1.135.416 2.61.416h339.744c1.475 0 2.034-.108 2.61-.416a2.635 2.635 0 0 0 1.102-1.102c.308-.576.416-1.135.416-2.61V5.128c0-1.475-.108-2.034-.416-2.61a2.635 2.635 0 0 0-1.102-1.102c-.576-.308-1.135-.416-2.61-.416H5.128zm0-1h339.744c1.783 0 2.43.186 3.082.534.652.349 1.163.86 1.512 1.512.348.652.534 1.299.534 3.082v261.744c0 1.783-.186 2.43-.534 3.082a3.635 3.635 0 0 1-1.512 1.512c-.652.348-1.299.534-3.082.534H5.128c-1.783 0-2.43-.186-3.082-.534a3.635 3.635 0 0 1-1.512-1.512c-.348-.652-.534-1.299-.534-3.082V5.128c0-1.783.186-2.43.534-3.082A3.635 3.635 0 0 1 2.046.534C2.698.186 3.345 0 5.128 0z"
                    />
                    <circle cx="48" cy="44" r="24" fill="#858F95" fillOpacity="0.15" />
                    <path
                      fill="#858F95"
                      fillOpacity="0.15"
                      d="M88 20h101v10H88zM24 92h240v10H24zM88 40h61v10H88zM24 114h291v10H24zM24 136h76v10H24z"
                    />
                  </g>
                </svg>
              </div>
            </Col>
          </Row>
        </Container>
      </Fragment>
    );
  }
}

export default LoadingContent;
