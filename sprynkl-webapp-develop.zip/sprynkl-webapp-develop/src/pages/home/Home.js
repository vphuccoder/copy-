// @flow
import autobind from 'autobind-decorator';
import {observer} from 'mobx-react';
import type {Node} from 'react';
import React, {Component, Fragment} from 'react';
import {Col, Container, Row, Spinner} from 'react-bootstrap';
import type {Match, RouterHistory} from 'react-router';
import {withRouter} from 'react-router';
import {StickyContainer} from '../../components/baseComponents';
import {PostViewModel} from '../../components/feeds';
import FeedList from '../../components/feeds/FeedList';
import {Header} from '../../components/header';
import {
  CreateTeamModal,
  InviteTeammateModal,
  JoinTeamModal,
  SeeAllMembersModal,
  UpdateTeamInfoModal
} from '../../components/modals';
import {PostModel, UserGroup} from '../../models';
import {appModel} from '../../models/app-model';
import {groupService} from '../../services';
import {HomePageViewModel} from './HomePageViewModel';
import CreatePostPanel from './createPostPanel/CreatePostPanel';
import LoadingContent from './loadingContent/LoadingContent';
import TeamInfo from './teamInfo/TeamInfo';
import './Home.scss';

type PropsType = {
  history: RouterHistory,
  match: Match
};

type StateType = {};

@withRouter
@observer
class Home extends Component<PropsType, StateType> {
  viewModel: HomePageViewModel;
  groupId: string;

  constructor(props: PropsType) {
    super(props);
    const groupId = this.getGroupId();
    if (groupId) {
      this.groupId = groupId;
    }
    this.viewModel = new HomePageViewModel();
  }

  viewModel: HomePageViewModel;

  async componentDidMount() {
    await this.checkUserGroups();

    await this.viewModel.getFeeds();
  }

  getGroupId(): string {
    return this.props.match.params.id || '';
  }

  async checkUserGroups() {
    const user = appModel.currentUser;

    if (user.hasJoinedGroup === true) {
      const groups = user.getJoinedUserGroup();
      this.viewModel.setJoinGroups(groups);
      if (groups.length === 1) {
        // select group
        const userGroup = groups[0] || {};
        const group = await groupService.getGroup(appModel.currentToken.accessToken, userGroup.group.id);
        this.viewModel.setCurrentGroup(group);
        appModel.setCurrentGroup(group);
      } else if (this.groupId) {
        const userGroup = groups.find((group: UserGroup) => group.group.id === this.groupId);
        const group = await groupService.getGroup(appModel.currentToken.accessToken, userGroup.group.id);
        this.viewModel.setCurrentGroup(group);
        appModel.setCurrentGroup(group);
      } else {
        appModel.setCurrentGroup(null);
      }
      this.viewModel.canCloseJoinTeam = true;
    } else if (user.hasInvitedGroup === true) {
      // show join team
      this.viewModel.showJoinTeamDialog();
    } else {
      // show create team
      this.viewModel.showCreateTeamDialog();
    }
  }

  @autobind
  signInClick() {
    const {history} = this.props;
    history.push('/login');
  }

  @autobind
  clickCreateTeam() {
    this.viewModel.showCreateTeamDialog(true);
  }

  @autobind
  async deletePost(postVm: PostViewModel) {
    await this.viewModel.deletePost(postVm);
  }

  @autobind
  showJoinTeamDialog() {
    const {showJoinTeamDialog} = this.viewModel;
    if (showJoinTeamDialog) {
      showJoinTeamDialog();
    }
  }

  @autobind
  showUpdateTeamInfoDialog() {
    const {showUpdateTeamInfoDialog} = this.viewModel;
    if (showUpdateTeamInfoDialog) {
      showUpdateTeamInfoDialog(true);
    }
  }

  @autobind
  showInviteTeammateDialog() {
    const {showInviteTeammateDialog} = this.viewModel;
    if (showInviteTeammateDialog) {
      showInviteTeammateDialog(true);
    }
  }

  @autobind
  showSeeAllMembersDialog() {
    const {showSeeAllMembersDialog} = this.viewModel;
    if (showSeeAllMembersDialog) {
      showSeeAllMembersDialog(true);
    }
  }

  @autobind
  renderHeader(): Node {
    return <CreatePostPanel addPostToFeeds={this.addPostToFeeds} />;
  }

  @autobind
  addPostToFeeds(post: PostModel) {
    const {viewModel} = this;
    if (post) {
      viewModel.addPostToFeeds(post);
    }
  }

  @autobind
  async loadMore() {
    await this.viewModel.getFeeds(this.viewModel.page + 1);
  }

  @autobind
  renderLoadMore(): Node {
    const {onLoading, firstTimeLoad} = this.viewModel;
    return onLoading === true && firstTimeLoad === false ? (
      <div className="load-more-spinner">
        <Spinner animation="border" variant="primary" />
      </div>
    ) : null;
  }

  @autobind
  renderContent(): Node {
    const {firstTimeLoad, feeds, onLoading} = this.viewModel;
    const {currentGroup} = appModel;

    if (firstTimeLoad) {
      return <LoadingContent />;
    }

    return (
      <Fragment>
        <Container id="main-container" className="main">
          <Row>
            <Col lg={8}>
              <div>
                {this.renderHeader()}
                <FeedList
                  deletePost={this.deletePost}
                  feeds={feeds}
                  showLoadingContent={onLoading && firstTimeLoad}
                  loadMore={this.loadMore}
                />
                {this.renderLoadMore()}
              </div>
            </Col>
            <Col lg={4}>
              <StickyContainer>
                <TeamInfo
                  showEditTeamProfile={this.showUpdateTeamInfoDialog}
                  showInviteTeammate={this.showInviteTeammateDialog}
                  showSeeAllMembers={this.showSeeAllMembersDialog}
                  team={currentGroup}
                />
              </StickyContainer>
            </Col>
          </Row>
        </Container>
      </Fragment>
    );
  }

  @autobind
  selectTeam(id: string) {
    if (id) {
      this.props.history.push(`/group/${id}`);
    } else {
      this.props.history.push('/');
    }
  }

  @autobind
  showCreateTeamDialog() {
    const user = appModel.currentUser;
    const {viewModel} = this;
    viewModel.showCreateTeamDialog(user.hasJoinedGroup);
  }

  render(): Node {
    const {
      canCloseDialog,
      canCloseInviteTeammateDialog,
      canCloseJoinTeam,
      closeInviteTeammateDialog,
      isLeadCurrentGroup,
      isOwnerCurrentGroup,
      showCreateTeam,
      showInviteTeammate,
      showInviteTeammateDialog,
      showJoinTeam
    } = this.viewModel;
    const {currentGroup, currentUser} = appModel;
    const {id: groupId} = currentGroup || {};
    return (
      <Fragment>
        <CreateTeamModal
          canCloseDialog={canCloseDialog}
          onClose={this.viewModel.closeCreateTeam}
          show={showCreateTeam}
          signInClick={this.signInClick}
        />
        <JoinTeamModal
          canCloseDialog={canCloseJoinTeam}
          createClick={this.showCreateTeamDialog}
          onClose={this.viewModel.closeJoinTeam}
          show={showJoinTeam}
          signInClick={this.signInClick}
          user={currentUser}
        />
        <UpdateTeamInfoModal
          canCloseDialog={canCloseDialog}
          onClose={this.viewModel.closeUpdateTeamInfo}
          show={this.viewModel.showUpdateTeamInfo}
          team={currentGroup}
        />
        <SeeAllMembersModal
          canCloseDialog={canCloseDialog}
          groupId={groupId}
          isLead={isLeadCurrentGroup}
          isOwner={isOwnerCurrentGroup}
          onClose={this.viewModel.closeSeeAllMembers}
          show={this.viewModel.showSeeAllMembers}
          showInviteTeammateDialog={showInviteTeammateDialog}
        />
        <InviteTeammateModal
          canCloseDialog={canCloseInviteTeammateDialog}
          groupId={groupId}
          onClose={closeInviteTeammateDialog}
          show={showInviteTeammate}
        />
        <Header
          addPostToFeeds={this.addPostToFeeds}
          clickCreateTeam={this.clickCreateTeam}
          editTeamProfile={this.showUpdateTeamInfoDialog}
          groups={this.viewModel.joinGroups}
          isLead={this.viewModel.isLeadCurrentGroup}
          selectTeam={this.selectTeam}
          selectedGroup={currentGroup}
          showInviteTeammateDialog={showInviteTeammateDialog}
          showJoinTeamDialog={this.showJoinTeamDialog}
        />
        {this.renderContent()}
      </Fragment>
    );
  }
}

export default Home;
