// @flow
import * as React from "react";
import { Container } from "react-bootstrap";
import { Group } from "models";
import autobind from "autobind-decorator";
import { renderGroupAvatar } from "../../../components/baseComponents/svg/Avatar";
import "./TeamAbout.scss";

type PropsType = {
  team: Group,
  isLeader: boolean,
  showEditTeamProfile: () => void
};

type StateType = {};

class TeamAbout extends React.Component<PropsType, StateType> {
  @autobind
  showEditTeamProfile(e) {
    e.preventDefault();
    const { showEditTeamProfile } = this.props;
    showEditTeamProfile();
  }
  render(): React.Node {
    const {
      team: { name, description, avatar, defaultAvatar },
      isLeader
    } = this.props;
    return (
      <Container className="right-panel team-about">
        <div className="panel-header">
          <span>About Us</span>
          {isLeader && (
            <a className="edit-profile" href="" onClick={this.showEditTeamProfile}>
              Edit Profile
            </a>
          )}
        </div>
        <div className="team-info">
          <div className="team-avatar">{renderGroupAvatar(name, avatar, defaultAvatar, 64)}</div>
          <div className="team-name">{name}</div>
        </div>
        <div className="description">{description}</div>
      </Container>
    );
  }
}

export default TeamAbout;
