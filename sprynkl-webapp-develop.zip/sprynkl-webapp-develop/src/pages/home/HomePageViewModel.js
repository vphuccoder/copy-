// @flow

import {observable, action, flow, runInAction, computed} from 'mobx';
import autobind from 'autobind-decorator';
import {BasePageViewModel} from '../BasePageViewModel';
import {postService, groupService} from '../../services/index';
import {appModel} from '../../models/app-model';
import {FeedModel, Group, PostModel, ASK, VOICE, THANKS} from '../../models';
import {PAGE_SIZE} from '../../models/constants/system';
import {PostViewModel} from '../../components/feeds';

class HomePageViewModel extends BasePageViewModel {
  @observable
  showCreateTeam: boolean = false;

  @observable
  canCloseDialog: boolean = false;

  @observable
  showJoinTeam: boolean = false;

  @observable
  onLoading: boolean = false;

  @observable
  firstTimeLoad: boolean = true;

  @observable
  showUpdateTeamInfo: boolean = false;

  @observable
  showInviteTeammate: boolean = false;

  @observable
  showSeeAllMembers: boolean = false;

  @observable
  canCloseInviteTeammateDialog: boolean = false;

  @observable
  showProfile: boolean = false;

  @observable
  feeds: Array = [];

  @observable
  joinGroups: Array = [];

  @observable
  group: Group = null;

  @observable
  hasMore: boolean = true;

  page: number = 1;

  @action
  setCurrentGroup(group: Group) {
    this.group = group;
  }

  @computed
  get isLeadCurrentGroup(): boolean {
    if (this.group) {
      const {currentUser} = appModel;
      return currentUser.isLeadGroup(this.group.id);
    }
    return false;
  }

  @computed
  get isOwnerCurrentGroup(): boolean {
    if (this.group) {
      const {currentUser} = appModel;
      return currentUser.isGroupOwner(this.group.id);
    }
    return false;
  }

  @action
  async checkLogin() {
    await appModel.checkLogdedIn();
  }

  @observable
  canCloseJoinTeam: boolean = false;

  @autobind
  @action
  showCreateTeamDialog(canCloseDialog: boolean = false) {
    this.showJoinTeam = false;
    this.showCreateTeam = true;
    this.canCloseDialog = canCloseDialog;
  }

  @autobind
  @action
  closeJoinTeam() {
    this.showJoinTeam = false;
  }

  @autobind
  @action
  closeCreateTeam() {
    this.showCreateTeam = false;
  }

  @autobind
  @action
  showUpdateTeamInfoDialog(canCloseDialog: boolean = false) {
    this.showUpdateTeamInfo = true;
    this.canCloseDialog = canCloseDialog;
  }

  @autobind
  @action
  closeUpdateTeamInfo() {
    this.showUpdateTeamInfo = false;
  }

  @autobind
  @action
  showInviteTeammateDialog(canCloseDialog: boolean = false) {
    this.showInviteTeammate = true;
    this.canCloseInviteTeammateDialog = canCloseDialog;
  }

  @autobind
  @action
  closeInviteTeammateDialog() {
    this.showInviteTeammate = false;
  }

  @autobind
  @action
  showSeeAllMembersDialog(canCloseDialog: boolean = false) {
    this.showSeeAllMembers = true;
    this.canCloseDialog = canCloseDialog;
  }

  @autobind
  @action
  closeSeeAllMembers() {
    this.showSeeAllMembers = false;
  }

  @autobind
  @action
  closeProfileDialog() {
    this.showProfile = false;
  }

  @action
  setJoinGroups(groups: []) {
    this.joinGroups = groups;
  }

  @autobind
  @action
  showJoinTeamDialog(canCloseDialog: boolean = false) {
    this.showJoinTeam = true;
    this.canCloseDialog = canCloseDialog;
  }

  @autobind
  @action
  showProfileDialog(canCloseDialog: boolean = false) {
    this.showProfile = true;
    this.canCloseDialog = canCloseDialog;
  }

  @action
  getFeeds = flow(function*(page: number = 1): Promise {
    if (this.onLoading === true) {
      return;
    }

    if (page === 1) {
      // reload
      this.page = 1;
      this.hasMore = true;
    }

    if (this.hasMore === false) {
      return;
    }

    this.onLoading = true;

    try {
      const newFeeds = [];
      const data = {
        types: [ASK, VOICE, THANKS],
        pageSize: PAGE_SIZE,
        pageNumber: page
      };

      if (this.group) {
        data.groupId = this.group.id;
        const results = yield postService.filterFeed(appModel.currentToken.accessToken, data);
        const res = FeedModel.map(results.data);

        if (res && res.posts.length > 0) {
          res.posts.forEach((p: PostModel) => {
            p.setGroup(this.group);
          });
          newFeeds.push(...res.posts.map((p: PostModel): PostViewModel => PostViewModel.toViewModel(p)));
          this.page = page;
        }
      } else {
        const results = yield postService.filterFeed(appModel.currentToken.accessToken, data);
        const res = FeedModel.map(results.data);
        if (res && res.posts.length > 0) {
          const uniqueGroupIds = this.getUniqueGroupIds(res.posts);
          const groups = yield this.fetchUniqueGroups(uniqueGroupIds);
          res.posts.forEach((p: PostModel) => {
            const group = groups.find((g: Group): boolean => g.id === p.group.id);
            if (group) {
              p.setGroup(group);
            }
          });
          newFeeds.push(...res.posts.map((p: PostModel): PostViewModel => PostViewModel.toViewModel(p)));
          this.page = page;
        }
      }

      if (page === 1) {
        this.feeds = [];
      }

      if (newFeeds.length <= 0) {
        this.hasMore = false;
      }

      // Check new feeds already on current feeds before push to list
      newFeeds.forEach((item: {}) => {
        const index = this.feeds.findIndex(
          (itemSource: {}): boolean => {
            const postItem = item.post || {};
            const postItemSource = itemSource.post || {};
            return postItem.id === postItemSource.id;
          }
        );

        if (index < 0) {
          this.feeds.push(item);
        }
      });

      this.onLoading = false;
    } finally {
      this.firstTimeLoad = false;
    }
  });

  @autobind
  getUniqueGroupIds(posts: PostModel[]): string[] {
    const groupIds: string[] = [];
    posts.forEach((p: PostModel) => {
      if (groupIds.indexOf(p.group.id) === -1) {
        groupIds.push(p.group.id);
      }
    });
    return groupIds;
  }

  @autobind
  async fetchUniqueGroups(uniqueGroups: string[]): Promise<Group[]> {
    const allRequests = uniqueGroups.map(
      (groupId: string): Promise<Group> => groupService.getGroup(appModel.currentToken.accessToken, groupId)
    );
    return await Promise.all(allRequests);
  }

  @action
  async selectedGroupById(id: string) {
    if (!id) {
      appModel.setCurrentGroup(null);
      this.group = null;
      this.feeds = [];
      this.getFeeds(1);
    } else {
      this.showLoading();
      const group = await groupService.getGroup(appModel.currentToken.accessToken, id);
      appModel.setCurrentGroup(group);
      this.group = group;
      this.feeds = [];
      this.hideLoading();
      this.getFeeds(1);
    }
  }

  @action
  async deletePost(selectedPost: {}): Promise {
    try {
      this.showLoading();
      const {accessToken} = appModel.currentToken;
      await postService.deletePost(accessToken, selectedPost.post.id);

      const index = this.feeds.indexOf(selectedPost);

      runInAction(() => {
        this.feeds.splice(index, 1);
        this.hideLoading();
      });
    } catch (ex) {
      this.hideLoading();
      this.handleError(ex, true);
    }
  }

  @action
  addPostToFeeds(post: PostModel) {
    const postViewModel = PostViewModel.toViewModel(post);
    const {group} = this;
    if (post && (!group || (group && post.group && group.id === post.group.id))) {
      this.feeds.unshift(postViewModel);
    }
  }
}

export {HomePageViewModel};
