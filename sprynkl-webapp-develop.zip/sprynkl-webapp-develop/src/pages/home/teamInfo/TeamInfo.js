// @flow
import React, {Component, Fragment} from 'react';
import type {Node} from 'react';
import {observer} from 'mobx-react';
import {Group} from '../../../models';
import {appModel} from '../../../models/app-model';
import TeamAbout from '../teamAbout/TeamAbout';
import TeamMember from '../teamMember/TeamMember';

type PropsType = {
  team: Group,
  showEditTeamProfile: () => void,
  showSeeAllMembers: () => void,
  showInviteTeammate: () => void
};

type StateType = {};

@observer
class TeamInfo extends Component<PropsType, StateType> {
  render(): Node {
    const {
      currentUser: {id: currentUserId}
    } = appModel;
    const {team, showEditTeamProfile, showInviteTeammate, showSeeAllMembers} = this.props;
    if (!team) return null;
    const isLeader = team.isLeader(currentUserId);
    const isOwner = team.isOwner(currentUserId);

    return (
      <Fragment>
        <div>
          <TeamAbout team={team} isLeader={isLeader} showEditTeamProfile={showEditTeamProfile} />
        </div>
        <div>
          <TeamMember
            team={team}
            isLeader={isLeader}
            isOwner={isOwner}
            showSeeAllMembers={showSeeAllMembers}
            showInviteTeammate={showInviteTeammate}
          />
        </div>
      </Fragment>
    );
  }
}

export default TeamInfo;
