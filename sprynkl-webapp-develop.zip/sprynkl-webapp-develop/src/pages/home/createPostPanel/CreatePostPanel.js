// @flow
import React, {Component} from 'react';
import {Container, Row, Col} from 'react-bootstrap';
import {AskIcon, ThanksIcon, VoiceIcon} from '../../../components/baseComponents/svg/Svg';
import './CreatePostPanel.scss';
import {ModalConsumer} from '../../../components/context/ModalContext';
import {CreateAsk, CreateThanks, CreateVoice} from '../../../components/modals';
import {DISCARD_ALERT_MESSAGE} from '../../../models/constants/string-constant';
import autobind from 'autobind-decorator';

type PropsType = {};

type StateType = {
  showAlert: boolean
};

class CreatePostPanel extends Component<PropsType, StateType> {
  constructor(props: PropsType) {
    super(props);
    this.state = {
      showAlert: false
    };
  }

  @autobind
  showAlert(value: boolean) {
    if (this.state.showAlert !== value) {
      this.setState({showAlert: value});
    }
  }

  @autobind
  onHide(hideModal: function, alertMessage: string) {
    if (this.state.showAlert) {
      if (!confirm(alertMessage)) {
        return;
      }
    }
    hideModal();
    this.setState({showAlert: false});
  }

  render(): React.Node {
    const {addPostToFeeds} = this.props;
    const {showAlert} = this;

    return (
      <Container className="left-panel create-post-panel">
        <Row>
          <Col>
            <ModalConsumer>
              {({showModal, hideModal}: {}): ReactNode => (
                <a
                  className="create-voice"
                  onClick={(): {} =>
                    showModal(CreateVoice, {
                      hideModal: () => {
                        this.onHide(hideModal, DISCARD_ALERT_MESSAGE);
                      },
                      showAlert,
                      alertMessage: DISCARD_ALERT_MESSAGE,
                      header: 'Create a voice',
                      dialogClassName: 'create-voice-dialog',
                      addPostToFeeds: addPostToFeeds
                    })
                  }
                >
                  <VoiceIcon />
                  <span>Share Voice</span>
                </a>
              )}
            </ModalConsumer>
          </Col>
          <div className="vertical-separator" />
          <Col>
            <ModalConsumer>
              {({showModal, hideModal}: {}): ReactNode => (
                <a
                  className="create-thanks"
                  onClick={(): {} =>
                    showModal(CreateThanks, {
                      hideModal: () => {
                        this.onHide(hideModal, DISCARD_ALERT_MESSAGE);
                      },
                      showAlert,
                      alertMessage: DISCARD_ALERT_MESSAGE,
                      header: 'Say thanks',
                      dialogClassName: 'create-thanks-dialog',
                      addPostToFeeds: addPostToFeeds
                    })
                  }
                >
                  <ThanksIcon />
                  <span>Say thanks</span>
                </a>
              )}
            </ModalConsumer>
          </Col>
          <div className="vertical-separator" />
          <Col>
            <ModalConsumer>
              {({showModal, hideModal}: {}): ReactNode => (
                <a
                  className="create-ask"
                  onClick={(): {} =>
                    showModal(CreateAsk, {
                      hideModal: () => {
                        this.onHide(hideModal, DISCARD_ALERT_MESSAGE);
                      },
                      showAlert,
                      alertMessage: DISCARD_ALERT_MESSAGE,
                      header: 'Ask a question',
                      dialogClassName: 'create-ask-dialog',
                      addPostToFeeds: addPostToFeeds
                    })
                  }
                >
                  <AskIcon />
                  <span>Ask a question</span>
                </a>
              )}
            </ModalConsumer>
          </Col>
        </Row>
      </Container>
    );
  }
}

export default CreatePostPanel;
