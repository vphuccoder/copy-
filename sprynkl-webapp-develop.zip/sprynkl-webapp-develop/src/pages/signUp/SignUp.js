import autobind from 'autobind-decorator';
import {URL_PRIVACY_POLICY, URL_TERM_OF_USE} from '../../configs';
import IcomoonReact from 'icomoon-react';
import {
  EMAIL_EXISTED,
  INVALID_EMAIL_FORMAT,
  INVALID_FULL_NAME_FORMAT,
  INVALID_PASSWORD_FORMAT
} from '../../models/constants/string-constant';
import React, {Component, Fragment} from 'react';
import {Button, Col, Container, Form, Row} from 'react-bootstrap';
import {emailReg, passwordRegex, fullnameReg, hasEmoji, hasSpecialCharacter} from '../../utils/regex';
import iconSet from '~/selection.json';
import {Logo} from '../../components/baseComponents/svg/Svg';
import Footer from '../../components/footer/Footer';
import GoogleSignIn from '../../components/google/GoogleSignIn';
import {icons} from '../../components/themes/Icons';
import {ERROR_CODE} from '../../models/constants';
import {userService} from '../../services';
import LeftCarousel from './leftCarousel/LeftCarousel';
import WaitingConfirmationScreen from './waitingConfirmationScreen/WaitingConfirmationScreen';
import './SignUp.scss';

class StartUp extends Component {
  state = {
    accountExisted: false,
    email: '',
    emailInvalidMessage: INVALID_EMAIL_FORMAT,
    fullName: '',
    isEmailSent: false,
    isValidEmail: true,
    isValidPassword: true,
    isValidFullName: true,
    password: '',
    passwordType: 'password'
  };

  @autobind
  validateForm() {
    const {email, password, fullName} = this.state;
    const isValidPassword = passwordRegex.test(password);
    const isValidEmail = emailReg.test(email);
    const isValidFullName = fullnameReg.test(fullName) && !hasEmoji(fullName) && !hasSpecialCharacter(fullName);
    return {
      isValidFullName,
      isValidEmail,
      isValidPassword
    };
  }

  @autobind
  async signUp(e) {
    e.preventDefault();
    e.stopPropagation();

    const {isValidEmail, isValidPassword, isValidFullName} = this.validateForm();
    if (!isValidPassword || !isValidEmail || !isValidFullName) {
      this.setState({
        emailInvalidMessage: INVALID_EMAIL_FORMAT,
        isValidEmail,
        isValidPassword,
        isValidFullName
      });
      return;
    }

    try {
      await userService.signUp(this.state);
      this.setState({
        isEmailSent: true
      });
    } catch ({data}) {
      if (data && data.key === ERROR_CODE.user_existing) {
        this.setState({
          emailInvalidMessage: EMAIL_EXISTED,
          isValidEmail: false,
          isValidPassword
        });
      }
    }
  }

  @autobind
  onFieldChanged(e) {
    this.setState({
      [e.target.name]: e.target.value
    });
  }

  @autobind
  toggleShowPassword() {
    this.setState(({passwordType}) => {
      const password = 'password';
      const text = 'text';
      const newType = passwordType === password ? text : password;
      return {
        passwordType: newType
      };
    });
  }

  renderSignUpForm() {
    const {
      email,
      emailInvalidMessage,
      fullName,
      isValidEmail,
      isValidPassword,
      password,
      passwordType,
      isValidFullName
    } = this.state;
    return (
      <Fragment>
        <Logo height={40} />
        <h3 className="title">Get started absolutely free</h3>
        <p className="info">No credit card needed.</p>
        <Form className="sign-up-form" onSubmit={this.signUp}>
          <Form.Group>
            <Form.Control
              isInvalid={!isValidFullName}
              name="fullName"
              onChange={this.onFieldChanged}
              placeholder="Your full name"
              required
              value={fullName}
            />
            <Form.Control.Feedback type="invalid"> {INVALID_FULL_NAME_FORMAT}</Form.Control.Feedback>
          </Form.Group>
          <Form.Group>
            <Form.Control
              isInvalid={!isValidEmail}
              name="email"
              onChange={this.onFieldChanged}
              placeholder="Your email address"
              required
              type="email"
              value={email}
            />
            <Form.Control.Feedback type="invalid"> {emailInvalidMessage}</Form.Control.Feedback>
          </Form.Group>
          <Form.Group>
            <Form.Control
              isInvalid={!isValidPassword}
              name="password"
              onChange={this.onFieldChanged}
              placeholder="Your password"
              required
              type={passwordType}
              value={password}
            />
            <span className="show-password-icon" onClick={this.toggleShowPassword}>
              {passwordType === 'text' ? (
                <IcomoonReact color="#282c2e" icon={icons.visible} iconSet={iconSet} size={24} />
              ) : (
                <IcomoonReact color="#282c2e" icon={icons.invisible} iconSet={iconSet} size={24} />
              )}
            </span>
            <Form.Control.Feedback type="invalid">{INVALID_PASSWORD_FORMAT}</Form.Control.Feedback>
          </Form.Group>
          <Button className="sign-up-button" variant="primary" onClick={this.signUp}>
            {'Continue'}
          </Button>
        </Form>
        <Form.Group>
          <h6 className="seperate-line">
            <span className="text">or</span>
          </h6>
          <GoogleSignIn />
        </Form.Group>
      </Fragment>
    );
  }

  renderOtherInfo() {
    return (
      <Fragment>
        <Form.Group>
          <span className="agree-statement">
            {'By clicking "Continue" I agree to Sprynkl’s'}
            <a href={URL_TERM_OF_USE}>
              <span> Terms of Service </span>
            </a>
            and
            <a href={URL_PRIVACY_POLICY}>
              <span> Privacy Policy </span>
            </a>
          </span>
        </Form.Group>
        <Form.Group className="sign-in-group">
          <p>Already have an account?</p>
          <a href="./login">
            <span>{'Sign in'}</span>
          </a>
        </Form.Group>
      </Fragment>
    );
  }

  renderSignUpScreen() {
    return (
      <Container className="sign-up-panel">
        {this.renderSignUpForm()}
        {this.renderOtherInfo()}
        <Footer />
      </Container>
    );
  }

  render() {
    const {isEmailSent, email} = this.state;
    return (
      <div className="sign-up">
        {isEmailSent ? (
          <WaitingConfirmationScreen email={email} />
        ) : (
          <Row className="sign-up-container">
            <Col lg="6" className="d-none d-lg-block">
              <LeftCarousel />
            </Col>
            <Col lg="6">{this.renderSignUpScreen()}</Col>
          </Row>
        )}
      </div>
    );
  }
}
export default StartUp;
