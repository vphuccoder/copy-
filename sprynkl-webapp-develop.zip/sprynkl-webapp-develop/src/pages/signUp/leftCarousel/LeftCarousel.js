import React from "react";
import { Form, Col, Row, Carousel } from "react-bootstrap";
import autobind from "autobind-decorator";
import "./LeftCarousel.scss";
import "../../../assets/images/sign-up-img-1.png";
import "../../../assets/images/sign-up-img-2.png";
import "../../../assets/images/sign-up-img-3.png";

class LeftCarousel extends React.Component {
  constructor(props, context) {
    super(props, context);

    this.state = {
      index: 0,
      direction: null,
    };
  }

  @autobind
  handleSelect(selectedIndex, e) {
    this.setState({
      index: selectedIndex,
      direction: e.direction,
    });
  }

  render() {
    const { index, direction } = this.state;

    return (
      <Carousel
        activeIndex={index}
        direction={direction}
        onSelect={this.handleSelect}
        className="signup-left-carousel"
      >
        <Carousel.Item>
          <Carousel.Caption>
            <h3 className="caption-1">Find and fix problems faster with anonymous posts that give your teammates a new voice</h3>
          </Carousel.Caption>
          <div className="image-container">
            <img
              src="/assets/images/sign-up-img-1.png"
              alt="Sign up"
            />
          </div>
        </Carousel.Item>
        <Carousel.Item>
          <Carousel.Caption>
            <h3 className="caption-2">Make over-thanking a team feature so everybody supports each other</h3>
          </Carousel.Caption>
          <div className="image-container">
            <img
              src="/assets/images/sign-up-img-2.png"
              alt="Sign up"
            />
          </div>
        </Carousel.Item>
        <Carousel.Item>
          <Carousel.Caption>
            <h3 className="caption-3">Give and get input at any time so your team is always growing</h3>
          </Carousel.Caption>
          <div className="image-container">
            <img
              src="/assets/images/sign-up-img-3.png"
              alt="Sign up"
            />
          </div>
        </Carousel.Item>

      </Carousel>
    );
  }
}

export default LeftCarousel;
