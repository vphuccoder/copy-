import autobind from 'autobind-decorator';
import {Logo} from 'components/baseComponents/svg/Svg';
import Footer from 'components/footer/Footer';
import {icons} from 'components/themes/Icons';
import IcomoonReact from 'icomoon-react';
import React, {Component} from 'react';
import {Alert, Button, Container, Spinner} from 'react-bootstrap';
import {userService} from 'services';
import iconSet from '~/selection.json';
import './WaitingConfirmationScreen.scss';

class WaitingConfirmationScreen extends Component {
  state = {
    reSending: false,
    showAlertMessage: false
  };

  @autobind
  async sendVerifyEmail() {
    const {email} = this.props;

    try {
      await userService.resendVerifyEmail(email);

      this.setState({reSending: false, showAlertMessage: true});
    } catch {
      this.setState({
        reSending: false
      });
    }
  }

  @autobind
  resendVerifyEmail() {
    this.setState(
      () => ({
        reSending: true
      }),
      this.sendVerifyEmail
    );
  }

  @autobind
  closeAlertMessage() {
    this.setState({showAlertMessage: false});
  }

  render() {
    const {email} = this.props;
    const {reSending, showAlertMessage} = this.state;
    return (
      <div className="waiting-confirmation">
        <Container>
          <Alert dismissible onClose={this.closeAlertMessage} show={showAlertMessage} variant="success">
            <IcomoonReact color="#52c41a" icon={icons.checkAlt} iconSet={iconSet} size={14} />
            <span> Email sent!</span>
          </Alert>
          <Logo height={40} />
          <h3>{'Please verify your email'}</h3>
          <p className="info">{`We just emailed your verification link to ${email}.`}</p>
          <Button className="resend-button" disabled={reSending} onClick={!reSending ? this.resendVerifyEmail : null}>
            {reSending && <Spinner animation="border" aria-hidden="true" as="span" role="status" size="sm" />}
            {'Resend email'}
          </Button>
          <h6 className="separator">
            <span>or</span>
          </h6>
          <a className="back-to-sign-up" href="./signup">
            <span>{'Sign up with another email address'}</span>
          </a>
          <Footer />
        </Container>
      </div>
    );
  }
}

export default WaitingConfirmationScreen;
