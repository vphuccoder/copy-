import autobind from 'autobind-decorator';
import IcomoonReact from 'icomoon-react';
import {appModel} from 'models/app-model';
import queryString from 'query-string';
import React, {Component} from 'react';
import {Alert, Button, Container} from 'react-bootstrap';
import {withRouter} from 'react-router';
import {userService} from 'services';
import iconSet from '~/selection.json';
import {Logo} from '../../../components/baseComponents/svg/Svg';
import Footer from '../../../components/footer/Footer';
import {icons} from '../../../components/themes/Icons';
import './VerifyAccount.scss';

@withRouter
class VerifyAccount extends Component {
  constructor(props) {
    super(props);
    this.queryValues = this.getQueryValues();
  }
  state = {
    isLinkExpired: false,
    reSending: false,
    showAlertMessage: false
  };

  async componentDidMount() {
    const {code: pin, email} = this.queryValues;
    const {history} = this.props;
    try {
      const {code: verifyCode} = await userService.verifyAccount({
        email,
        pin
      });
      const {deviceId, fcmToken} = appModel;
      const token = await userService.oauth(email, verifyCode, deviceId, fcmToken, true);
      const user = await userService.getUser(token.accessToken);
      if (token && user) {
        appModel.setCurrentUser(user);
        appModel.setCurrentToken(token);
        history.push('/');
      }
    } catch {
      this.setState({
        isLinkExpired: true
      });
    }
  }

  @autobind
  getQueryValues() {
    return queryString.parse(this.props.location.search);
  }

  @autobind
  async sendVerifyEmail() {
    const {email} = this.queryValues;

    try {
      await userService.resendVerifyEmail(email);

      this.setState({reSending: false, showAlertMessage: true});
    } catch {
      this.setState({
        reSending: false
      });
    }
  }

  @autobind
  resendVerifyEmail() {
    this.setState(
      () => ({
        reSending: true
      }),
      this.sendVerifyEmail
    );
  }

  @autobind
  closeAlertMessage() {
    this.setState({showAlertMessage: false});
  }

  render() {
    const {isLinkExpired, reSending, showAlertMessage} = this.state;
    return (
      isLinkExpired && (
        <div className="waiting-confirmation">
          <Container>
            <Alert
              dismissible
              onClose={this.closeAlertMessage}
              show={showAlertMessage}
              variant="success"
            >
              <IcomoonReact color="#52c41a" icon={icons.checkAlt} iconSet={iconSet} size={14} />
              <span> Email sent!</span>
            </Alert>
            <Logo height={40} />
            <h3>{'Verification link has expired'}</h3>
            <p className="info">{'Please resend a new verification link from your account.'}</p>
            <Button
              className="verify-account-button"
              disabled={reSending}
              onClick={!reSending ? this.resendVerifyEmail : null}
            >
              {reSending ? 'Sending...' : 'Resend email'}
            </Button>
            <Footer />
          </Container>
        </div>
      )
    );
  }
}

export default VerifyAccount;
