// @flow
import React, {Component} from 'react';
import {PageNotFoundIcon} from '../../components/baseComponents/svg/Svg';
import {PAGE_NOT_FOUND} from '../../models/constants/string-constant';
import './NotFound.scss';

class NotFound extends Component {
  render(): React.Node {
    return (
      <div className="page-not-found">
        <PageNotFoundIcon />
        <div className="description">{PAGE_NOT_FOUND}</div>
      </div>
    );
  }
}

export default NotFound;
