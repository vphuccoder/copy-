// @flow

import React, {Component} from 'react';
import {Col, Nav, Row, Tab} from 'react-bootstrap';
import {AccountSetting, EditProfile, NotificationSetting, SendFeedback} from './settingsTab';

class Body extends Component {
  render() {
    return (
      <div className="settings container">
        <Tab.Container defaultActiveKey="editProfile" id="left-menu">
          <Row className="setting-body">
            <Col sm={3}>
              <div className="flex-column left-menu">
                <Nav className="flex-column">
                  <Nav.Item>
                    <Nav.Link eventKey="editProfile">Edit Profile</Nav.Link>
                  </Nav.Item>
                  <Nav.Item>
                    <Nav.Link eventKey="accountSetting">Account</Nav.Link>
                  </Nav.Item>
                  <Nav.Item>
                    <Nav.Link eventKey="notificationSetting">Notifications</Nav.Link>
                  </Nav.Item>
                  <Nav.Item>
                    <Nav.Link eventKey="sendFeedback">Send Us Feedback</Nav.Link>
                  </Nav.Item>
                </Nav>
              </div>
            </Col>
            <Col sm={9}>
              <Tab.Content>
                <Tab.Pane eventKey="editProfile">
                  <EditProfile />
                </Tab.Pane>
                <Tab.Pane eventKey="accountSetting">
                  <AccountSetting />
                </Tab.Pane>
                <Tab.Pane eventKey="notificationSetting">
                  <NotificationSetting />
                </Tab.Pane>
                <Tab.Pane eventKey="sendFeedback">
                  <SendFeedback />
                </Tab.Pane>
              </Tab.Content>
            </Col>
          </Row>
        </Tab.Container>
      </div>
    );
  }
}

export default Body;
