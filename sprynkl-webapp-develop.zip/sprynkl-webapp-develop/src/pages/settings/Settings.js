// @flow
import React, {Component} from 'react';
import {Body, Header} from './';
import './Settings.scss';
class Settings extends Component {
  render(): React.Node {
    return (
      <div className="setting-pages">
        <Header />
        <Body />
      </div>
    );
  }
}

export default Settings;
