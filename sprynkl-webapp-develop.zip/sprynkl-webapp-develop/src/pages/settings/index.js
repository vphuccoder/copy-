import Body from './Body';
import Header from './Header';
import Settings from './Settings';
export {Body, Header, Settings};
