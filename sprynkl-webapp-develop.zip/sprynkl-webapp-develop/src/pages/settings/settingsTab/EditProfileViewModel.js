// @flow
import {observable, computed} from 'mobx';
import {action} from 'popmotion';
import {User} from '../../../models';
import {appModel} from '../../../models/app-model';
import {BasePageViewModel} from '../../../pages/BasePageViewModel';
import {fileService, userService} from '../../../services';
import {UPDATE_PROFILE_SUCCESSFULLY} from '../../../models/constants/string-constant';
import {hasSpecialCharacter, hasEmoji, phoneReg} from '../../../utils/regex';
export const GENDERS = [
  {value: 'male', label: 'Male'},
  {value: 'female', label: 'Female'},
  {value: 'not specified', label: 'Not Specified'}
];
class EditProfileViewModel extends BasePageViewModel {
  id: string = '';
  userStatus: string = '';
  email: string = '';
  defaultAvatar: string = '';

  @observable
  avatar: string = '';

  @observable
  about: string = '';

  @observable
  bio: string = '';

  @observable
  team: string = '';

  @observable
  fullName: string = '';

  @observable
  nickName: string = '';

  @observable
  nickName: string = '';

  @observable
  office: string = '';

  @observable
  phone: string = '';

  @observable
  position: string = '';

  @observable
  skype: string = '';

  @observable
  birthday: Date;

  @observable
  gender: string = 'male';

  @observable
  isOpenAvatarEditor: boolean = false;

  @observable
  avatarUrl: string = '';

  editedAvatarFile: File;

  avatarFile: File;

  @observable
  isLoading: boolean = false;

  @observable
  disabled: boolean = true;

  @observable
  fullNameInvalid: boolean = false;

  @observable
  phoneInvalid: boolean = false;

  @computed
  get isValidForm() {
    return !this.fullNameInvalid && !this.phoneInvalid;
  }

  @computed
  get genderLabel(): string {
    const selectedGender = GENDERS.find(
      (gender: {value: string, label: string}) => gender.value === this.gender.toLowerCase()
    );
    return selectedGender ? selectedGender.label : '';
  }

  constructor() {
    super();
    const {currentUser} = appModel;
    this.populateData(currentUser);
  }

  @action
  populateData(data: User = {}) {
    const {instantMessage, office, privateInfo} = data;
    this.id = data.id;
    this.userStatus = data.userStatus;
    this.email = data.email;
    this.defaultAvatar = data.defaultAvatar;

    this.avatar = data.avatar;
    this.team = data.team;
    this.about = data.about;
    this.bio = data.bio;
    this.fullName = data.fullName;
    this.nickName = data.nickName;
    this.office = office.name;
    this.phone = data.phone;
    this.position = data.position;
    this.skype = instantMessage.skype;

    this.birthday = privateInfo.birthday ? new Date(privateInfo.birthday) : null;
    this.gender = privateInfo.gender || '';
  }

  @action
  updateFullName(fullName: string) {
    this.fullNameInvalid = false;
    this.fullName = fullName;
    this.disabled = false;
  }

  @action
  updateNickName(nickName: string) {
    this.nickName = nickName;
    this.disabled = false;
  }

  @action
  updateBio(bio: string) {
    this.bio = bio;
    this.disabled = false;
  }

  @action
  updatePosiotion(position: string) {
    this.position = position;
    this.disabled = false;
  }

  @action
  updateTeam(team: string) {
    this.team = team;
    this.disabled = false;
  }

  @action
  updateOffice(office: string) {
    this.office = office;
    this.disabled = false;
  }

  @action
  updateAboutMe(aboutMe: string) {
    this.about = aboutMe;
    this.disabled = false;
  }

  @action
  updateSkype(skype: string) {
    this.skype = skype;
    this.disabled = false;
  }

  @action
  updatePhone(phone: string) {
    this.phoneInvalid = false;
    this.phone = phone;
    this.disabled = false;
  }

  @action
  updateBirthday(birthday: Date) {
    this.birthday = birthday;
    this.disabled = false;
  }

  @action
  updateGender(gender: string) {
    this.gender = gender;
    this.disabled = false;
  }

  openAvatarEditor() {
    this.isOpenAvatarEditor = true;
  }

  closeAvatarEditor() {
    this.isOpenAvatarEditor = false;
  }

  @action
  completeEditAvatar(file: File) {
    this.editedAvatarFile = file;
    this.avatar = URL.createObjectURL(file);
    this.closeAvatarEditor();
    this.disabled = false;
  }

  @action
  updateAvatar(file: ?File) {
    if (file) {
      this.avatarFile = file;
      this.openAvatarEditor();
    }
  }

  buildDataForSave() {
    const {fullName, team, about, bio, nickName, phone, office, skype, position, gender, birthday, avatar} = this;
    return {
      fullName: fullName.trim(),
      team,
      about,
      bio,
      nickName,
      phone,
      position,
      office: {name: office},
      instantMessage: {skype},
      gender: gender,
      birthday: birthday ? birthday.setHours(0, 0, 0, 0) : ''
    };
  }

  @action
  clean() {
    this.editedAvatarFile = undefined;
    this.avatarFile = undefined;
  }

  @action
  validate() {
    if (this.fullName.trim() === '' || hasSpecialCharacter(this.fullName) || hasEmoji(this.fullName)) {
      this.fullNameInvalid = true;
    }

    if (this.phone.trim() !== '' && !phoneReg.test(this.phone)) {
      this.phoneInvalid = true;
    }
  }

  async saveProfile() {
    this.validate();
    if (this.isValidForm) {
      this.isLoading = true;
      const userProfile = this.buildDataForSave();
      try {
        const {currentToken} = appModel;
        const {accessToken} = currentToken;
        if (this.editedAvatarFile) {
          const {name: fileName, type: fileType} = this.editedAvatarFile;
          const file = await fileService.uploadFile(accessToken, this.editedAvatarFile, fileName, fileType);
          if (file && file.id) {
            userProfile.avatar = file.id;
          }
        }

        const user = await userService.updateUser(accessToken, userProfile);
        appModel.setCurrentUser(user);
        appModel.alertMessageViewModel.showAlert(UPDATE_PROFILE_SUCCESSFULLY);
        this.clean();
        this.isLoading = false;
      } catch (ex) {
        this.handleError(ex, false);
        this.isLoading = false;
      }
    }
  }
}
export default EditProfileViewModel;
