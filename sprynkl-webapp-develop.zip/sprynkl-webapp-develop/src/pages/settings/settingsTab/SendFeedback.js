// @flow

import React, {Component} from 'react';
import {Button, Form} from 'react-bootstrap';
class SendFeedback extends Component {
  render() {
    return (
      <div className="send-feedback">
        <div className="tab-header">
          <span className="title">Send Us Feedback</span>
        </div>
        <div className="content">
          <div className="description">
            <span>How can we make Sprynkl better for you?</span>
          </div>
          <Form>
            <Form.Group>
              <Form.Control
                as="textarea"
                className="text-body padding-0 paddingTopBottom-8"
                name="feedback-content"
                rows={3}
              />
            </Form.Group>
            <Button className="float-right">Send </Button>
          </Form>
        </div>
      </div>
    );
  }
}

export default SendFeedback;
