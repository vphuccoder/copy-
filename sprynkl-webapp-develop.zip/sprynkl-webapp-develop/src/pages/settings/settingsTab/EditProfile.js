// @flow
import autobind from 'autobind-decorator';
import {observer} from 'mobx-react';
import React, {Component} from 'react';
import {Button, Col, Dropdown, DropdownButton, Form, Row, Spinner} from 'react-bootstrap';
import {DatePicker} from '../../../components/baseComponents';
import Icon from '../../../components/baseComponents/Icon';
import AvatarEditor from '../../../components/baseComponents/avatarEditor';
import {renderUserAvatar} from '../../../components/baseComponents/svg/Avatar';
import {isContains} from '../../../utils/utils';
import './EditProfile.scss';
import EditProfileViewModel, {GENDERS} from './EditProfileViewModel';
import {FULLNAME_INVALID, PHONE_NUMBER_INVALID} from '../../../models/constants/string-constant';

type PropsType = {};

@observer
class EditProfile extends Component<PropsType> {
  viewModel: EditProfileViewModel;
  constructor() {
    super();
    this.viewModel = new EditProfileViewModel();
  }

  @autobind
  onChangeFullName(event: SyntheticInputEvent<HTMLInputElement>) {
    this.viewModel.updateFullName(event.target.value);
  }

  @autobind
  onChangeNickName(event: SyntheticInputEvent<HTMLInputElement>) {
    this.viewModel.updateNickName(event.target.value);
  }

  @autobind
  onChangeBio(event: SyntheticInputEvent<HTMLInputElement>) {
    this.viewModel.updateBio(event.target.value);
  }

  @autobind
  onChangePosition(event: SyntheticInputEvent<HTMLInputElement>) {
    this.viewModel.updatePosiotion(event.target.value);
  }

  @autobind
  onChangeTeam(event: SyntheticInputEvent<HTMLInputElement>) {
    this.viewModel.updateTeam(event.target.value);
  }

  @autobind
  onChangeOffice(event: SyntheticInputEvent<HTMLInputElement>) {
    this.viewModel.updateOffice(event.target.value);
  }

  @autobind
  onChangeAboutMe(event: SyntheticInputEvent<HTMLInputElement>) {
    this.viewModel.updateAboutMe(event.target.value);
  }

  @autobind
  onChangeSkype(event: SyntheticInputEvent<HTMLInputElement>) {
    this.viewModel.updateSkype(event.target.value);
  }

  @autobind
  onChangePhone(event: SyntheticInputEvent<HTMLInputElement>) {
    this.viewModel.updatePhone(event.target.value);
  }

  @autobind
  onChangeBirthday(value: Date) {
    this.viewModel.updateBirthday(value);
  }

  @autobind
  selectMale() {
    this.viewModel.updateGender(GENDERS[0].value);
  }

  @autobind
  selectFemale() {
    this.viewModel.updateGender(GENDERS[1].value);
  }

  @autobind
  selectOther() {
    this.viewModel.updateGender(GENDERS[2].value);
  }

  @autobind
  cleanGender() {
    this.viewModel.updateGender('');
  }

  @autobind
  editAvatar(event: SyntheticInputEvent<HTMLInputElement>) {
    const image = event.target.files[0];
    const type = image.type;
    if (!isContains(type, 'image')) {
      return;
    }
    this.viewModel.updateAvatar(image);
  }

  @autobind
  closeAvatarEditor() {
    this.viewModel.closeAvatarEditor();
  }

  @autobind
  onCompleteEditAvatar(file: File) {
    this.viewModel.completeEditAvatar(file);
  }

  @autobind
  onSave(event: SyntheticInputEvent<HTMLButtonElement>) {
    event.preventDefault();
    this.viewModel.saveProfile();
  }

  render() {
    const {
      viewModel: {
        about,
        avatar,
        avatarFile,
        bio,
        birthday,
        defaultAvatar,
        email,
        fullNameInvalid,
        fullName,
        isOpenAvatarEditor,
        nickName,
        office,
        phone,
        position,
        skype,
        team,
        isLoading,
        disabled,
        genderLabel,
        phoneInvalid
      }
    } = this;
    return (
      <div className="edit-profile">
        <Form onSubmit={this.onSave}>
          <div className="tab-header">
            <span className="title">About me</span>
          </div>
          <div className="content">
            <Form.Group as={Row}>
              <Form.Label className="avatar-label" column sm="3">
                Avatar
              </Form.Label>
              <Col sm="9">
                <label className="user-avatar" role="button">
                  {renderUserAvatar(avatar, defaultAvatar, 64)}
                  <div className="overlay">
                    <input
                      accept=".jpg,.jpeg,.png"
                      className="file-input"
                      onChange={this.editAvatar}
                      type="file"
                      value={''}
                    />
                    <Icon color="#fff" iconName="camera" size={24} />
                  </div>
                </label>
              </Col>
            </Form.Group>
            <Form.Group as={Row}>
              <Form.Label column sm="3">
                Full Name
              </Form.Label>
              <Col sm="9">
                <Form.Control
                  onChange={this.onChangeFullName}
                  value={fullName}
                  maxLength={250}
                  isInvalid={fullNameInvalid}
                />
                <Form.Control.Feedback className="text-left" type="invalid">
                  {FULLNAME_INVALID}
                </Form.Control.Feedback>
              </Col>
            </Form.Group>
            <Form.Group as={Row}>
              <Form.Label column sm="3">
                Nickname
              </Form.Label>
              <Col sm="9">
                <Form.Control onChange={this.onChangeNickName} value={nickName} maxLength={100} />
              </Col>
            </Form.Group>
            <Form.Group as={Row}>
              <Form.Label column sm="3">
                Bio
              </Form.Label>
              <Col sm="9">
                <Form.Control as="textarea" rows={3} onChange={this.onChangeBio} value={bio} maxLength={250} />
              </Col>
            </Form.Group>
            <Form.Group as={Row}>
              <Form.Label column sm="3">
                Position
              </Form.Label>
              <Col sm="9">
                <Form.Control
                  as="textarea"
                  rows={3}
                  onChange={this.onChangePosition}
                  value={position}
                  maxLength={250}
                />
              </Col>
            </Form.Group>
            <Form.Group as={Row}>
              <Form.Label column sm="3">
                Team
              </Form.Label>
              <Col sm="9">
                <Form.Control as="textarea" rows={3} onChange={this.onChangeTeam} value={team} maxLength={250} />
              </Col>
            </Form.Group>
            <Form.Group as={Row}>
              <Form.Label column sm="3">
                Office
              </Form.Label>
              <Col sm="9">
                <Form.Control as="textarea" rows={3} onChange={this.onChangeOffice} value={office} maxLength={250} />
              </Col>
            </Form.Group>
          </div>

          <div className="tab-header">
            <span className="title">Talk to me</span>
          </div>
          <div className="content">
            <Form.Group as={Row}>
              <Form.Label column sm="3">
                About
              </Form.Label>
              <Col sm="9">
                <Form.Control as="textarea" rows={3} onChange={this.onChangeAboutMe} value={about} maxLength={250} />
              </Col>
            </Form.Group>
            <Form.Group as={Row}>
              <Form.Label column sm="3">
                Email
              </Form.Label>
              <Col sm="9">
                <Form.Control disabled isInvalid={false} value={email} />
              </Col>
            </Form.Group>
            <Form.Group as={Row}>
              <Form.Label column sm="3">
                Skype
              </Form.Label>
              <Col sm="9">
                <Form.Control onChange={this.onChangeSkype} value={skype} maxLength={80} />
              </Col>
            </Form.Group>
            <Form.Group as={Row}>
              <Form.Label column sm="3">
                Phone
              </Form.Label>
              <Col sm="9">
                <Form.Control
                  onChange={this.onChangePhone}
                  type="tel"
                  value={phone}
                  maxLength={25}
                  isInvalid={phoneInvalid}
                />
                <Form.Control.Feedback className="text-left" type="invalid">
                  {PHONE_NUMBER_INVALID}
                </Form.Control.Feedback>
              </Col>
            </Form.Group>
          </div>
          <div className="tab-header">
            <span className="title">Private information</span>
          </div>
          <div className="content">
            <Form.Group as={Row}>
              <Form.Label column sm="3">
                Gender
              </Form.Label>
              <Col sm="9">
                <DropdownButton className="gender" title={genderLabel}>
                  <Dropdown.Item className="empty-dropdown" onClick={this.cleanGender} />
                  <Dropdown.Item onClick={this.selectMale}>Male</Dropdown.Item>
                  <Dropdown.Item onClick={this.selectFemale}>Female</Dropdown.Item>
                  <Dropdown.Item onClick={this.selectOther}>Not Specified</Dropdown.Item>
                </DropdownButton>
              </Col>
            </Form.Group>
            <Form.Group as={Row}>
              <Form.Label column sm="3">
                Birthday
              </Form.Label>
              <Col sm="9">
                <DatePicker
                  className="birth-day"
                  maxDate={new Date()}
                  onChange={this.onChangeBirthday}
                  placeholderText={'mm dd yyyy'}
                  dateFormat="MMM dd, yyyy"
                  selected={birthday}
                />
              </Col>
            </Form.Group>
          </div>
          <Button className="float-right" disabled={disabled || isLoading} type="submit">
            {isLoading && (
              <Spinner
                className="marginLeftRight-4"
                as="span"
                animation="border"
                size="sm"
                role="status"
                aria-hidden="true"
              />
            )}
            Save
          </Button>
        </Form>
        <AvatarEditor
          file={avatarFile}
          onClose={this.closeAvatarEditor}
          onComplete={this.onCompleteEditAvatar}
          open={isOpenAvatarEditor}
        />
      </div>
    );
  }
}

export default EditProfile;
