import AccountSetting from './AccountSetting';
import EditProfile from './EditProfile';
import NotificationSetting from './NotificationSetting';
import SendFeedback from './SendFeedback';

export {AccountSetting, EditProfile, NotificationSetting, SendFeedback};
