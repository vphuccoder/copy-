// @flow
import autobind from 'autobind-decorator';
import {observer} from 'mobx-react';
import React, {Component} from 'react';
import {Button, Col, Form, Row, Spinner} from 'react-bootstrap';
import {INVALID_PASSWORD_FORMAT} from '../../../models/constants/string-constant';
import {passwordPattern} from '../../../utils/regex';
import AccountSetingViewModel from './AccountSettingViewModel';

type PropsType = {};

@observer
class AccountSetting extends Component<PropsType> {
  viewModel: AccountSetingViewModel;
  constructor() {
    super();
    this.viewModel = new AccountSetingViewModel();
  }

  @autobind
  updateCurrentPassword(event: SyntheticInputEvent<HTMLInputElement>) {
    this.viewModel.updateCurrentPassword(event.target.value);
  }

  @autobind
  updateNewPassword(event: SyntheticInputEvent<HTMLInputElement>) {
    this.viewModel.updateNewPassword(event.target.value);
  }

  @autobind
  updateConfirmPassword(event: SyntheticInputEvent<HTMLInputElement>) {
    this.viewModel.updateConfirmPassword(event.target.value);
  }

  @autobind
  async onSubmit(event: SyntheticInputEvent<HTMLButtonElement>) {
    event.preventDefault();
    await this.viewModel.updatePassword();
  }

  render() {
    const {
      isValid,
      isLoading,
      currentPassword,
      newPassword,
      confirmNewPassword,
      currentPasswordErrorMessage,
      newPasswordErrorMessage,
      confirmPasswordErrorMessage,
      passwordNotMatch,
      incorrectPassword
    } = this.viewModel;
    return (
      <div className="account-setting">
        <div className="tab-header">
          <span className="title">Change your password</span>
        </div>
        <div className="content">
          <Form onSubmit={this.onSubmit}>
            <Form.Group as={Row}>
              <Form.Label column sm="4">
                Current password
              </Form.Label>
              <Col sm="8">
                <Form.Control
                  autoComplete="off"
                  isInvalid={incorrectPassword}
                  required
                  type="password"
                  pattern="(?=.*\d)(?=.*[a-zA-Z]).{6,}"
                  title={INVALID_PASSWORD_FORMAT}
                  value={currentPassword}
                  onChange={this.updateCurrentPassword}
                />
                <Form.Control.Feedback className="text-left" type="invalid">
                  {currentPasswordErrorMessage}
                </Form.Control.Feedback>
              </Col>
            </Form.Group>
            <Form.Group as={Row}>
              <Form.Label column sm="4">
                New password
              </Form.Label>
              <Col sm="8">
                <Form.Control
                  autoComplete="off"
                  isInvalid={passwordNotMatch}
                  required
                  type="password"
                  pattern="(?=.*\d)(?=.*[a-zA-Z]).{6,}"
                  title={INVALID_PASSWORD_FORMAT}
                  value={newPassword}
                  onChange={this.updateNewPassword}
                />
                <Form.Control.Feedback className="text-left" type="invalid">
                  {newPasswordErrorMessage}
                </Form.Control.Feedback>
              </Col>
            </Form.Group>
            <Form.Group as={Row}>
              <Form.Label column sm="4">
                Confirm new password
              </Form.Label>
              <Col sm="8">
                <Form.Control
                  autoComplete="off"
                  isInvalid={passwordNotMatch}
                  required
                  type="password"
                  pattern="(?=.*\d)(?=.*[a-zA-Z]).{6,}"
                  title={INVALID_PASSWORD_FORMAT}
                  value={confirmNewPassword}
                  onChange={this.updateConfirmPassword}
                />
                <Form.Control.Feedback className="text-left" type="invalid">
                  {confirmPasswordErrorMessage}
                </Form.Control.Feedback>
              </Col>
            </Form.Group>
            <Button className="float-right" disabled={!isValid || isLoading} type="submit">
              {isLoading && (
                <Spinner
                  className="marginLeftRight-4"
                  as="span"
                  animation="border"
                  size="sm"
                  role="status"
                  aria-hidden="true"
                />
              )}
              Save
            </Button>
          </Form>
        </div>
      </div>
    );
  }
}

export default AccountSetting;
