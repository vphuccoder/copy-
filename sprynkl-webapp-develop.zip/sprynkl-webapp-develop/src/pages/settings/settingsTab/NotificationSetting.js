// @flow

import React, {Component} from 'react';
import {Button, Col, Row} from 'react-bootstrap';
class NotificationSetting extends Component {
  render() {
    return (
      <div className="notification-setting">
        <div className="tab-header">
          <span className="title"> Desktop Notifications</span>
        </div>
        <div className="content">
          <Row>
            <Col lg={8}>
              <div className="description">
                <span>
                  We strongly recommend enabling notifications so that you’ll know when important
                  activity happens in your Sprynkl workspace.
                </span>
              </div>
            </Col>
            <Col lg={4}>
              <Button>Enable</Button>
            </Col>
          </Row>
        </div>
      </div>
    );
  }
}

export default NotificationSetting;
