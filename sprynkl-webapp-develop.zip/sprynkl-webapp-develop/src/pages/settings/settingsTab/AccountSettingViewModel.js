// @flow
import {observable, computed} from 'mobx';
import {action} from 'popmotion';
import {appModel} from '../../../models/app-model';
import {BasePageViewModel} from '../../../pages/BasePageViewModel';
import {userService} from '../../../services';
import {
  PASSWORD_NOT_MATCH,
  INCORRECT_PASSWORD,
  CAN_NOT_USE_OLD_PASSWORD,
  UPDATE_PASSWORD_SUCCESSFULLY
} from '../../../models/constants/string-constant';
import {password_incorrect, similar_currentpassword} from '../../../models/constants/error-codes';
class AccountSettingViewModel extends BasePageViewModel {
  @observable
  currentPassword: string = '';

  @observable
  newPassword: string = '';

  @observable
  confirmNewPassword: string = '';

  @observable
  isLoading: boolean = false;

  @observable
  disabled: boolean = true;

  @observable
  passwordNotMatch: boolean = false;

  @observable
  incorrectPassword: boolean = false;

  @observable
  notAllowUsingCurrentPassword: boolean = false;

  @observable
  currentPasswordErrorMessage: string = '';

  @observable
  newPasswordErrorMessage: string = '';

  @observable
  confirmPasswordErrorMessage: string = '';

  @computed
  get isValid(): boolean {
    const {currentPassword, newPassword, confirmNewPassword, disabled} = this;
    return !disabled && currentPassword.trim() !== '' && newPassword.trim() !== '' && confirmNewPassword.trim() !== '';
  }

  @action
  updateCurrentPassword(password: string) {
    this.resetValidate();
    this.currentPassword = password;
    this.disabled = false;
  }

  @action
  updateNewPassword(password: string) {
    this.resetValidate();
    this.newPassword = password;
    this.disabled = false;
  }

  @action
  updateConfirmPassword(password: string) {
    this.resetValidate();
    this.confirmNewPassword = password;
    this.disabled = false;
  }

  @action
  resetValidate() {
    this.passwordNotMatch = false;
    this.incorrectPassword = false;
    this.notAllowUsingCurrentPassword = false;
  }

  @action
  validateForm(): boolean {
    if (this.newPassword !== this.confirmNewPassword) {
      this.passwordNotMatch = true;
      this.newPasswordErrorMessage = this.confirmPasswordErrorMessage = PASSWORD_NOT_MATCH;
      return false;
    }
    return true;
  }

  async updatePassword() {
    if (this.validateForm()) {
      this.isLoading = true;

      const {currentPassword, newPassword} = this;
      try {
        const {
          currentToken: {accessToken}
        } = appModel;

        await userService.changePassword(accessToken, currentPassword, newPassword);
        appModel.alertMessageViewModel.showAlert(UPDATE_PASSWORD_SUCCESSFULLY);
        this.clean();
        this.isLoading = false;
      } catch (ex) {
        const {data = {}} = ex;
        if (data.key === password_incorrect) {
          this.incorrectPassword = true;
          this.currentPasswordErrorMessage = INCORRECT_PASSWORD;
        } else if (data.key === similar_currentpassword) {
          this.passwordNotMatch = true;
          this.newPasswordErrorMessage = this.confirmPasswordErrorMessage = CAN_NOT_USE_OLD_PASSWORD;
        }
        this.isLoading = false;
      }
    }
  }

  @action
  clean() {
    this.currentPassword = '';
    this.newPassword = '';
    this.confirmNewPassword = '';
  }
}

export default AccountSettingViewModel;
