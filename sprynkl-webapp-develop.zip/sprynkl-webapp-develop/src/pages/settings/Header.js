// @flow

import autobind from 'autobind-decorator';
import React, {Component} from 'react';
import {withRouter} from 'react-router';
import Icon from '../../components/baseComponents/Icon';
import {icons} from '../../components/themes/Icons';

@withRouter
class Header extends Component {
  @autobind
  onBack() {
    this.props.history.goBack();
  }
  render() {
    return (
      <div className="setting-header">
        <span className="title">Settings</span>
        <a className="back-button" onClick={this.onBack}>
          <Icon color={'#dbddde'} iconName={icons.close} size={24} />
        </a>
      </div>
    );
  }
}

export default Header;
