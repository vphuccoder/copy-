import GetStart from './getStart/GetStart';
import Home from './home/Home';
import Login from './login/Login';
import MagicLink from './magicLink/MagicLink';
import NotFound from './notFound';
import ResetPassword from './resetPassword/ResetPassword';
import {Settings} from './settings';
import SignUp from './signUp/SignUp';
import UserProfile from './userProfile';
import PageForbidden from './forbidden';

export {GetStart, Home, Login, MagicLink, NotFound, ResetPassword, Settings, SignUp, UserProfile, PageForbidden};
