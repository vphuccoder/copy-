// @flow
import autobind from 'autobind-decorator';
import queryString from 'query-string';
import React, {Component} from 'react';
import {withRouter} from 'react-router';
import UpdateNewPassword from '../resetPassword/updateNewPassword/UpdateNewPassword';
import VerifyAccount from '../signUp/verifyAccount/VerifyAccount';
@withRouter
class MagicLink extends Component {
  @autobind
  getQueryValues(): {} {
    return queryString.parse(this.props.location.search);
  }

  render(): React.Node {
    const queryValue = this.getQueryValues();
    switch (queryValue.action) {
      case 'reset-password':
        return <UpdateNewPassword {...queryValue} />;
      case 'verify-account':
        return <VerifyAccount {...queryValue} />;
      default:
        return null;
    }
  }
}

export default MagicLink;
