import autobind from 'autobind-decorator';
import React, {Component, Fragment} from 'react';
import {Button, Col, Container, Form} from 'react-bootstrap';
import {userService} from 'services';
import {Logo} from '../../components/baseComponents/svg/Svg';
import Footer from '../../components/footer/Footer';
import './ResetPassword.scss';

class ResetPassword extends Component {
  state = {
    accountExisted: true,
    email: '',
    isEmailSent: false
  };

  @autobind
  async sendResetPasswordLink(event) {
    event.preventDefault();
    event.stopPropagation();
    try {
      await userService.forgetPassword(this.state.email);
      this.setState({
        isEmailSent: true
      });
    } catch (e) {
      this.setState({
        accountExisted: false
      });
    }
  }

  @autobind
  renderResetPasswordForm() {
    const {accountExisted, email} = this.state;
    return (
      <Fragment>
        <h3>{'Forgot your password?'}</h3>
        <p className="info">{"We'll send you an email with a reset link."}</p>
        <Col lg="4" md="6" sm="8">
          <Form className="form" onSubmit={this.sendResetPasswordLink}>
            <Form.Group>
              <Form.Control
                isInvalid={!accountExisted}
                onChange={this.changeEmail}
                placeholder="Your email address"
                required
                type="email"
                value={email}
              />
              <Form.Control.Feedback type="invalid">
                Account email does not exist.
              </Form.Control.Feedback>
            </Form.Group>
            <Button className="reset-password-button" variant="primary">
              {'Reset Password'}
            </Button>
          </Form>
          <a className="back-to-sign-in" href="./login">
            <span>{'Back to sign in'}</span>
          </a>
        </Col>
      </Fragment>
    );
  }

  @autobind
  renderSentMessage() {
    return (
      <Fragment>
        <h3>{'We just sent you an email'}</h3>
        <p className="info">{'Please follow the link in the email to reset your password.'}</p>
      </Fragment>
    );
  }

  @autobind
  changeEmail(e) {
    this.setState({
      email: e.target.value
    });
  }

  render() {
    const {isEmailSent} = this.state;
    return (
      <div className="reset-password">
        <Container>
          <Logo height={40} />
          {isEmailSent ? this.renderSentMessage() : this.renderResetPasswordForm()}
          <Footer />
        </Container>
      </div>
    );
  }
}

export default ResetPassword;
