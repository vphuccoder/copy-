import autobind from 'autobind-decorator';
import queryString from 'query-string';
import React, {Component, Fragment} from 'react';
import {Button, Col, Container, Form} from 'react-bootstrap';
import {withRouter} from 'react-router';
import {Logo} from '../../../components/baseComponents/svg/Svg';
import Footer from '../../../components/footer/Footer';
import {userService} from '../../../services';
import {passwordRegex} from '../../../utils/regex';
import './UpdateNewPassword.scss';

@withRouter
class UpdateNewPassword extends Component {
  state = {
    confirmPassword: '',
    isPasswordUpdated: false,
    isPasswordsMatched: true,
    isValidPassword: true,
    password: ''
  };

  @autobind
  getQueryValues() {
    return queryString.parse(this.props.location.search);
  }

  @autobind
  async resetNewPassword(e) {
    e.preventDefault();
    const {password} = this.state;
    const {code: pin, email} = this.props;

    const validationResults = this.validateForm();
    const {isValid} = validationResults;
    if (isValid) {
      try {
        await userService.resetPassword(email, pin, password);
        this.setState({
          isPasswordUpdated: true
        });
      } finally {
        this.setState({
          ...validationResults
        });
      }
    } else {
      this.setState({...validationResults});
    }
  }

  @autobind
  validateForm() {
    const {confirmPassword, password} = this.state;
    const isValidPassword = passwordRegex.test(password);
    const isPasswordsMatched = password === confirmPassword;

    return {
      isPasswordsMatched,
      isValid: isValidPassword && isPasswordsMatched,
      isValidPassword
    };
  }

  @autobind
  onValueChange(e) {
    this.setState({
      [e.target.name]: e.target.value
    });
  }

  @autobind
  renderResetPasswordForm() {
    const {confirmPassword, isPasswordsMatched, isValidPassword, password} = this.state;
    return (
      <Fragment>
        <h3>{'Reset your password'}</h3>
        <Col lg="4" md="6" sm="8">
          <Form className="form" onSubmit={this.resetNewPassword}>
            <Form.Group>
              <Form.Control
                isInvalid={!isValidPassword}
                name="password"
                onChange={this.onValueChange}
                placeholder="New password"
                required
                type="password"
                value={password}
              />
              <Form.Control.Feedback type="invalid">
                Your password must be at least 6 characters, 1 letter, 1 number required.
              </Form.Control.Feedback>
            </Form.Group>
            <Form.Group>
              <Form.Control
                isInvalid={!isPasswordsMatched}
                name="confirmPassword"
                onChange={this.onValueChange}
                placeholder="Confirm new password"
                required
                type="password"
                value={confirmPassword}
              />
              <Form.Control.Feedback type="invalid">Password mismatch</Form.Control.Feedback>
            </Form.Group>
            <Button className="update-password-button" variant="primary" type="submit">
              {'Save'}
            </Button>
          </Form>
        </Col>
      </Fragment>
    );
  }

  @autobind
  renderSentMessage() {
    return <p className="success-message">{'Your password has been updated.'}</p>;
  }

  render() {
    const {isPasswordUpdated} = this.state;
    return (
      <div className="update-password">
        <Container>
          <Logo height={40} />
          {isPasswordUpdated ? this.renderSentMessage() : this.renderResetPasswordForm()}
          <Footer />
        </Container>
      </div>
    );
  }
}

export default UpdateNewPassword;
