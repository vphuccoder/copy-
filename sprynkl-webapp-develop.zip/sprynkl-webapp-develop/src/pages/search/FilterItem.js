// @flow
import React, {PureComponent} from 'react';
import autobind from 'autobind-decorator';

export default class FilterBar extends PureComponent {
  @autobind
  selectFilter() {
    const {selectFilter, filterItem} = this.props;
    selectFilter(filterItem);
  }

  render() {
    const {className, filterItem} = this.props;
    return (
      <p className={className} onClick={this.selectFilter}>
        {filterItem}
      </p>
    );
  }
}
