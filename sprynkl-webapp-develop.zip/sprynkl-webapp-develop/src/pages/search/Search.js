// @flow
import * as React from 'react';
import {Component, Fragment} from 'react';
import type {Node} from 'react';
import {observer} from 'mobx-react';
import {withRouter} from 'react-router';
import type {Match, RouterHistory} from 'react-router';
import autobind from 'autobind-decorator';
import {Col, Spinner} from 'react-bootstrap';
import {Container, Row} from 'react-bootstrap';
import {TextOverFlow} from '../../components/baseComponents';
import {Header} from '../../components/header';
import {PostViewModel, FeedList} from '../../components/feeds';
import {appModel} from '../../models/app-model';
import {INVALID_SEARCH_URL, NO_RESULT_FOUND} from '../../models/constants/string-constant';
import {FilterBar, SearchViewModel} from './';
import './Search.scss';

type PropsType = {
  match: Match,
  history: RouterHistory
};

@withRouter
@observer
class Search extends Component<PropsType> {
  searchTerm: ?string = '';

  viewModel: SearchViewModel;

  constructor(props: PropsType) {
    super(props);
    const searchTerm = this.getSearchTerm();
    this.searchTerm = searchTerm;
    this.viewModel = new SearchViewModel(this.searchTerm);
  }

  componentDidMount() {
    const {viewModel} = this;
    if (this.searchTerm) {
      viewModel.initial();
    }
  }

  @autobind
  getSearchTerm(): ?string {
    const {
      match: {
        params: {searchTerm}
      }
    } = this.props;
    if (searchTerm) {
      return decodeURIComponent(searchTerm) || '';
    }
  }

  @autobind
  async loadMore() {
    await this.viewModel.getFeeds(this.viewModel.page + 1);
  }

  @autobind
  renderLoadMore(): Node {
    const {onLoading, firstTimeLoad} = this.viewModel;
    return onLoading === true && firstTimeLoad === false ? (
      <div className="load-more-spinner">
        <Spinner animation="border" variant="primary" />
      </div>
    ) : null;
  }

  @autobind
  async deletePost(postVm: PostViewModel) {
    await this.viewModel.deletePost(postVm);
  }

  @autobind
  renderEmptyState(): React.Element<'div'> {
    if (this.searchTerm) {
      return <div className="no-results">{`${NO_RESULT_FOUND}"${this.searchTerm}"`}</div>;
    }
    return <div className="no-results">{INVALID_SEARCH_URL}</div>;
  }

  renderTotalResult(): React.Element<'div'> {
    const {feeds, onLoading, totalResults} = this.viewModel;
    if (onLoading || !totalResults || !feeds) {
      return null;
    }
    if (totalResults <= 1) {
      return <div className="total-results">{totalResults} result</div>;
    } else {
      return <div className="total-results">{totalResults} results</div>;
    }
  }

  @autobind
  renderContent(): Node {
    const {feeds, onLoading} = this.viewModel;
    return (
      <Fragment>
        <Container className="main">
          <Row>
            <Col lg={8}>
              {this.renderTotalResult()}
              <FeedList
                renderEmptyState={this.renderEmptyState}
                deletePost={this.deletePost}
                feeds={feeds}
                showLoadingContent={onLoading && true}
                loadMore={this.loadMore}
              />
            </Col>
          </Row>
          {this.renderLoadMore()}
        </Container>
      </Fragment>
    );
  }

  @autobind
  selectTeam(id: string) {
    // TODO: Implement later.
  }

  @autobind
  selectFilter(filterItem: string) {
    this.viewModel.selectFilter(filterItem);
  }

  render(): Node {
    const {currentGroup} = appModel;
    const {selectedFilter} = this.viewModel;
    const {searchTerm = ''} = this;
    return (
      <div className="search-page">
        <Header
          searchValue={searchTerm}
          groups={this.viewModel.joinGroups}
          selectedGroup={currentGroup}
          disabledTeamSelection
        />
        <div className="search-term">
          <TextOverFlow className="search-text" textOverflow={searchTerm} placement="right" />
        </div>
        <FilterBar selectFilter={this.selectFilter} selectedFilter={selectedFilter} />
        {this.renderContent()}
      </div>
    );
  }
}

export default Search;
