// @flow
import React, {Component} from 'react';
import autobind from 'autobind-decorator';
import FilterItem from './FilterItem';
import {ASK, VOICE, THANKS} from '../../models';
const ALL_ITEM = 'all';

export default class FilterBar extends Component {
  @autobind
  selectFilter(filterItem: string) {
    if (filterItem === ALL_ITEM) {
      this.props.selectFilter('');
    } else {
      this.props.selectFilter(filterItem);
    }
  }

  renderFilterItem(filterItem: string, index: number) {
    const {selectedFilter} = this.props;
    const activeItem =
      (selectedFilter && selectedFilter === filterItem) || (!selectedFilter && filterItem === ALL_ITEM);
    const className = `filter-item ${activeItem ? 'active' : ''}`;
    return <FilterItem key={index} className={className} filterItem={filterItem} selectFilter={this.selectFilter} />;
  }

  renderFilters() {
    return [ALL_ITEM, ASK, VOICE, THANKS].map((filterItem: string, index: index) => {
      return this.renderFilterItem(filterItem, index);
    });
  }

  render() {
    return (
      <div className="filter-bar">
        <div className="filter-container">{this.renderFilters()}</div>
      </div>
    );
  }
}
