// @flow
import {observable, action, flow, runInAction} from 'mobx';
import {BasePageViewModel} from '../BasePageViewModel';
import {postService, groupService} from '../../services/index';
import {appModel} from '../../models/app-model';
import {FeedModel, Group, PostModel, ASK, VOICE, THANKS, UserGroup} from '../../models';
import {PostViewModel} from '../../components/feeds';
import {PAGE_SIZE} from '../../models/constants/system';
import {checkValidHashTag} from '../../utils/regex';
const ALL_ITEM = 'all';

class SearchViewModel extends BasePageViewModel {
  @observable
  joinGroups: Array<UserGroup> = [];

  @observable
  group: Group = null;

  @observable
  feeds: Array<{}> = [];

  @observable
  onLoading: boolean = false;

  @observable
  selectedFilter: string = '';

  @observable
  onProgress: boolean = false;

  @observable
  totalResults: number;

  searchTerm: ?string = '';

  constructor(searchTerm: ?string) {
    super();
    this.searchTerm = searchTerm;
  }

  @action
  setCurrentGroup(group: Group) {
    this.group = group;
  }

  @action
  selectFilter(filterItem: string) {
    this.selectedFilter = filterItem;
    this.getFeeds(1);
  }

  @action
  async selectedGroupById(id: string) {
    if (!id) {
      appModel.setCurrentGroup(null);
      this.group = null;
    } else {
      this.showLoading();
      const group = await groupService.getGroup(appModel.currentToken.accessToken, id);
      appModel.setCurrentGroup(group);
      this.group = group;
      this.hideLoading();
    }
  }

  @action
  async deletePost(selectedPost: {}): Promise {
    try {
      this.showLoading();
      const {accessToken} = appModel.currentToken;
      await postService.deletePost(accessToken, selectedPost.post.id);

      const index = this.feeds.indexOf(selectedPost);

      runInAction(() => {
        this.feeds.splice(index, 1);
        this.hideLoading();
      });
    } catch (ex) {
      this.hideLoading();
      this.handleError(ex, true);
    }
  }
  @action
  setJoinGroups(groups: Array<UserGroup>) {
    this.joinGroups = groups;
  }

  async initial() {
    const user = appModel.currentUser;

    if (user.hasJoinedGroup === true) {
      const groups = user.getJoinedUserGroup();
      this.setJoinGroups(groups);
      if (groups.length === 1) {
        // select group
        const userGroup = groups[0] || {};
        const group = await groupService.getGroup(appModel.currentToken.accessToken, userGroup.group.id);
        this.setCurrentGroup(group);
        appModel.setCurrentGroup(group);
      } else {
        appModel.setCurrentGroup(null);
        this.showLoadingContent = false;
      }
      this.canCloseJoinTeam = true;
    } else if (user.hasInvitedGroup === true) {
      // show join team
      this.showJoinTeamDialog();
    } else {
      // show create team
      this.showCreateTeamDialog();
    }
    this.getFeeds(1);
  }

  @action
  getFeeds = flow(function*(page: number = 1): Promise {
    if (this.onLoading === true || !this.searchTerm) {
      return;
    }

    if (page === 1) {
      // reload
      this.page = 1;
      this.hasMore = true;
    }

    if (this.hasMore === false) {
      return;
    }

    this.onLoading = true;

    try {
      const newFeeds = [];
      const {selectedFilter} = this;
      const types =
        selectedFilter && selectedFilter.trim() !== '' && selectedFilter !== ALL_ITEM
          ? [selectedFilter]
          : [ASK, VOICE, THANKS];
      const isHashTag = checkValidHashTag(this.searchTerm);
      const data = {
        keyword: isHashTag ? null : this.searchTerm,
        types,
        pageSize: PAGE_SIZE,
        pageNumber: page,
        hashtag: isHashTag ? this.searchTerm.substr(1) : null,
        groupId: undefined
      };

      if (this.group) {
        data.groupId = this.group.id;
        const results = yield postService.filterFeed(appModel.currentToken.accessToken, data);
        const res = FeedModel.map(results.data);

        if (res && res.posts.length > 0) {
          res.posts.forEach((p: PostModel) => {
            p.setGroup(this.group);
          });
          newFeeds.push(...res.posts.map((p: PostModel): PostViewModel => PostViewModel.toViewModel(p)));
          this.page = page;
        }
      } else {
        const response = yield postService.filterFeed(appModel.currentToken.accessToken, data);
        const searchResult = FeedModel.map(response.data);
        if (searchResult && searchResult.posts.length > 0) {
          const uniqueGroupIds = this.getUniqueGroupIds(searchResult.posts);
          const groups = yield this.fetchUniqueGroups(uniqueGroupIds);
          searchResult.posts.forEach((post: PostModel) => {
            const group = groups.find((group: Group): boolean => group.id === post.group.id);
            if (group) {
              post.setGroup(group);
            }
          });
          newFeeds.push(...searchResult.posts.map((post: PostModel): PostViewModel => PostViewModel.toViewModel(post)));
          this.page = page;
        }
        this.totalResults = response.total;
      }

      if (page === 1) {
        this.feeds = [];
      }

      if (newFeeds.length <= 0) {
        this.hasMore = false;
      }

      // Check new feeds already on current feeds before push to list
      newFeeds.forEach((item: {}) => {
        const index = this.feeds.findIndex(
          (itemSource: {}): boolean => {
            const postItem = item.post || {};
            const postItemSource = itemSource.post || {};
            return postItem.id === postItemSource.id;
          }
        );

        if (index < 0) {
          this.feeds.push(item);
        }
      });

      this.onLoading = false;
    } finally {
      this.firstTimeLoad = false;
    }
  });

  async fetchUniqueGroups(uniqueGroups: string[]): Promise<Group[]> {
    const allRequests = uniqueGroups.map(
      (groupId: string): Promise<Group> => groupService.getGroup(appModel.currentToken.accessToken, groupId)
    );
    return await Promise.all(allRequests);
  }

  getUniqueGroupIds(posts: PostModel[]): string[] {
    const groupIds: string[] = [];
    posts.forEach((p: PostModel) => {
      if (groupIds.indexOf(p.group.id) === -1) {
        groupIds.push(p.group.id);
      }
    });
    return groupIds;
  }
}

export {SearchViewModel};
