import React, { Component } from "react";
class Logout extends Component {
  render() {
    return <div className="home" ><span>Log Out</span></div>;
  }
}

export default Logout;
