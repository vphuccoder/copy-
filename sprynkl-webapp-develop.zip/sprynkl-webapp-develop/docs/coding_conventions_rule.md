# Coding conventions

Please follow javaScript Style Guide and Coding Conventions: https://www.w3schools.com/js/js_conventions.asp

# Rules

- Use const by default. Only let for mutable var.
- Components: always have index.js
- Component-specific view model must be defined right next to the component.
- Use lower case for directory and file name, e.g. scale-unit.js.
- Service must be a class. Can export instance.
- Do not hard code colors
- Components: always have index.js
- Use lower case for directory and file name, e.g. scale-unit.js.
- Service must be a class. Can export instance.
- Do not hard code colors
- Do not use inline styles or styled components.  Stick with SCSS, one per component.
- Component-specific view model must be defined right next to the component.