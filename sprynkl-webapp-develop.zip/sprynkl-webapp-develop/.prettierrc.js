module.exports = {
  tslintIntegration: false,
  eslintIntegration: false,
  printWidth: 120,
  arrowParens: 'always',
  singleQuote: true,
  tabWidth: 2,
  bracketSpacing: false,
  useTabs: false
};
